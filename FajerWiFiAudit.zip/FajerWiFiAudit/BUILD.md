# Build Instructions for FAJER WiFi Audit

This document describes the build process for the complete FAJER Android application.

## Project Structure

The project is a complete, production-ready Android Studio project with the following structure:

```
FajerWiFiAudit/
├── app/                                 # Main application module
│   ├── src/
│   │   ├── main/
│   │   │   ├── java/com/fajer/wifiaudit/   # All source code
│   │   │   ├── res/                        # Resources (strings, colors, themes)
│   │   │   └── AndroidManifest.xml
│   │   ├── test/                           # Unit tests
│   │   └── androidTest/                    # Instrumented tests
│   ├── proguard-rules.pro                  # R8 optimization rules
│   └── build.gradle.kts                    # App module build configuration
│
├── gradle/
│   ├── wrapper/
│   │   └── gradle-wrapper.properties        # Pins the Gradle version (8.14.5)
│   └── libs.versions.toml (future)
├── (gradlew / gradlew.bat — not committed; see "First build" in README.md.
│    Android Studio generates both, with the matching wrapper jar, on first sync.)
│
├── build.gradle.kts                         # Root build file
├── settings.gradle.kts                      # Gradle settings
├── gradle.properties                        # Gradle properties
├── AndroidManifest.xml                      # App manifest
├── .gitignore                               # Git ignore file
├── README.md                                # User-facing documentation
├── BUILD.md                                 # This file
└── LICENSE                                  # MIT License

```

## Prerequisites

### Minimum Requirements

- **Android Studio** 2024.3.1 (Meerkat) or later
  - Supports Kotlin 2.2.21, AGP 8.13.2, Compose 2026.06.01
  - Download from: https://developer.android.com/studio

- **Android SDK**
  - Platform SDK 36 (Android 16 / Baklava) — **required** for compileSdk
  - Platform SDK 26+ — required for minSdk compatibility
  - Build-Tools 36.x.x or later

- **JDK**
  - OpenJDK 17+ or Oracle JDK 17+
  - JDK 21+ recommended (current stable)

- **Gradle**
  - Version 8.14.5 (managed by the included wrapper)
  - Gradle wrapper downloads this automatically on first build

### Installation

1. **Download Android Studio:**
   ```
   https://developer.android.com/studio/download
   ```

2. **SDK Manager** (in Android Studio):
   - Tools → SDK Manager
   - Platform tab: Install "Android SDK Platform 36"
   - Tools tab: Install "Android SDK Build-Tools 36.x.x" (latest)
   - Tools tab: Install "Android Emulator" (optional, for testing)

3. **Set ANDROID_HOME** (optional but recommended):
   ```bash
   export ANDROID_HOME="~/Library/Android/sdk"  # macOS
   export ANDROID_HOME="~/Android/Sdk"          # Linux
   export ANDROID_HOME="%APPDATA%\Android\sdk" # Windows
   ```

## Build Process

### 1. Clone and Open

```bash
cd ~/projects
git clone <repo-url>
cd FajerWiFiAudit
```

Open in Android Studio: `File → Open → (navigate to FajerWiFiAudit)`

### 2. Build Variants

#### Debug Build (Development)

```bash
./gradlew assembleDebug
```

Output: `app/build/outputs/apk/debug/app-debug.apk`

- Unoptimized, includes debug symbols
- Debugger-friendly (breakpoints, logcat)
- Installs quickly
- Slow at runtime
- Use for testing during development

#### Release Build (Production)

```bash
./gradlew assembleRelease
```

Output: `app/build/outputs/apk/release/app-release-unsigned.apk`

- Minified with R8 (ProGuard replacement)
- Resource shrinking enabled
- Not signed (you must sign manually or let Android Studio sign)
- Fast at runtime
- Use for Play Store submission or distribution

### 3. From Android Studio (GUI)

1. **Sync Gradle files** (automatic, or `File → Sync Now`)
2. **Select Build Variant:**
   - Bottom panel: "Build Variants" tab → select "debug" or "release"
3. **Build:**
   - `Build → Build Bundle(s) / APK(s) → Build APK(s)`
4. **Find output:**
   - Build output shows in "Build" window with file path link

### 4. Install and Run

**From command line:**

```bash
# Install on device/emulator
./gradlew installDebug

# Launch the app
adb shell am start -n com.fajer.wifiaudit.debug/com.fajer.wifiaudit.MainActivity

# View live logs
adb logcat -s "FAJ*"
```

**From Android Studio:**

1. Select device/emulator from toolbar
2. Press the green "Run" arrow (or Shift+F10)

### 5. Testing

**Run all unit tests:**

```bash
./gradlew test
```

Output: `app/build/reports/tests/testDebugUnitTest/index.html`

**Run instrumented tests (requires device/emulator):**

```bash
./gradlew connectedAndroidTest
```

**Run lint checks:**

```bash
./gradlew lint
```

Output: `app/build/reports/lint-results-debug.html`

## Build System Overview

### Gradle Configuration

- **Root `build.gradle.kts`:** Declares plugin versions (AGP, Kotlin, KSP)
- **App `app/build.gradle.kts`:** Module-specific configuration:
  - compileSdk = 36
  - minSdk = 26
  - targetSdk = 36
  - Compose feature flag enabled
  - All production dependencies declared here

### Dependency Management

Dependencies are declared in `app/build.gradle.kts`:

```kotlin
// Core
implementation("androidx.core:core-ktx:1.15.0")
implementation("androidx.lifecycle:lifecycle-viewmodel-ktx:2.8.7")

// Compose (using BOM for aligned versions)
implementation(platform("androidx.compose:compose-bom:2026.06.01"))
implementation("androidx.compose.ui:ui")
implementation("androidx.compose.material3:material3")

// Database (Room)
implementation("androidx.room:room-runtime:2.6.1")
ksp("androidx.room:room-compiler:2.6.1")

// Navigation
implementation("androidx.navigation:navigation-compose:2.8.4")

// Tests
testImplementation("junit:junit:4.13.2")
androidTestImplementation("androidx.compose.ui:ui-test-junit4")
```

### KSP (Kotlin Symbol Processing)

The build uses KSP for code generation (Room database compiler). Configured in `app/build.gradle.kts`:

```kotlin
plugins {
    id("com.google.devtools.ksp")
}

ksp {
    arg("room.schemaLocation", "$projectDir/schemas")
    arg("room.generateKotlin", "true")
}

dependencies {
    ksp("androidx.room:room-compiler:2.6.1")
}
```

## Troubleshooting

### Gradle Sync Issues

**Problem:** "Failed to sync / Plugin not found / Version unavailable"

**Solution:**
1. `File → Sync Now` (or `./gradlew sync`)
2. `File → Invalidate Caches → Invalidate and Restart`
3. Delete `~/.gradle/caches` (nuclear option; will re-download everything)

### Build Fails with "compileSdk Not Set" or "Unsupported ClassVersion"

**Problem:** Gradle can't compile

**Solution:**
1. Verify Android SDK Platform 36 is installed: `SDK Manager → Platform → Android SDK Platform 36`
2. Verify JDK version: `File → Project Structure → JDK Location`
   - Must be JDK 17+

### Compilation Errors in IDE but Build Succeeds

**Problem:** Red squiggles in Android Studio but `./gradlew build` works

**Solution:**
1. `File → Invalidate Caches and Restart`
2. `Build → Clean Project` then `Build → Make Project`

### APK Won't Install

**Problem:** `adb install` fails with "Signature mismatch" or "INSTALL_FAILED_UPDATE_INCOMPATIBLE"

**Solution:**
```bash
# Uninstall previous version(s)
adb uninstall com.fajer.wifiaudit
adb uninstall com.fajer.wifiaudit.debug

# Clear app data
adb shell pm clear com.fajer.wifiaudit.debug

# Reinstall
./gradlew installDebug
```

### "Android SDK Platform 36" Not Available

**Problem:** SDK Manager doesn't show Platform 36

**Solution:**
1. In SDK Manager, enable "Show Package Details" (bottom right)
2. Expand "Android 16" (if not visible, scroll down)
3. Check "Android SDK Platform Baklava" and install

## CI/CD (GitHub Actions)

A future `.github/workflows/android-ci.yml` would automate:

```yaml
name: Android CI
on: [push, pull_request]
jobs:
  build:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      - uses: actions/setup-java@v3
        with:
          java-version: '17'
      - run: ./gradlew assembleDebug
      - run: ./gradlew test
      - run: ./gradlew lint
```

## Signing for Release

To sign the APK for Play Store or distribution:

```bash
# Generate keystore (one-time)
keytool -genkey -v -keystore my-release-key.keystore \
  -keyalg RSA -keysize 2048 -validity 10000 \
  -alias my-key-alias

# Sign the unsigned APK
jarsigner -verbose -sigalg SHA1withRSA -digestalg SHA1 \
  -keystore my-release-key.keystore \
  app/build/outputs/apk/release/app-release-unsigned.apk \
  my-key-alias

# Verify signature
jarsigner -verify -verbose -certs app-release-unsigned.apk

# Align (required for Play Store)
zipalign -v 4 app-release-unsigned.apk app-release-signed.apk
```

Or use Android Studio's built-in signing: `Build → Generate Signed Bundle/APK`.

## Performance Tips

### Faster Builds

```bash
# Parallel builds (4 parallel tasks)
./gradlew --parallel --max-workers=4 assembleDebug

# Build cache enabled by default (gradle.properties)
# Incremental compilation already enabled

# Skip unnecessary tasks
./gradlew assembleDebug -x lint -x test
```

### Smaller APK

- Release build uses R8 minification and resource shrinking
- Check: `app/build/outputs/apk/release/app-release-unsigned.apk` for size
- ProGuard rules in `app/proguard-rules.pro` are minimal; add more if needed

## Version Management

Current versions (in `build.gradle.kts` root file):

| Component | Version |
|-----------|---------|
| AGP | 8.13.2 |
| Kotlin | 2.2.21 |
| Gradle | 8.14.5 |
| Compose BOM | 2026.06.01 |
| compileSdk | 36 |
| minSdk | 26 |
| targetSdk | 36 |

To update, edit `build.gradle.kts` root file and re-sync.

## Next Steps

1. **Open in Android Studio** and sync Gradle
2. **Run the app**: `Shift+F10` (Run) or `./gradlew installDebug`
3. **Explore the code**: Start with `MainActivity.kt` and `FajerNavGraph.kt`
4. **Run tests**: `./gradlew test` and `./gradlew connectedAndroidTest`
5. **Generate reports**: `./gradlew lint`

---

For questions or issues, see README.md or refer to official documentation at https://developer.android.com/studio/build
