# FAJER WiFi Audit

**FAJER** is a professional, offline-first Android application for authorized Wi-Fi security auditing and laboratory simulation. It provides network discovery, password-strength analysis, and a safe local simulation engine—never accessing real Wi-Fi credentials or networks.

## Build verification status — read this first

This project's source was generated in a sandboxed environment with **no internet access** and no Android SDK installed (only a bare JDK 21). That environment could not download the Android Gradle Plugin, AndroidX/Compose/Room artifacts, or a Gradle distribution, so **`./gradlew assembleDebug` was never actually run, and no APK was produced or verified here.** What *was* done to compensate:

- Every Kotlin file was hand-reviewed for type/name consistency (every cross-file method call, field name, and constructor signature was traced back to its declaration).
- An automated sweep checked for duplicate top-level declarations, stale references to renamed/removed types, and every `R.string.*` reference against `strings.xml` — all came back clean.
- The Gradle wrapper's binary jar (`gradle/wrapper/gradle-wrapper.jar`) is intentionally **not** included, since it's a compiled artifact this environment couldn't fetch or produce correctly — see "First build" below for the one extra step this requires.

None of that is a substitute for a real compiler. The most likely first-build issues are minor: a library API that shifted slightly from the pinned version, or an import Android Studio's inspector flags. Budget for one normal "fix what the IDE underlines" pass.

### Getting a real, compiled APK
Pick one:
1. **Android Studio (recommended):** open the project folder directly. On first sync, Android Studio detects the missing wrapper jar and offers to generate it — accept that, let Gradle sync, then Run. This is the standard flow for any Gradle project and needs no extra setup.
2. **GitHub Actions:** push this project to a GitHub repo. `.github/workflows/android-ci.yml` is included and builds debug + release APKs, runs unit tests and lint, on a runner with full network and SDK access — no local setup needed at all. Download the APK from the workflow run's Artifacts.
3. **Local Gradle:** if you have Gradle installed, run `gradle wrapper --gradle-version 8.14.5` once inside the project root to generate `gradlew`/`gradlew.bat`, then use `./gradlew` as normal per the commands below.

## Features

### Network Discovery
- Scan for nearby Wi-Fi networks using official Android APIs
- Display network metadata: SSID, BSSID, RSSI, security type, channel
- Show signal strength and estimated distance indicators
- OUI/vendor lookup for access point manufacturers

### Wordlist Management
- Import plain-text wordlists from device storage
- Automatic analysis: line count, duplicates, character composition
- Password length distribution visualization
- Deduplicate and trim options for data cleaning
- Support for UTF-8, UTF-16, and ASCII encodings

### Local Audit Laboratory
Three safe simulation modes:

1. **Password Strength Analysis** — Score every candidate in a wordlist for entropy, patterns, and resistance to common attacks
2. **Offline Wordlist Simulation** — Run a wordlist against the built-in synthetic lab target to demonstrate audit engine speed and accuracy
3. **Known-Test-Credential Simulation** — Check whether a credential you already know appears in a wordlist

All testing is 100% local and never touches any real Wi-Fi access point.

### Audit Engine
- Coroutine-based, non-blocking candidate processing
- Real-time progress: processed count, rate (attempts/sec), ETA
- Pause, resume, and stop controls
- Result tracking: matched credential, attempt number, completion time

### History & Reports
- Persistent audit session storage using Room database
- TXT, CSV, JSON report generation (PDF support optional)
- Session filtering and search
- Detailed audit logs with timestamps

### Professional UI
- Material 3 Compose design system
- Dark and light theme support
- Arabic RTL layout support
- Responsive phone and tablet layouts
- Accessibility features: TalkBack, large text, high contrast

### Privacy & Security
- **Local-only processing**: No network requests, no cloud storage, no analytics
- **No credentials stored**: Only synthetic test data and user-owned wordlists
- **Open-source policy**: No cloud backends, no proprietary tracking
- Explicit authorization requirement for each audit session

## Architecture

### Clean Modular Design

```
com.fajer.wifiaudit/
├── core/                           # Framework-agnostic infrastructure
│   ├── common/                     # App-wide constants, result types
│   ├── model/                      # Core data structures
│   ├── permissions/                # Android permission abstraction
│   ├── security/                   # Audit engine, password strength
│   ├── storage/                    # Wordlist parsing, file I/O
│   └── ui/theme/                   # Material 3 theme, colors, typography
│
├── data/                           # Data layer (repositories, local DB)
│   ├── local/
│   │   ├── entities/               # Room entity definitions
│   │   ├── dao/                    # Database access objects
│   │   └── FajerDatabase.kt        # Room database configuration
│   ├── repository/                 # Repository implementations
│   └── wifi/                       # Android WifiManager integration
│
├── domain/                         # Business logic (use cases, interfaces)
│   ├── model/                      # Domain models (no Android imports)
│   ├── repository/                 # Repository interfaces
│   └── usecase/                    # Business logic operations
│
└── presentation/                   # UI layer (Compose screens, ViewModels)
    ├── navigation/                 # Navigation routes and graphs
    ├── dashboard/                  # Dashboard screen
    ├── scanner/                    # Networks scanner screen
    ├── network/                    # Network details screen
    ├── wordlist/                   # Wordlist management screens
    ├── audit/                      # Audit lab and run screens
    ├── history/                    # Audit history and details
    ├── reports/                    # Report generation screen
    ├── settings/                   # App settings
    ├── about/                      # About and privacy info
    └── common/                     # Shared UI components
```

### Technology Stack

| Component | Choice | Version |
|-----------|--------|---------|
| **Language** | Kotlin | 2.2.21 |
| **Build** | Gradle + AGP | 8.13.2 + 8.14.5 |
| **UI Framework** | Jetpack Compose | 2026.06.01 (BOM) |
| **Material Design** | Material 3 | Latest (via Compose BOM) |
| **Navigation** | Navigation Compose | 2.8.4 |
| **Local DB** | Room | 2.6.1 |
| **Async** | Coroutines | 1.9.0 |
| **State Management** | StateFlow, ViewModel | Lifecycle 2.8.7 |
| **Settings** | DataStore Preferences | 1.1.1 |
| **Testing** | JUnit 4, Compose UI Test, Turbine | Various stable versions |

### Data Persistence

- **Room Database (SQLite)**: Audit session history, settings cache
- **DataStore Preferences**: User preferences (theme, scan interval, etc.)
- **File Storage**: Imported wordlists, generated reports (via SAF)

### Permissions

- `ACCESS_WIFI_STATE` — Read Wi-Fi metadata (read-only)
- `CHANGE_WIFI_STATE` — Detect Wi-Fi state changes
- `ACCESS_NETWORK_STATE` — Check connectivity status
- `ACCESS_FINE_LOCATION` (Android 12 and below) — Wi-Fi scan results
- `NEARBY_WIFI_DEVICES` (Android 13+) — Wi-Fi scan results (location-exempt)

The app never requests: Internet, camera, microphone, contacts, SMS, broad storage access.

## Setup & Build

### Requirements

- **Android Studio** 2024.3.1 Meerkat or later (supports Kotlin 2.2, AGP 8.13, Android 16 SDK)
- **Android SDK** 36 (Android 16 / Baklava)
- **JDK** 17 or later
- **Gradle** 8.14.5 (managed by wrapper)

### Build Instructions

1. **Clone and open in Android Studio:**
   ```bash
   git clone <repo-url>
   cd FajerWiFiAudit
   # Open in Android Studio
   ```

2. **Build the debug APK:**
   ```bash
   ./gradlew assembleDebug
   # Output: app/build/outputs/apk/debug/app-debug.apk
   ```

3. **Build the release APK (unsigned):**
   ```bash
   ./gradlew assembleRelease
   # Output: app/build/outputs/apk/release/app-release-unsigned.apk
   ```

4. **Run unit tests:**
   ```bash
   ./gradlew test
   ```

5. **Run instrumented tests:**
   ```bash
   ./gradlew connectedAndroidTest
   ```

6. **Run lint checks:**
   ```bash
   ./gradlew lint
   ```

### Running on Device/Emulator

```bash
# Install and launch
./gradlew installDebug
adb shell am start -n com.fajer.wifiaudit.debug/com.fajer.wifiaudit.MainActivity
```

## Usage

### Scanning Wi-Fi Networks

1. Navigate to **Networks** tab
2. Grant location/Wi-Fi permissions if prompted
3. Tap **Scan** to discover nearby networks
4. Tap a network for detailed information (RSSI, channel, capabilities)
5. Tap **Add to Lab** to add it to your local testing directory

### Importing Wordlists

1. Navigate to **Wordlists** tab
2. Tap the **+** button or "Import Wordlist"
3. Select a plain-text file from your device
4. The app analyzes the file automatically (line count, duplicates, character composition)
5. Tap a wordlist to see detailed statistics and character distribution

### Running an Audit

1. Navigate to **Audits** (or tap "New Audit" from Dashboard)
2. Enter an audit name
3. Select a target network from your lab
4. Choose a wordlist
5. Select a simulation mode
6. **IMPORTANT:** Check "I confirm I own this network or have authorization to test it"
7. Tap **Create Audit**
8. Watch real-time progress: processed count, rate, ETA
9. Pause, resume, or stop at any time
10. View results: matched, no match, or stopped early

### Generating Reports

1. Navigate to **Reports**
2. Select a completed audit session
3. Choose a format: TXT, CSV, JSON, or PDF
4. Save via Storage Access Framework (SAF)

## Localization

The app is built for English and Arabic with full RTL (right-to-left) layout support for Arabic.

### Adding Languages

Edit the following files:

- `app/src/main/res/values/strings.xml` — English (default)
- `app/src/main/res/values-ar/strings.xml` — Arabic
- `app/src/main/res/xml/locales_config.xml` — Per-app language list

Then rebuild.

## Testing

### Unit Tests
```bash
./gradlew test
```

Tests cover:
- Wordlist parsing (UTF-8, CRLF, deduplication)
- Audit engine simulation
- Password strength analysis
- Repository operations

### UI Tests (Compose)
```bash
./gradlew connectedAndroidTest
```

Tests cover:
- Navigation flows
- Screen rendering
- User interactions

### Lint & Detekt
```bash
./gradlew lint
```

## Security & Privacy Policy

### What FAJER Does NOT Do

❌ **Never submits passwords to any network**  
❌ **Never performs real authentication attacks**  
❌ **Never sends data to external servers**  
❌ **Never uses analytics or tracking SDKs**  
❌ **Never stores real credentials** (only synthetic lab data)  
❌ **Never accesses location** (location permission used only for Wi-Fi scan results on older Android)  

### What FAJER Does

✅ **Reads public Wi-Fi broadcast metadata** via `WifiManager.scanResults()`  
✅ **Analyzes wordlists locally** for strength and patterns  
✅ **Runs local simulation engine** against synthetic test targets  
✅ **Stores audit history locally** in encrypted Room database  
✅ **Respects user authorizations** via explicit confirmation checkbox  

### Authorized Use Only

This application is **intended exclusively for**:
- Testing networks you own
- Testing networks where you have explicit, written authorization
- Educational and laboratory environments
- Security research and professional auditing

Unauthorized network testing is illegal in most jurisdictions. Users assume all legal responsibility for their use of this application.

## Known Limitations

1. **No packet injection** — Cannot perform real WPA handshake capture or brute-force attacks
2. **No PCAP/packet analysis** — Wi-Fi scanning only, no packet-level inspection
3. **Simulated only** — All password testing is against a synthetic lab target
4. **Large wordlist memory** — Wordlists over 1M lines may require significant RAM
5. **No cloud sync** — All data remains on-device; no backup or cross-device access

## Troubleshooting

| Issue | Solution |
|-------|----------|
| "No Wi-Fi networks found" | Enable Wi-Fi and location services; on Android 12 and below, location services must be on even with new permissions |
| "Permission denied" | Grant Wi-Fi/location permissions in system settings → Apps → FAJER → Permissions |
| "Wordlist import fails" | Ensure file is plain text (`.txt`) with one candidate per line; check for unusual encodings (defaults: UTF-8, UTF-16, ASCII) |
| "Audit doesn't start" | Verify authorization checkbox is checked; ensure wordlist has at least one entry |
| "Slow wordlist analysis" | Large files (>500K lines) process on a background thread; UI remains responsive |

## Contributing

This is a reference implementation of an authorized Wi-Fi auditing application. Contributions should focus on:

- UI/UX improvements
- Additional report formats
- Language translations
- Performance optimizations
- Test coverage

Changes that add real-network attack functionality will not be accepted.

## License

Copyright © 2026 FAJER Contributors

Licensed under the [MIT License](LICENSE) — see LICENSE file for details.

## Disclaimer

**FAJER is provided as-is for authorized security testing only.** Users are entirely responsible for compliance with all applicable laws and regulations in their jurisdiction. Unauthorized network testing is illegal in most countries. The authors assume no liability for misuse or damage.

---

**Built with ❤️ for security researchers, penetration testers, and network administrators.**
