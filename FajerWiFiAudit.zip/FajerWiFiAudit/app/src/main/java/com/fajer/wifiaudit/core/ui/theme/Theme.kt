package com.fajer.wifiaudit.core.ui.theme

import androidx.compose.foundation.background
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.material3.ColorScheme as M3ColorScheme

private val DarkColorScheme = darkColorScheme(
    primary = FajerColors.Accent,
    onPrimary = FajerColors.OnAccent,
    secondary = FajerColors.AccentDim,
    tertiary = FajerColors.Info,
    background = FajerColors.DarkBackground,
    surface = FajerColors.DarkSurface,
    surfaceVariant = FajerColors.DarkSurfaceVariant,
    outline = FajerColors.DarkOutline,
    error = FajerColors.Error,
    onBackground = FajerColors.OnDarkBackground,
    onSurface = FajerColors.OnDarkBackground,
)

private val LightColorScheme = lightColorScheme(
    primary = FajerColors.Accent,
    onPrimary = FajerColors.OnAccent,
    secondary = FajerColors.AccentDim,
    tertiary = FajerColors.Info,
    background = FajerColors.LightBackground,
    surface = FajerColors.LightSurface,
    surfaceVariant = FajerColors.LightSurfaceVariant,
    outline = FajerColors.LightOutline,
    error = FajerColors.Error,
    onBackground = FajerColors.OnLightBackground,
    onSurface = FajerColors.OnLightBackground,
)

@Composable
fun FajerTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit,
) {
    val colorScheme = when {
        darkTheme -> DarkColorScheme
        else -> LightColorScheme
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = FajerTypography,
        shapes = FajerShapes,
        content = content,
    )
}
