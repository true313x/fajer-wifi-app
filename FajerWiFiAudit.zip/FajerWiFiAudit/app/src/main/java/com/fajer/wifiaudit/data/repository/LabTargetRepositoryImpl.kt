package com.fajer.wifiaudit.data.repository

import com.fajer.wifiaudit.core.common.AppResult
import com.fajer.wifiaudit.core.common.FajerConstants
import com.fajer.wifiaudit.data.local.dao.LabTargetDao
import com.fajer.wifiaudit.data.local.entities.LabTargetEntity
import com.fajer.wifiaudit.domain.model.LabTarget
import com.fajer.wifiaudit.domain.model.WifiNetwork
import com.fajer.wifiaudit.domain.repository.LabTargetRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext

class LabTargetRepositoryImpl(
    private val dao: LabTargetDao,
) : LabTargetRepository {

    override fun observeTargets(): Flow<List<LabTarget>> =
        dao.observeAll().map { entities -> entities.map { it.toDomain() } }

    override suspend fun addFromNetwork(network: WifiNetwork): AppResult<LabTarget> =
        withContext(Dispatchers.IO) {
            if (dao.countByBssid(network.bssid) > 0) {
                return@withContext AppResult.Error("This network is already in your lab")
            }
            val target = LabTarget(
                ssid = network.ssid,
                bssid = network.bssid,
                securityType = network.securityType,
                // The target's stored credential is always the shared synthetic sample —
                // a real password is never read from, or written to, the network itself.
                // A user-supplied "known" credential is entered per-audit instead (see
                // Known-Test-Credential Simulation) and is never persisted against the target.
                syntheticCredential = FajerConstants.SAMPLE_LAB_SYNTHETIC_CREDENTIAL,
                isBuiltInSample = false,
                addedAtEpochMillis = System.currentTimeMillis(),
            )
            val id = dao.insert(LabTargetEntity.fromDomain(target))
            AppResult.Success(target.copy(id = id))
        }

    override suspend fun remove(id: Long): AppResult<Unit> = withContext(Dispatchers.IO) {
        val target = dao.getById(id) ?: return@withContext AppResult.Success(Unit)
        dao.delete(target)
        AppResult.Success(Unit)
    }

    override suspend fun ensureSampleTargetExists(): LabTarget = withContext(Dispatchers.IO) {
        dao.getSampleTarget()?.toDomain() ?: run {
            val sample = LabTarget(
                ssid = FajerConstants.SAMPLE_LAB_SSID,
                bssid = FajerConstants.SAMPLE_LAB_BSSID,
                securityType = com.fajer.wifiaudit.domain.model.SecurityType.WPA2,
                syntheticCredential = FajerConstants.SAMPLE_LAB_SYNTHETIC_CREDENTIAL,
                isBuiltInSample = true,
                addedAtEpochMillis = System.currentTimeMillis(),
            )
            val id = dao.insert(LabTargetEntity.fromDomain(sample))
            sample.copy(id = id)
        }
    }
}
