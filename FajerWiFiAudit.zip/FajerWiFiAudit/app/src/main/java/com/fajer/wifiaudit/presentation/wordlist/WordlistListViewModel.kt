package com.fajer.wifiaudit.presentation.wordlist

import android.content.Context
import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.fajer.wifiaudit.core.common.AppResult
import com.fajer.wifiaudit.core.storage.WordlistFileReader
import com.fajer.wifiaudit.domain.model.Wordlist
import com.fajer.wifiaudit.domain.repository.SettingsRepository
import com.fajer.wifiaudit.domain.repository.WordlistRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class WordlistsUiState(
    val wordlists: List<Wordlist> = emptyList(),
    val isImporting: Boolean = false,
    val errorMessage: String? = null,
)

class WordlistListViewModel(
    private val wordlistRepository: WordlistRepository,
    private val settingsRepository: SettingsRepository,
) : ViewModel() {

    private val isImporting = MutableStateFlow(false)
    private val errorMessage = MutableStateFlow<String?>(null)

    val uiState: StateFlow<WordlistsUiState> = combine(
        wordlistRepository.observeWordlists(),
        isImporting,
        errorMessage,
    ) { wordlists, importing, error ->
        WordlistsUiState(wordlists.sortedByDescending { it.importedAtEpochMillis }, importing, error)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), WordlistsUiState())

    fun importFrom(context: Context, uri: Uri) {
        viewModelScope.launch {
            isImporting.value = true
            errorMessage.value = null
            val displayName = WordlistFileReader.queryDisplayName(context, uri) ?: uri.lastPathSegment ?: "Wordlist"
            val preferences = settingsRepository.observeSettings().first().wordlistPreferences
            when (val result = wordlistRepository.import(uri.toString(), displayName, preferences)) {
                is AppResult.Error -> errorMessage.value = result.message
                is AppResult.Success -> Unit
            }
            isImporting.value = false
        }
    }

    fun installSample() {
        viewModelScope.launch {
            wordlistRepository.installSampleWordlist()
        }
    }

    fun delete(id: Long) {
        viewModelScope.launch { wordlistRepository.delete(id) }
    }
}
