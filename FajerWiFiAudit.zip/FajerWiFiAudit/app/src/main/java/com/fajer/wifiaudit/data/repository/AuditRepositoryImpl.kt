package com.fajer.wifiaudit.data.repository

import com.fajer.wifiaudit.core.common.AppResult
import com.fajer.wifiaudit.data.local.dao.AuditLogDao
import com.fajer.wifiaudit.data.local.dao.AuditSessionDao
import com.fajer.wifiaudit.data.local.entities.AuditLogEntity
import com.fajer.wifiaudit.data.local.entities.AuditSessionEntity
import com.fajer.wifiaudit.domain.model.AuditLogEntry
import com.fajer.wifiaudit.domain.model.AuditLogEvent
import com.fajer.wifiaudit.domain.model.AuditSession
import com.fajer.wifiaudit.domain.repository.AuditRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext

class AuditRepositoryImpl(
    private val sessionDao: AuditSessionDao,
    private val logDao: AuditLogDao,
) : AuditRepository {

    override fun observeSessions(): Flow<List<AuditSession>> =
        sessionDao.observeAll().map { entities -> entities.map { it.toDomain() } }

    override fun observeSession(id: Long): Flow<AuditSession?> =
        sessionDao.observeById(id).map { it?.toDomain() }

    override suspend fun createSession(session: AuditSession): AppResult<AuditSession> =
        withContext(Dispatchers.IO) {
            try {
                val id = sessionDao.insert(AuditSessionEntity.fromDomain(session))
                AppResult.Success(session.copy(id = id))
            } catch (e: Exception) {
                AppResult.Error(e.message ?: "Could not create audit session", e)
            }
        }

    override suspend fun updateSession(session: AuditSession): AppResult<Unit> =
        withContext(Dispatchers.IO) {
            try {
                sessionDao.update(AuditSessionEntity.fromDomain(session))
                AppResult.Success(Unit)
            } catch (e: Exception) {
                AppResult.Error(e.message ?: "Could not update audit session", e)
            }
        }

    override suspend fun deleteSession(id: Long): AppResult<Unit> = withContext(Dispatchers.IO) {
        sessionDao.deleteById(id)
        AppResult.Success(Unit)
    }

    override fun observeLogs(auditSessionId: Long?): Flow<List<AuditLogEntry>> {
        val flow = if (auditSessionId == null) {
            logDao.observeGlobal(limit = 200)
        } else {
            logDao.observeForSession(auditSessionId)
        }
        return flow.map { entities -> entities.map { it.toDomain() } }
    }

    override suspend fun log(event: AuditLogEvent, detail: String, auditSessionId: Long?) {
        withContext(Dispatchers.IO) {
            logDao.insert(
                AuditLogEntity(
                    auditSessionId = auditSessionId,
                    event = event.name,
                    detail = detail,
                    timestampEpochMillis = System.currentTimeMillis(),
                )
            )
        }
    }
}
