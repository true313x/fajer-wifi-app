package com.fajer.wifiaudit.core.ui.theme

import androidx.compose.ui.graphics.Color

// Deep, graphite base — professional security tool aesthetic
object FajerColors {
    // Dark mode (primary)
    val DarkBackground = Color(0xFF12151A)
    val DarkSurface = Color(0xFF1A1D24)
    val DarkSurfaceVariant = Color(0xFF252933)
    val DarkOutline = Color(0xFF3D4452)
    val DarkScrim = Color(0xFF000000)

    // Light mode
    val LightBackground = Color(0xFFFBFBFB)
    val LightSurface = Color(0xFFFFFFFF)
    val LightSurfaceVariant = Color(0xFFF5F5F5)
    val LightOutline = Color(0xFFB0B0B0)
    val LightScrim = Color(0xFFFFFFFF)

    // Primary brand accent — phosphor amber, vibrant but restrained
    val Accent = Color(0xFFE0A94A)
    val AccentDim = Color(0xFFA67C2E)
    val AccentBright = Color(0xFFFFC966)

    // Semantic palette — never use pure red/green, use these
    val Success = Color(0xFF4CAF50)
    val Warning = Color(0xFFFFC107)
    val Error = Color(0xFFF44336)
    val Info = Color(0xFF2196F3)

    // Text and feedback
    val OnDarkBackground = Color(0xFFE8E8E8)
    val OnLightBackground = Color(0xFF212121)
    val OnAccent = Color(0xFF12151A)
    val TextSecondary = Color(0xFF9CA3AF)
    val TextHint = Color(0xFF757575)
}
