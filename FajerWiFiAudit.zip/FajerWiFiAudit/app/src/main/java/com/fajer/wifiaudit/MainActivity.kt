package com.fajer.wifiaudit

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import com.fajer.wifiaudit.core.ui.theme.FajerTheme
import com.fajer.wifiaudit.presentation.navigation.FajerNavGraph

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        installSplashScreen()
        super.onCreate(savedInstanceState)

        setContent {
            FajerTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                ) {
                    FajerNavGraph()
                }
            }
        }
    }
}
