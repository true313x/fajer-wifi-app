package com.fajer.wifiaudit.presentation.scanner

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import androidx.navigation.NavHostController
import com.fajer.wifiaudit.R
import com.fajer.wifiaudit.core.ui.components.EmptyState
import com.fajer.wifiaudit.core.ui.components.SecurityBadge
import com.fajer.wifiaudit.core.ui.components.SignalIndicator
import com.fajer.wifiaudit.domain.model.WifiNetwork
import com.fajer.wifiaudit.presentation.common.currentAppContainer
import com.fajer.wifiaudit.presentation.navigation.FajerRoute

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NetworksScreen(navController: NavHostController) {
    val container = currentAppContainer()
    val viewModel: NetworkListViewModel = viewModel(
        factory = viewModelFactory { initializer { NetworkListViewModel(container.wifiRepository) } }
    )
    val state by viewModel.uiState.collectAsStateWithLifecycle()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(stringResource(R.string.networks_title)) },
                actions = {
                    IconButton(onClick = { viewModel.scan() }, enabled = !state.isScanning) {
                        Icon(Icons.Default.Refresh, contentDescription = stringResource(R.string.networks_scan))
                    }
                },
            )
        },
    ) { innerPadding ->
        Column(modifier = Modifier.fillMaxSize().padding(innerPadding)) {
            when {
                !state.permissionState.hasScanPermission -> {
                    EmptyState(
                        title = stringResource(R.string.permission_rationale_title),
                        body = stringResource(R.string.permission_rationale_body),
                        modifier = Modifier.fillMaxSize(),
                    )
                }

                state.isScanning && state.networks.isEmpty() -> {
                    Column(
                        modifier = Modifier.fillMaxSize().padding(32.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center,
                    ) {
                        CircularProgressIndicator()
                        Text(
                            text = stringResource(R.string.networks_scanning),
                            modifier = Modifier.padding(top = 12.dp),
                        )
                    }
                }

                state.networks.isEmpty() -> {
                    EmptyState(
                        title = stringResource(R.string.networks_empty_title),
                        body = state.errorMessage ?: stringResource(R.string.networks_empty_body),
                        actionLabel = stringResource(R.string.networks_empty_action),
                        onAction = { viewModel.scan() },
                        modifier = Modifier.fillMaxSize(),
                    )
                }

                else -> {
                    LazyColumn(
                        contentPadding = PaddingValues(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp),
                    ) {
                        items(state.networks, key = { it.bssid }) { network ->
                            NetworkRow(network) {
                                navController.navigate(
                                    FajerRoute.networkDetails(network.bssid)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun NetworkRow(network: WifiNetwork, onClick: () -> Unit) {
    Card(
        onClick = onClick,
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
    ) {
        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text(
                    text = network.ssid.ifBlank { "(hidden network)" },
                    style = MaterialTheme.typography.titleSmall,
                )
                SignalIndicator(percent = network.signalPercent)
            }
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text(
                    text = "${network.bssid} · Ch ${network.channel}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                SecurityBadge(network.securityType)
            }
        }
    }
}
