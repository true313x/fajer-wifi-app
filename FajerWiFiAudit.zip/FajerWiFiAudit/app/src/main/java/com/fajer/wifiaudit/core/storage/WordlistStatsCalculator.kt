package com.fajer.wifiaudit.core.storage

import com.fajer.wifiaudit.domain.model.LengthBucket
import com.fajer.wifiaudit.domain.model.WordlistPreferences
import com.fajer.wifiaudit.domain.model.WordlistStats

/**
 * Computes [WordlistStats] from a single streaming pass over a line sequence. Deliberately
 * framework-free (no `android.*` import) so it can be exercised with plain JVM unit tests —
 * see `WordlistParsingTest`.
 *
 * Memory note: exact duplicate counting requires remembering every distinct line seen so far,
 * so peak memory is proportional to the number of *unique* entries, not total file size. For
 * wordlists in the hundreds of thousands to low millions of lines this is a reasonable
 * trade-off; callers should surface [com.fajer.wifiaudit.core.common.FajerConstants.LARGE_WORDLIST_LINE_WARNING_THRESHOLD]
 * as a heads-up rather than trying to avoid the pass entirely.
 */
object WordlistStatsCalculator {

    fun compute(lines: Sequence<String>, preferences: WordlistPreferences): WordlistStats {
        var totalLines = 0
        var emptyRemoved = 0
        var lengthSum = 0L
        var minLength = Int.MAX_VALUE
        var maxLength = 0
        var numericOnly = 0
        var alphabeticOnly = 0
        var mixed = 0
        var specialCharacter = 0
        var unicode = 0
        val lengthDistribution = LinkedHashMap<LengthBucket, Int>().apply {
            LengthBucket.entries.forEach { put(it, 0) }
        }
        val seen = HashSet<String>()

        for (rawLine in lines) {
            totalLines++
            val line = if (preferences.trimWhitespace) rawLine.trim() else rawLine

            if (line.isEmpty()) {
                if (preferences.ignoreEmptyLines) {
                    emptyRemoved++
                    continue
                }
            }

            seen.add(line)

            val length = line.length
            lengthSum += length
            if (length < minLength) minLength = length
            if (length > maxLength) maxLength = length
            lengthDistribution.merge(LengthBucket.forLength(length), 1, Int::plus)

            when (classify(line)) {
                Classification.UNICODE -> unicode++
                Classification.NUMERIC -> numericOnly++
                Classification.ALPHABETIC -> alphabeticOnly++
                Classification.MIXED -> mixed++
                Classification.SPECIAL -> specialCharacter++
            }
        }

        val consideredLines = totalLines - emptyRemoved
        val uniqueLines = seen.size
        val duplicateCount = (consideredLines - uniqueLines).coerceAtLeast(0)

        return WordlistStats(
            totalLines = totalLines,
            uniqueLines = uniqueLines,
            duplicateCount = duplicateCount,
            emptyLinesRemoved = emptyRemoved,
            averageLength = if (consideredLines > 0) lengthSum.toDouble() / consideredLines else 0.0,
            minimumLength = if (minLength == Int.MAX_VALUE) 0 else minLength,
            maximumLength = maxLength,
            numericOnlyCount = numericOnly,
            alphabeticOnlyCount = alphabeticOnly,
            mixedCount = mixed,
            specialCharacterCount = specialCharacter,
            unicodeCount = unicode,
            lengthDistribution = lengthDistribution
        )
    }

    private enum class Classification { UNICODE, NUMERIC, ALPHABETIC, MIXED, SPECIAL }

    /** Mutually-exclusive classification, checked in this priority order: a line with any
     *  non-ASCII character is Unicode even if it also contains digits or symbols; otherwise
     *  digits-only and letters-only are their own buckets; a pure letters+digits combination
     *  is Mixed; anything else containing ASCII punctuation is Special-character. */
    private fun classify(line: String): Classification = when {
        line.any { it.code > 127 } -> Classification.UNICODE
        line.all { it in '0'..'9' } -> Classification.NUMERIC
        line.all { it.isAsciiLetter() } -> Classification.ALPHABETIC
        line.all { it.isAsciiLetter() || it in '0'..'9' } -> Classification.MIXED
        else -> Classification.SPECIAL
    }

    private fun Char.isAsciiLetter(): Boolean = this in 'a'..'z' || this in 'A'..'Z'
}
