package com.fajer.wifiaudit.domain.model

/**
 * The three safe audit modes. None of these ever opens a network connection or attempts
 * authentication against a real access point:
 *
 * - [PASSWORD_STRENGTH_ANALYSIS] scores every candidate in a wordlist for strength.
 * - [OFFLINE_WORDLIST_SIMULATION] runs a wordlist against the built-in synthetic lab target
 *   ([com.fajer.wifiaudit.core.common.FajerConstants.SAMPLE_LAB_SYNTHETIC_CREDENTIAL]) purely
 *   to demonstrate the engine's mechanics (progress, rate, ETA, match detection).
 * - [KNOWN_TEST_CREDENTIAL_SIMULATION] checks whether a credential the user already knows
 *   (e.g. their own lab router's password) appears in a wordlist, and how quickly a naive
 *   wordlist run would reach it.
 */
enum class AuditMode {
    PASSWORD_STRENGTH_ANALYSIS,
    OFFLINE_WORDLIST_SIMULATION,
    KNOWN_TEST_CREDENTIAL_SIMULATION
}

enum class AuditStatus {
    IDLE,
    PREPARING,
    RUNNING,
    PAUSED,
    COMPLETED,
    STOPPED,
    FAILED
}

data class AuditSession(
    val id: Long = 0,
    val name: String,
    val targetSsid: String,
    val targetBssid: String,
    val wordlistId: Long,
    val wordlistName: String,
    val mode: AuditMode,
    val status: AuditStatus,
    val processed: Int,
    val total: Int,
    val durationMillis: Long,
    val result: AuditOutcome,
    val authorizationConfirmed: Boolean,
    val notes: String,
    val createdAtEpochMillis: Long,
    val completedAtEpochMillis: Long?
)

/** Live progress snapshot published by [com.fajer.wifiaudit.domain.usecase.AuditEngine]. */
data class AuditProgress(
    val processed: Int,
    val total: Int,
    val ratePerSecond: Double,
    val elapsedMillis: Long,
    val etaMillis: Long?,
    val currentCandidate: String
) {
    val percentage: Float
        get() = if (total <= 0) 0f else (processed.toFloat() / total.toFloat()).coerceIn(0f, 1f)

    companion object {
        val ZERO = AuditProgress(0, 0, 0.0, 0L, null, "")
    }
}

sealed interface AuditOutcome {
    data object Pending : AuditOutcome
    data class Matched(val matchedAtIndex: Int, val candidate: String) : AuditOutcome
    data object NoMatch : AuditOutcome
    data class StrengthSummary(val distribution: Map<PasswordStrength, Int>) : AuditOutcome
    data class Stopped(val processedBeforeStop: Int) : AuditOutcome
    data class Failed(val reason: String) : AuditOutcome
}

enum class AuditLogEvent {
    SCAN_STARTED,
    SCAN_COMPLETED,
    WORDLIST_IMPORTED,
    WORDLIST_ANALYZED,
    AUDIT_CREATED,
    AUDIT_STARTED,
    AUDIT_PAUSED,
    AUDIT_RESUMED,
    AUDIT_STOPPED,
    AUDIT_COMPLETED,
    REPORT_CREATED
}

data class AuditLogEntry(
    val id: Long = 0,
    val auditSessionId: Long?,
    val event: AuditLogEvent,
    val detail: String,
    val timestampEpochMillis: Long
)
