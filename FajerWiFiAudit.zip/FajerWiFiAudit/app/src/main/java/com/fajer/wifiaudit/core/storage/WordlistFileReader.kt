package com.fajer.wifiaudit.core.storage

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import java.io.BufferedReader
import java.io.InputStreamReader
import java.nio.charset.Charset

/**
 * Reads a wordlist file selected via `ACTION_OPEN_DOCUMENT` a line at a time. Every read opens
 * its own [android.content.ContentResolver] stream and closes it when the sequence is fully
 * consumed or the caller stops iterating (e.g. audit paused/stopped) — nothing is ever
 * buffered into a single giant `String`.
 */
object WordlistFileReader {

    private const val SNIFF_BYTES = 4

    fun queryDisplayName(context: Context, uri: Uri): String? = runCatchingNull {
        context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
            ?.use { cursor ->
                val nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (cursor.moveToFirst() && nameIndex >= 0) cursor.getString(nameIndex) else null
            }
    }

    fun querySize(context: Context, uri: Uri): Long = runCatchingNull {
        context.contentResolver.query(uri, arrayOf(OpenableColumns.SIZE), null, null, null)
            ?.use { cursor ->
                val sizeIndex = cursor.getColumnIndex(OpenableColumns.SIZE)
                if (cursor.moveToFirst() && sizeIndex >= 0) cursor.getLong(sizeIndex) else null
            }
    } ?: -1L

    /**
     * BOM-based encoding detection: UTF-8, UTF-16LE and UTF-16BE byte-order marks are
     * recognized explicitly; anything without a BOM is treated as UTF-8, which also correctly
     * reads plain ASCII. Legacy 8-bit encodings that lack a BOM are a known limitation — the
     * UI surfaces the detected encoding so the user can tell.
     */
    fun detectCharset(context: Context, uri: Uri): Charset {
        val head = context.contentResolver.openInputStream(uri)?.use { input ->
            val buffer = ByteArray(SNIFF_BYTES)
            val read = input.read(buffer)
            if (read <= 0) ByteArray(0) else buffer.copyOf(read)
        } ?: return Charsets.UTF_8

        return when {
            head.size >= 3 && head[0] == 0xEF.toByte() && head[1] == 0xBB.toByte() && head[2] == 0xBF.toByte() ->
                Charsets.UTF_8
            head.size >= 2 && head[0] == 0xFF.toByte() && head[1] == 0xFE.toByte() ->
                Charsets.UTF_16LE
            head.size >= 2 && head[0] == 0xFE.toByte() && head[1] == 0xFF.toByte() ->
                Charsets.UTF_16BE
            else -> Charsets.UTF_8
        }
    }

    /**
     * Streams every line, normalizing CRLF/CR/LF to logical lines. The returned [Sequence]
     * opens the underlying stream lazily on first iteration and closes it automatically when
     * exhausted or when the caller stops collecting (e.g. cancels a coroutine mid-scan).
     */
    fun lineSequence(context: Context, uri: Uri, charset: Charset = detectCharset(context, uri)): Sequence<String> =
        sequence {
            val input = context.contentResolver.openInputStream(uri) ?: return@sequence
            BufferedReader(InputStreamReader(input, charset)).use { reader ->
                while (true) {
                    // BufferedReader.readLine() already treats \n, \r and \r\n as line
                    // terminators, which is exactly the CRLF/CR/LF normalization we need.
                    val line = reader.readLine() ?: break
                    yield(line)
                }
            }
        }

    private inline fun <T> runCatchingNull(block: () -> T?): T? = try {
        block()
    } catch (_: Exception) {
        null
    }
}
