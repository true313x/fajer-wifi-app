package com.fajer.wifiaudit.core.utils

import com.fajer.wifiaudit.domain.model.SecurityType

/**
 * Classifies the security of a Wi-Fi network from the capability string Android's scanner
 * already returns (e.g. `[WPA2-PSK-CCMP+TKIP][ESS]`). Deliberately conservative: if the
 * string does not clearly indicate a known protocol, we report [SecurityType.UNKNOWN] rather
 * than guess — the spec is explicit that we must never claim a security type we can't
 * reliably determine.
 */
object SecurityClassifier {

    fun classify(capabilities: String): SecurityType {
        if (capabilities.isBlank()) return SecurityType.UNKNOWN
        val caps = capabilities.uppercase()

        return when {
            // SAE (Simultaneous Authentication of Equals) is WPA3's key exchange.
            caps.contains("WPA3") || caps.contains("SAE") -> SecurityType.WPA3
            // RSN is the 802.11 standard name that WPA2 is built on; some OEM firmware
            // reports it instead of the literal string "WPA2".
            caps.contains("WPA2") || caps.contains("RSN") -> SecurityType.WPA2
            caps.contains("WPA") -> SecurityType.WPA
            caps.contains("WEP") -> SecurityType.WEP
            caps.contains("ESS") || caps.contains("IBSS") -> SecurityType.OPEN
            else -> SecurityType.UNKNOWN
        }
    }
}
