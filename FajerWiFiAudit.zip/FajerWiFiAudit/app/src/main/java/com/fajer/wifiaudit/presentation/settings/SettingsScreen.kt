package com.fajer.wifiaudit.presentation.settings

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import androidx.navigation.NavHostController
import com.fajer.wifiaudit.R
import com.fajer.wifiaudit.core.model.ThemeMode
import com.fajer.wifiaudit.core.ui.components.FajerSectionCard
import com.fajer.wifiaudit.presentation.common.currentAppContainer

@Composable
fun SettingsScreen(navController: NavHostController) {
    val container = currentAppContainer()
    val viewModel: SettingsViewModel = viewModel(
        factory = viewModelFactory { initializer { SettingsViewModel(container.settingsRepository) } }
    )
    val settings by viewModel.settings.collectAsStateWithLifecycle()

    Scaffold(
        topBar = { TopAppBar(title = { Text(stringResource(R.string.settings_title)) }) },
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            FajerSectionCard(title = stringResource(R.string.settings_section_appearance)) {
                ThemeMode.entries.forEach { mode ->
                    SettingsRadioRow(
                        label = mode.name,
                        selected = settings.themeMode == mode,
                        onSelect = { viewModel.setThemeMode(mode) },
                    )
                }
            }

            FajerSectionCard(title = stringResource(R.string.settings_section_scanning)) {
                SettingsSwitchRow(
                    label = stringResource(R.string.settings_include_hidden_ssids),
                    checked = settings.includeHiddenSsids,
                    onCheckedChange = viewModel::setIncludeHiddenSsids,
                )
            }

            FajerSectionCard(title = stringResource(R.string.settings_section_wordlist)) {
                SettingsSwitchRow(
                    label = stringResource(R.string.wordlist_option_trim_whitespace),
                    checked = settings.wordlistPreferences.trimWhitespace,
                    onCheckedChange = viewModel::setTrimWhitespace,
                )
                SettingsSwitchRow(
                    label = stringResource(R.string.wordlist_option_deduplicate),
                    checked = settings.wordlistPreferences.deduplicate,
                    onCheckedChange = viewModel::setDeduplicate,
                )
                SettingsSwitchRow(
                    label = stringResource(R.string.wordlist_option_ignore_empty_lines),
                    checked = settings.wordlistPreferences.ignoreEmptyLines,
                    onCheckedChange = viewModel::setIgnoreEmptyLines,
                )
            }

            FajerSectionCard(title = stringResource(R.string.settings_section_audit)) {
                SettingsSwitchRow(
                    label = stringResource(R.string.settings_confirmation_requirement),
                    checked = settings.requireAuthorizationConfirmation,
                    onCheckedChange = viewModel::setRequireAuthorizationConfirmation,
                )
            }

            FajerSectionCard(title = stringResource(R.string.settings_section_privacy)) {
                Text("• " + stringResource(R.string.privacy_local_only), style = MaterialTheme.typography.bodySmall)
                Text("• " + stringResource(R.string.privacy_no_analytics), style = MaterialTheme.typography.bodySmall)
                Text("• " + stringResource(R.string.privacy_no_telemetry), style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}

@Composable
private fun SettingsRadioRow(label: String, selected: Boolean, onSelect: () -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        RadioButton(selected = selected, onClick = onSelect)
        Text(label, style = MaterialTheme.typography.bodyMedium)
    }
}

@Composable
private fun SettingsSwitchRow(label: String, checked: Boolean, onCheckedChange: (Boolean) -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(label, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f))
        Switch(checked = checked, onCheckedChange = onCheckedChange)
    }
}
