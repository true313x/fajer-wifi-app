package com.fajer.wifiaudit.presentation.settings

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.fajer.wifiaudit.core.model.ThemeMode
import com.fajer.wifiaudit.domain.model.AuditMode
import com.fajer.wifiaudit.domain.repository.AppSettings
import com.fajer.wifiaudit.domain.repository.SettingsRepository
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class SettingsViewModel(private val settingsRepository: SettingsRepository) : ViewModel() {

    val settings: StateFlow<AppSettings> = settingsRepository.observeSettings()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), AppSettings())

    fun setThemeMode(mode: ThemeMode) = updateSettings { it.copy(themeMode = mode) }
    fun setScanInterval(seconds: Int) = updateSettings { it.copy(scanIntervalSeconds = seconds) }
    fun setIncludeHiddenSsids(value: Boolean) = updateSettings { it.copy(includeHiddenSsids = value) }
    fun setTrimWhitespace(value: Boolean) = updateSettings { it.copy(wordlistPreferences = it.wordlistPreferences.copy(trimWhitespace = value)) }
    fun setDeduplicate(value: Boolean) = updateSettings { it.copy(wordlistPreferences = it.wordlistPreferences.copy(deduplicate = value)) }
    fun setIgnoreEmptyLines(value: Boolean) = updateSettings { it.copy(wordlistPreferences = it.wordlistPreferences.copy(ignoreEmptyLines = value)) }
    fun setDefaultAuditMode(mode: AuditMode) = updateSettings { it.copy(defaultAuditMode = mode) }
    fun setRequireAuthorizationConfirmation(value: Boolean) = updateSettings { it.copy(requireAuthorizationConfirmation = value) }

    private fun updateSettings(transform: (AppSettings) -> AppSettings) {
        viewModelScope.launch { settingsRepository.update(transform) }
    }
}
