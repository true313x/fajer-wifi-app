package com.fajer.wifiaudit.core.utils

import kotlin.math.log10
import kotlin.math.pow
import kotlin.math.roundToInt

object SignalUtils {

    private const val MIN_RSSI = -100
    private const val MAX_RSSI = -50

    fun rssiToPercent(rssiDbm: Int): Int {
        val clamped = rssiDbm.coerceIn(MIN_RSSI, MAX_RSSI)
        return (((clamped - MIN_RSSI).toDouble() / (MAX_RSSI - MIN_RSSI)) * 100)
            .roundToInt()
            .coerceIn(0, 100)
    }

    /** Maps a center frequency in MHz to its Wi-Fi channel number across the 2.4/5/6 GHz
     *  bands. Returns 0 if the frequency doesn't fall in a known band. */
    fun frequencyToChannel(frequencyMhz: Int): Int = when {
        frequencyMhz == 2484 -> 14
        frequencyMhz in 2412..2472 -> (frequencyMhz - 2412) / 5 + 1
        frequencyMhz in 5160..5885 -> (frequencyMhz - 5000) / 5
        frequencyMhz == 5935 -> 2
        frequencyMhz in 5955..7115 -> (frequencyMhz - 5950) / 5
        else -> 0
    }

    /**
     * A rough, order-of-magnitude distance estimate using the standard log-distance path loss
     * model: `distance = 10 ^ ((referenceRssiAt1m - rssi) / (10 * pathLossExponent))`.
     *
     * This is a well-known approximation, not a measurement — indoor multipath, antenna
     * orientation and building materials easily shift it by 2-3x. Callers must present it as
     * an estimate, never as a precise figure.
     */
    fun estimatedDistanceMeters(
        rssiDbm: Int,
        referenceRssiAt1m: Int = -40,
        pathLossExponent: Double = 2.7
    ): Double {
        val exponent = (referenceRssiAt1m - rssiDbm).toDouble() / (10 * pathLossExponent)
        return 10.0.pow(exponent)
    }

    /** log10 exposed for tests / callers that want the raw path-loss curve. */
    fun log10(value: Double): Double = log10(value)
}
