package com.fajer.wifiaudit.presentation.reports

import android.content.Context
import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.fajer.wifiaudit.core.storage.ReportFileWriter
import com.fajer.wifiaudit.domain.model.AuditOutcome
import com.fajer.wifiaudit.domain.model.AuditSession
import com.fajer.wifiaudit.domain.model.ReportData
import com.fajer.wifiaudit.domain.model.ReportFormat
import com.fajer.wifiaudit.domain.repository.AuditRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

data class ReportsUiState(
    val completedSessions: List<AuditSession> = emptyList(),
    val selectedSessionId: Long? = null,
    val selectedFormat: ReportFormat = ReportFormat.TXT,
    val statusMessage: String? = null,
)

class ReportsViewModel(private val auditRepository: AuditRepository) : ViewModel() {

    private val selectedSessionId = MutableStateFlow<Long?>(null)
    private val selectedFormat = MutableStateFlow(ReportFormat.TXT)
    private val statusMessage = MutableStateFlow<String?>(null)

    val uiState: StateFlow<ReportsUiState> = combine(
        auditRepository.observeSessions(),
        selectedSessionId,
        selectedFormat,
        statusMessage,
    ) { sessions, selectedId, format, status ->
        val completed = sessions.filter { it.result !is AuditOutcome.Pending }
        ReportsUiState(
            completedSessions = completed,
            selectedSessionId = selectedId ?: completed.firstOrNull()?.id,
            selectedFormat = format,
            statusMessage = status,
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), ReportsUiState())

    fun selectSession(id: Long) {
        selectedSessionId.value = id
    }

    fun selectFormat(format: ReportFormat) {
        selectedFormat.value = format
    }

    /** Renders the report and writes it to [destinationUri] (obtained via ACTION_CREATE_DOCUMENT). */
    fun generateAndSave(context: Context, destinationUri: Uri) {
        val sessionId = uiState.value.selectedSessionId ?: return
        val format = uiState.value.selectedFormat
        viewModelScope.launch {
            val session = auditRepository.observeSession(sessionId).first() ?: return@launch
            val content = ReportFileWriter.render(
                ReportData(
                    session = session,
                    appVersionName = "1.0.0",
                    generatedAtEpochMillis = System.currentTimeMillis(),
                ),
                format,
            )
            withContext(Dispatchers.IO) {
                ReportFileWriter.writeToUri(context, destinationUri, content)
            }
            statusMessage.value = "Report saved"
        }
    }
}
