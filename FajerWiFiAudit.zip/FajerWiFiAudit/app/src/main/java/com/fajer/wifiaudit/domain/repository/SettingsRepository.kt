package com.fajer.wifiaudit.domain.repository

import com.fajer.wifiaudit.core.model.ThemeMode
import com.fajer.wifiaudit.domain.model.AuditMode
import com.fajer.wifiaudit.domain.model.WordlistPreferences
import kotlinx.coroutines.flow.Flow

data class AppSettings(
    val themeMode: ThemeMode = ThemeMode.SYSTEM,
    val scanIntervalSeconds: Int = 15,
    val includeHiddenSsids: Boolean = true,
    val wordlistPreferences: WordlistPreferences = WordlistPreferences(),
    val defaultAuditMode: AuditMode = AuditMode.PASSWORD_STRENGTH_ANALYSIS,
    val requireAuthorizationConfirmation: Boolean = true
)

interface SettingsRepository {
    fun observeSettings(): Flow<AppSettings>
    suspend fun update(transform: (AppSettings) -> AppSettings)
}
