package com.fajer.wifiaudit.core.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.fajer.wifiaudit.core.ui.theme.FajerColors
import com.fajer.wifiaudit.domain.model.PasswordStrength
import com.fajer.wifiaudit.domain.model.SecurityType

/** A titled card used to group a section of related content — the base unit of every screen. */
@Composable
fun FajerSectionCard(
    title: String? = null,
    modifier: Modifier = Modifier,
    content: @Composable ColumnScope.() -> Unit,
) {
    Card(
        modifier = modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            if (title != null) {
                Text(text = title, style = MaterialTheme.typography.titleMedium)
            }
            content()
        }
    }
}

// Re-export so call sites don't need a separate foundation.layout.Column import just for the
// lambda receiver type.
typealias ColumnScope = androidx.compose.foundation.layout.ColumnScope

/** A label/value row — the workhorse of every details screen (SSID, RSSI, entry counts, etc). */
@Composable
fun StatRow(label: String, value: String, valueColor: Color = MaterialTheme.colorScheme.onSurface) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Text(
            text = value,
            style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold),
            color = valueColor,
        )
    }
}

/** Small colored dot + label, used for system-status rows (Wi-Fi adapter, Storage, etc). */
@Composable
fun StatusPill(label: String, isReady: Boolean) {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        Icon(
            imageVector = if (isReady) Icons.Default.CheckCircle else Icons.Default.ErrorOutline,
            contentDescription = null,
            tint = if (isReady) FajerColors.Success else FajerColors.Warning,
            modifier = Modifier.size(16.dp),
        )
        Text(text = label, style = MaterialTheme.typography.bodySmall)
    }
}

private fun SecurityType.badgeColor(): Color = when (this) {
    SecurityType.OPEN -> FajerColors.Error
    SecurityType.WEP -> FajerColors.Warning
    SecurityType.WPA -> FajerColors.Warning
    SecurityType.WPA2 -> FajerColors.Info
    SecurityType.WPA3 -> FajerColors.Success
    SecurityType.UNKNOWN -> FajerColors.TextHint
}

@Composable
fun SecurityBadge(type: SecurityType, modifier: Modifier = Modifier) {
    val color = type.badgeColor()
    Row(
        modifier = modifier
            .clip(RoundedCornerShape(6.dp))
            .background(color.copy(alpha = 0.16f))
            .padding(horizontal = 8.dp, vertical = 3.dp),
    ) {
        Text(
            text = type.name,
            style = MaterialTheme.typography.labelSmall,
            color = color,
        )
    }
}

private fun PasswordStrength.badgeColor(): Color = when (this) {
    PasswordStrength.VERY_WEAK -> FajerColors.Error
    PasswordStrength.WEAK -> Color(0xFFF57C00)
    PasswordStrength.MODERATE -> FajerColors.Warning
    PasswordStrength.STRONG -> Color(0xFF7CB342)
    PasswordStrength.VERY_STRONG -> FajerColors.Success
}

fun PasswordStrength.displayLabel(): String = when (this) {
    PasswordStrength.VERY_WEAK -> "Very Weak"
    PasswordStrength.WEAK -> "Weak"
    PasswordStrength.MODERATE -> "Moderate"
    PasswordStrength.STRONG -> "Strong"
    PasswordStrength.VERY_STRONG -> "Very Strong"
}

@Composable
fun StrengthBadge(strength: PasswordStrength, modifier: Modifier = Modifier) {
    val color = strength.badgeColor()
    Row(
        modifier = modifier
            .clip(RoundedCornerShape(6.dp))
            .background(color.copy(alpha = 0.16f))
            .padding(horizontal = 8.dp, vertical = 3.dp),
    ) {
        Text(text = strength.displayLabel(), style = MaterialTheme.typography.labelSmall, color = color)
    }
}

/** Signal bars, 1-4, driven purely by RSSI via [com.fajer.wifiaudit.core.utils.SignalUtils]. */
@Composable
fun SignalIndicator(percent: Int, modifier: Modifier = Modifier) {
    Row(modifier = modifier, verticalAlignment = Alignment.Bottom, horizontalArrangement = Arrangement.spacedBy(2.dp)) {
        val bars = (percent / 25).coerceIn(0, 4)
        repeat(4) { index ->
            val active = index < bars
            Column(
                modifier = Modifier
                    .size(width = 4.dp, height = (6 + index * 4).dp)
                    .clip(RoundedCornerShape(1.dp))
                    .background(
                        if (active) MaterialTheme.colorScheme.primary
                        else MaterialTheme.colorScheme.outline.copy(alpha = 0.3f)
                    ),
            ) {}
        }
    }
}

/** Full-screen empty state: icon-less by design (keeps translation-only content, no baked-in
 *  drawables to keep in sync with strings), title + body + one primary action. */
@Composable
fun EmptyState(
    title: String,
    body: String,
    actionLabel: String? = null,
    onAction: (() -> Unit)? = null,
    modifier: Modifier = Modifier,
) {
    Column(
        modifier = modifier.padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        Text(text = title, style = MaterialTheme.typography.titleLarge)
        Text(
            text = body,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        if (actionLabel != null && onAction != null) {
            Button(onClick = onAction, modifier = Modifier.padding(top = 8.dp)) {
                Text(actionLabel)
            }
        }
    }
}

@Composable
fun ErrorState(message: String, onRetry: (() -> Unit)? = null, modifier: Modifier = Modifier) {
    Column(
        modifier = modifier.padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        Icon(Icons.Default.ErrorOutline, contentDescription = null, tint = FajerColors.Error)
        Text(text = message, style = MaterialTheme.typography.bodyMedium)
        if (onRetry != null) {
            TextButton(onClick = onRetry) { Text("Retry") }
        }
    }
}

@Composable
fun FajerPrimaryButton(text: String, onClick: () -> Unit, modifier: Modifier = Modifier, enabled: Boolean = true) {
    Button(onClick = onClick, modifier = modifier, enabled = enabled) { Text(text) }
}

@Composable
fun FajerSecondaryButton(text: String, onClick: () -> Unit, modifier: Modifier = Modifier, enabled: Boolean = true) {
    OutlinedButton(onClick = onClick, modifier = modifier, enabled = enabled) { Text(text) }
}

@Composable
fun FajerDangerButton(text: String, onClick: () -> Unit, modifier: Modifier = Modifier, enabled: Boolean = true) {
    Button(
        onClick = onClick,
        modifier = modifier,
        enabled = enabled,
        colors = androidx.compose.material3.ButtonDefaults.buttonColors(
            containerColor = FajerColors.Error,
            contentColor = Color.White,
        ),
    ) { Text(text) }
}
