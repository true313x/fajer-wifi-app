package com.fajer.wifiaudit.presentation.scanner

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.fajer.wifiaudit.core.common.AppResult
import com.fajer.wifiaudit.core.permissions.PermissionState
import com.fajer.wifiaudit.domain.model.WifiNetwork
import com.fajer.wifiaudit.domain.repository.WifiRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class NetworksUiState(
    val networks: List<WifiNetwork> = emptyList(),
    val permissionState: PermissionState = PermissionState.Unknown,
    val isScanning: Boolean = false,
    val errorMessage: String? = null,
)

class NetworkListViewModel(private val wifiRepository: WifiRepository) : ViewModel() {

    private val isScanning = MutableStateFlow(false)
    private val errorMessage = MutableStateFlow<String?>(null)

    val uiState: StateFlow<NetworksUiState> = combine(
        wifiRepository.observeNetworks(),
        wifiRepository.observePermissionState(),
        isScanning,
        errorMessage,
    ) { networks, permissionState, scanning, error ->
        NetworksUiState(networks, permissionState, scanning, error)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), NetworksUiState())

    init {
        refreshPermissions()
    }

    fun refreshPermissions() {
        wifiRepository.refreshPermissionState()
    }

    fun scan() {
        if (isScanning.value) return
        viewModelScope.launch {
            isScanning.value = true
            errorMessage.value = null
            when (val result = wifiRepository.scan()) {
                is AppResult.Error -> errorMessage.value = result.message
                is AppResult.Success -> Unit
            }
            isScanning.value = false
        }
    }
}
