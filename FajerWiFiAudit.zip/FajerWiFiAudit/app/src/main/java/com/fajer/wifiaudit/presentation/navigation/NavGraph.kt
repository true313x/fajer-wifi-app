package com.fajer.wifiaudit.presentation.navigation

import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.HistoryEdu
import androidx.compose.material.icons.filled.NetworkWifi
import androidx.compose.material.icons.filled.VpnKey
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.navigation.NavBackStackEntry
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.fajer.wifiaudit.R
import com.fajer.wifiaudit.presentation.about.AboutScreen
import com.fajer.wifiaudit.presentation.audit.AuditRunScreen
import com.fajer.wifiaudit.presentation.audit.NewAuditScreen
import com.fajer.wifiaudit.presentation.dashboard.DashboardScreen
import com.fajer.wifiaudit.presentation.history.AuditDetailsScreen
import com.fajer.wifiaudit.presentation.history.HistoryScreen
import com.fajer.wifiaudit.presentation.network.NetworkDetailsScreen
import com.fajer.wifiaudit.presentation.reports.ReportsScreen
import com.fajer.wifiaudit.presentation.scanner.NetworksScreen
import com.fajer.wifiaudit.presentation.settings.SettingsScreen
import com.fajer.wifiaudit.presentation.wordlist.WordlistDetailsScreen
import com.fajer.wifiaudit.presentation.wordlist.WordlistsScreen

private data class BottomDestination(val route: String, val labelRes: Int, val icon: ImageVector)

private val bottomDestinations = listOf(
    BottomDestination(FajerRoute.Dashboard, R.string.nav_dashboard, Icons.Default.Dashboard),
    BottomDestination(FajerRoute.Networks, R.string.nav_networks, Icons.Default.NetworkWifi),
    BottomDestination(FajerRoute.Wordlists, R.string.nav_wordlists, Icons.Default.VpnKey),
    BottomDestination(FajerRoute.History, R.string.nav_history, Icons.Default.HistoryEdu),
)

@Composable
fun FajerNavGraph() {
    val navController = rememberNavController()
    // Tablets (and anything sw >= 600dp) get a side rail instead of a bottom bar, per the
    // spec's "adaptive navigation" requirement — a real breakpoint check rather than just
    // orientation, so a large phone in landscape doesn't get an awkward half-rail.
    val isWideScreen = LocalConfiguration.current.screenWidthDp >= 600

    if (isWideScreen) {
        Row(modifier = Modifier.fillMaxSize()) {
            FajerNavigationRail(navController)
            FajerNavHost(navController, modifier = Modifier.fillMaxSize(), contentPadding = PaddingValues(0.dp))
        }
    } else {
        Scaffold(
            modifier = Modifier.fillMaxSize(),
            bottomBar = { FajerBottomBar(navController) },
        ) { innerPadding ->
            FajerNavHost(navController, modifier = Modifier.fillMaxSize(), contentPadding = innerPadding)
        }
    }
}

@Composable
private fun FajerNavHost(
    navController: NavHostController,
    modifier: Modifier = Modifier,
    contentPadding: PaddingValues,
) {
    NavHost(
        navController = navController,
        startDestination = FajerRoute.Dashboard,
        modifier = modifier.padding(contentPadding),
    ) {
        composable(FajerRoute.Dashboard) { DashboardScreen(navController) }
        composable(FajerRoute.Networks) { NetworksScreen(navController) }
        composable(
            route = FajerRoute.NetworkDetails,
            arguments = listOf(navArgument("bssid") { type = NavType.StringType }),
        ) { entry ->
            NetworkDetailsScreen(navController, entry.requireString("bssid"))
        }
        composable(FajerRoute.Wordlists) { WordlistsScreen(navController) }
        composable(
            route = FajerRoute.WordlistDetails,
            arguments = listOf(navArgument("wordlistId") { type = NavType.LongType }),
        ) { entry ->
            WordlistDetailsScreen(navController, entry.requireLong("wordlistId"))
        }
        composable(FajerRoute.NewAudit) { NewAuditScreen(navController) }
        composable(
            route = FajerRoute.AuditRun,
            arguments = listOf(navArgument("sessionId") { type = NavType.LongType }),
        ) { entry ->
            AuditRunScreen(navController, entry.requireLong("sessionId"))
        }
        composable(FajerRoute.History) { HistoryScreen(navController) }
        composable(
            route = FajerRoute.HistoryDetails,
            arguments = listOf(navArgument("sessionId") { type = NavType.LongType }),
        ) { entry ->
            AuditDetailsScreen(navController, entry.requireLong("sessionId"))
        }
        composable(FajerRoute.Reports) { ReportsScreen(navController) }
        composable(FajerRoute.Settings) { SettingsScreen(navController) }
        composable(FajerRoute.About) { AboutScreen(navController) }
    }
}

private fun NavBackStackEntry.requireLong(key: String): Long =
    arguments?.getLong(key) ?: error("Missing required nav argument: $key")

private fun NavBackStackEntry.requireString(key: String): String =
    arguments?.getString(key) ?: error("Missing required nav argument: $key")

@Composable
private fun FajerBottomBar(navController: NavHostController) {
    val currentRoute = navController.currentBackStackEntryAsState().value?.destination?.route
    NavigationBar {
        bottomDestinations.forEach { destination ->
            val selected = currentRoute == destination.route
            NavigationBarItem(
                selected = selected,
                onClick = { navigateToTab(navController, destination.route, selected) },
                icon = { Icon(destination.icon, contentDescription = stringResource(destination.labelRes)) },
                label = { Text(stringResource(destination.labelRes)) },
            )
        }
    }
}

@Composable
private fun FajerNavigationRail(navController: NavHostController) {
    val currentRoute = navController.currentBackStackEntryAsState().value?.destination?.route
    NavigationRail {
        bottomDestinations.forEach { destination ->
            val selected = currentRoute == destination.route
            NavigationRailItem(
                selected = selected,
                onClick = { navigateToTab(navController, destination.route, selected) },
                icon = { Icon(destination.icon, contentDescription = stringResource(destination.labelRes)) },
                label = { Text(stringResource(destination.labelRes)) },
            )
        }
    }
}

private fun navigateToTab(navController: NavHostController, route: String, alreadySelected: Boolean) {
    if (alreadySelected) return
    navController.navigate(route) {
        popUpTo(FajerRoute.Dashboard) { saveState = true }
        launchSingleTop = true
        restoreState = true
    }
}
