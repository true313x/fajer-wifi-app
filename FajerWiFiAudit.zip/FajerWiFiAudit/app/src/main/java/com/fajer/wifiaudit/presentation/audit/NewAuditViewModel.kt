package com.fajer.wifiaudit.presentation.audit

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.fajer.wifiaudit.core.common.AppResult
import com.fajer.wifiaudit.domain.model.AuditMode
import com.fajer.wifiaudit.domain.model.AuditOutcome
import com.fajer.wifiaudit.domain.model.AuditSession
import com.fajer.wifiaudit.domain.model.AuditStatus
import com.fajer.wifiaudit.domain.model.LabTarget
import com.fajer.wifiaudit.domain.model.Wordlist
import com.fajer.wifiaudit.domain.repository.AuditRepository
import com.fajer.wifiaudit.domain.repository.LabTargetRepository
import com.fajer.wifiaudit.domain.repository.WordlistRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class NewAuditFormState(
    val availableTargets: List<LabTarget> = emptyList(),
    val availableWordlists: List<Wordlist> = emptyList(),
    val name: String = "",
    val selectedTargetId: Long? = null,
    val selectedWordlistId: Long? = null,
    val mode: AuditMode = AuditMode.PASSWORD_STRENGTH_ANALYSIS,
    val knownCredential: String = "",
    val notes: String = "",
    val authorizationConfirmed: Boolean = false,
    val isSubmitting: Boolean = false,
    val errorMessage: String? = null,
) {
    /** Password Strength Analysis needs only a wordlist; the other two modes need a target too. */
    val canSubmit: Boolean
        get() = name.isNotBlank() &&
            selectedWordlistId != null &&
            authorizationConfirmed &&
            (mode == AuditMode.PASSWORD_STRENGTH_ANALYSIS || selectedTargetId != null) &&
            (mode != AuditMode.KNOWN_TEST_CREDENTIAL_SIMULATION || knownCredential.isNotBlank())
}

class NewAuditViewModel(
    private val auditRepository: AuditRepository,
    labTargetRepository: LabTargetRepository,
    wordlistRepository: WordlistRepository,
) : ViewModel() {

    private val formState = MutableStateFlow(NewAuditFormState())

    val uiState: StateFlow<NewAuditFormState> = combine(
        formState,
        labTargetRepository.observeTargets(),
        wordlistRepository.observeWordlists(),
    ) { form, targets, wordlists ->
        form.copy(availableTargets = targets, availableWordlists = wordlists)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), NewAuditFormState())

    fun setName(value: String) = update { it.copy(name = value) }
    fun selectTarget(id: Long) = update { it.copy(selectedTargetId = id) }
    fun selectWordlist(id: Long) = update { it.copy(selectedWordlistId = id) }
    fun selectMode(mode: AuditMode) = update { it.copy(mode = mode) }
    fun setKnownCredential(value: String) = update { it.copy(knownCredential = value) }
    fun setNotes(value: String) = update { it.copy(notes = value) }
    fun setAuthorizationConfirmed(value: Boolean) = update { it.copy(authorizationConfirmed = value) }

    private inline fun update(transform: (NewAuditFormState) -> NewAuditFormState) {
        formState.value = transform(formState.value)
    }

    /** Creates the session and, on success, invokes [onCreated] with its new id. */
    fun submit(onCreated: (Long) -> Unit) {
        val state = uiState.value
        if (!state.canSubmit) return

        viewModelScope.launch {
            formState.value = formState.value.copy(isSubmitting = true, errorMessage = null)

            val target = state.availableTargets.firstOrNull { it.id == state.selectedTargetId }
            val wordlist = state.availableWordlists.firstOrNull { it.id == state.selectedWordlistId }
            if (wordlist == null) {
                formState.value = formState.value.copy(isSubmitting = false, errorMessage = "Select a wordlist")
                return@launch
            }

            val session = AuditSession(
                name = state.name,
                targetSsid = target?.ssid ?: "",
                targetBssid = target?.bssid ?: "",
                wordlistId = wordlist.id,
                wordlistName = wordlist.displayName,
                mode = state.mode,
                status = AuditStatus.IDLE,
                processed = 0,
                total = wordlist.stats.totalLines,
                durationMillis = 0,
                result = AuditOutcome.Pending,
                authorizationConfirmed = state.authorizationConfirmed,
                notes = state.notes,
                createdAtEpochMillis = System.currentTimeMillis(),
                completedAtEpochMillis = null,
            )

            when (val result = auditRepository.createSession(session)) {
                is AppResult.Success -> {
                    formState.value = NewAuditFormState()
                    onCreated(result.data.id)
                }
                is AppResult.Error -> {
                    formState.value = formState.value.copy(isSubmitting = false, errorMessage = result.message)
                }
            }
        }
    }
}
