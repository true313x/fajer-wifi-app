package com.fajer.wifiaudit.presentation.audit

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.fajer.wifiaudit.domain.model.AuditOutcome
import com.fajer.wifiaudit.domain.model.AuditProgress
import com.fajer.wifiaudit.domain.model.AuditSession
import com.fajer.wifiaudit.domain.model.AuditStatus
import com.fajer.wifiaudit.domain.repository.AuditRepository
import com.fajer.wifiaudit.domain.repository.WordlistRepository
import com.fajer.wifiaudit.domain.usecase.AuditEngine
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.launchIn
import kotlinx.coroutines.flow.onEach
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

data class AuditRunUiState(
    val session: AuditSession? = null,
    val progress: AuditProgress = AuditProgress.ZERO,
    val isPaused: Boolean = false,
)

class AuditRunViewModel(
    private val auditRepository: AuditRepository,
    private val wordlistRepository: WordlistRepository,
    private val sessionId: Long,
) : ViewModel() {

    private val engine = AuditEngine()
    private var runJob: Job? = null

    private val _uiState = MutableStateFlow(AuditRunUiState())
    val uiState: StateFlow<AuditRunUiState> = _uiState.asStateFlow()

    init {
        engine.progress.onEach { progress ->
            _uiState.value = _uiState.value.copy(progress = progress)
        }.launchIn(viewModelScope)

        viewModelScope.launch {
            auditRepository.observeSession(sessionId).collect { session ->
                _uiState.value = _uiState.value.copy(session = session)
                if (session != null && session.status == AuditStatus.IDLE && runJob == null) {
                    start(session)
                }
            }
        }
    }

    private fun start(session: AuditSession) {
        runJob = viewModelScope.launch {
            try {
                persistStatus(session, AuditStatus.RUNNING)
                val candidates = wordlistRepository.streamCandidates(session.wordlistId)
                val outcome = engine.run(
                    mode = session.mode,
                    candidates = candidates,
                    totalHint = session.total,
                    // A user-entered Known-Test-Credential value lives only on the NewAudit
                    // form today and is never persisted on AuditSession/AuditSessionEntity, so
                    // it can never leak into history or a generated report. A future "re-run"
                    // feature would need to thread it through explicitly, not read it back
                    // from storage.
                    knownCredential = null,
                )
                finish(session, outcome)
            } catch (e: CancellationException) {
                val processed = _uiState.value.progress.processed
                finish(session, AuditOutcome.Stopped(processed))
                throw e
            }
        }
    }

    /** Always completes even if the calling coroutine has already been cancelled (Stop), so
     *  the final status genuinely reaches the database instead of being cancelled mid-write. */
    private suspend fun finish(session: AuditSession, outcome: AuditOutcome) = withContext(NonCancellable) {
        val progress = _uiState.value.progress
        val updated = session.copy(
            status = when (outcome) {
                is AuditOutcome.Stopped -> AuditStatus.STOPPED
                is AuditOutcome.Failed -> AuditStatus.FAILED
                else -> AuditStatus.COMPLETED
            },
            processed = progress.processed.takeIf { it > 0 } ?: session.processed,
            durationMillis = progress.elapsedMillis,
            result = outcome,
            completedAtEpochMillis = System.currentTimeMillis(),
        )
        auditRepository.updateSession(updated)
        Unit
    }

    private suspend fun persistStatus(session: AuditSession, status: AuditStatus) {
        auditRepository.updateSession(session.copy(status = status))
    }

    fun togglePause() {
        val paused = !_uiState.value.isPaused
        if (paused) engine.pause() else engine.resume()
        _uiState.value = _uiState.value.copy(isPaused = paused)
    }

    fun stop() {
        runJob?.cancel()
    }

    override fun onCleared() {
        super.onCleared()
        runJob?.cancel()
    }
}
