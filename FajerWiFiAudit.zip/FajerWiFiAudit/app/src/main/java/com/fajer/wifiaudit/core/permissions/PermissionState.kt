package com.fajer.wifiaudit.core.permissions

/**
 * Snapshot of every precondition Wi-Fi scanning depends on. The dashboard's "System status"
 * section and the Networks screen both render directly from this — nothing else needed.
 */
data class PermissionState(
    val hasScanPermission: Boolean,
    val locationServicesRequired: Boolean,
    val isLocationServicesEnabled: Boolean,
    val isWifiEnabled: Boolean,
    val isWifiHardwareSupported: Boolean
) {
    /** True only when every precondition for a scan to actually return results is met. */
    val canScan: Boolean
        get() = hasScanPermission &&
            isWifiEnabled &&
            isWifiHardwareSupported &&
            (!locationServicesRequired || isLocationServicesEnabled)

    companion object {
        val Unknown = PermissionState(
            hasScanPermission = false,
            locationServicesRequired = false,
            isLocationServicesEnabled = false,
            isWifiEnabled = false,
            isWifiHardwareSupported = true
        )
    }
}
