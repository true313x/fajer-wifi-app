package com.fajer.wifiaudit.core.common

/**
 * Central, dependency-free constants. Nothing here talks to Android — that keeps this file
 * safe to reference from `domain` without pulling framework classes into business logic.
 */
object FajerConstants {

    const val DATABASE_NAME = "fajer_wifi_audit.db"
    const val DATASTORE_NAME = "fajer_settings"

    // The built-in, clearly-fake lab target used by "Offline Wordlist Simulation" mode.
    // This is the ONLY credential the audit engine is ever allowed to compare candidates
    // against by default — it lives entirely on-device and is never sent anywhere, and the
    // engine never opens a real network connection to test it.
    const val SAMPLE_LAB_SSID = "FAJER-LAB"
    const val SAMPLE_LAB_BSSID = "02:00:00:00:00:01" // locally-administered, non-routable OUI
    const val SAMPLE_LAB_SYNTHETIC_CREDENTIAL = "LabPassword123!"

    val SAMPLE_WORDLIST_ENTRIES = listOf(
        "password",
        "12345678",
        "admin123",
        "qwerty123",
        "LabPassword123!"
    )

    // A file above this many lines triggers a "this may take a moment" notice in the UI
    // rather than silently blocking. Actual parsing always streams regardless of size.
    const val LARGE_WORDLIST_LINE_WARNING_THRESHOLD = 250_000

    // How often the audit engine publishes a new AuditProgress snapshot while running.
    // Emitting on every single candidate would flood Compose recomposition for large lists.
    const val AUDIT_PROGRESS_EMIT_INTERVAL_MS = 120L

    const val DEFAULT_SCAN_INTERVAL_SECONDS = 15
    val SCAN_INTERVAL_OPTIONS_SECONDS = listOf(10, 15, 30, 60)
}
