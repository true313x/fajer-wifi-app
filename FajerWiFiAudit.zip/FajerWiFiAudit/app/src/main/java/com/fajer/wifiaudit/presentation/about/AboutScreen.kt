package com.fajer.wifiaudit.presentation.about

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import com.fajer.wifiaudit.R
import com.fajer.wifiaudit.core.ui.components.FajerSectionCard

@Composable
fun AboutScreen(navController: NavHostController) {
    Scaffold(
        topBar = { TopAppBar(title = { Text(stringResource(R.string.about_title)) }) },
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            Text(stringResource(R.string.app_name), style = MaterialTheme.typography.headlineMedium)
            Text(
                stringResource(R.string.app_subtitle),
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )

            FajerSectionCard(title = stringResource(R.string.about_version)) {
                Text("1.0.0", style = MaterialTheme.typography.bodyMedium)
            }

            FajerSectionCard(title = stringResource(R.string.about_scope_title)) {
                Text(stringResource(R.string.about_scope_body), style = MaterialTheme.typography.bodyMedium)
            }

            FajerSectionCard(title = stringResource(R.string.settings_section_privacy)) {
                Text(stringResource(R.string.privacy_statement), style = MaterialTheme.typography.bodyMedium)
            }
        }
    }
}
