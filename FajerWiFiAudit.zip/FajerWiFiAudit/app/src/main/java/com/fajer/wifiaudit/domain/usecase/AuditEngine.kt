package com.fajer.wifiaudit.domain.usecase

import com.fajer.wifiaudit.core.common.FajerConstants
import com.fajer.wifiaudit.core.security.PasswordStrengthAnalyzer
import com.fajer.wifiaudit.core.utils.TimeUtils
import com.fajer.wifiaudit.domain.model.AuditMode
import com.fajer.wifiaudit.domain.model.AuditOutcome
import com.fajer.wifiaudit.domain.model.AuditProgress
import com.fajer.wifiaudit.domain.model.PasswordStrength
import kotlinx.coroutines.delay
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlin.coroutines.coroutineContext

/**
 * Runs one audit locally, entirely in-process. It is handed a [Flow] of candidate strings —
 * from [com.fajer.wifiaudit.domain.repository.WordlistRepository.streamCandidates] — and
 * either scores each one for strength, or compares it against a synthetic credential supplied
 * by the caller. **It never opens a socket, never touches [android.net.wifi.WifiManager] to
 * join a network, and never sends a candidate anywhere.** A candidate is only ever compared
 * with `==` against a string already held in memory, and the flow is consumed one element at
 * a time — nothing buffers the whole wordlist.
 *
 * Cancellation is cooperative: the caller (see `AuditRunViewModel`) cancels the coroutine
 * running [run] to implement "Stop", which surfaces as a normal [kotlinx.coroutines.CancellationException];
 * the caller reads [progress] for how far the run got and persists an [AuditOutcome.Stopped]
 * itself. "Pause" is a spin-wait on a flag checked between candidates, using [delay] — which is
 * itself a cancellable suspension point, so a paused run still responds to Stop immediately.
 */
class AuditEngine {

    private val _progress = MutableStateFlow(AuditProgress.ZERO)
    val progress: StateFlow<AuditProgress> = _progress.asStateFlow()

    @Volatile private var paused = false

    fun pause() {
        paused = true
    }

    fun resume() {
        paused = false
    }

    /** Thrown internally the instant a match is found, purely to unwind out of [Flow.collect]
     *  without processing the remainder of a potentially huge wordlist. Always caught inside
     *  [run] — it never escapes to the caller. */
    private class MatchFound(val outcome: AuditOutcome.Matched) : Exception()

    suspend fun run(
        mode: AuditMode,
        candidates: Flow<String>,
        totalHint: Int,
        knownCredential: String? = null,
    ): AuditOutcome {
        _progress.value = AuditProgress.ZERO.copy(total = totalHint)
        val startedAt = System.currentTimeMillis()
        var processed = 0
        var lastEmitAt = 0L
        val strengthTally = HashMap<PasswordStrength, Int>()

        try {
            candidates.collect { candidate ->
                coroutineContext.ensureActive() // lets Stop cancel promptly even on a slow producer

                while (paused) {
                    delay(50) // itself a cancellation point, so Stop still works while paused
                }

                processed++
                val elapsed = System.currentTimeMillis() - startedAt
                val rate = if (elapsed > 0) processed * 1000.0 / elapsed else 0.0
                val eta = TimeUtils.estimateEtaMillis(processed, totalHint, elapsed)

                val now = System.currentTimeMillis()
                val isLast = processed >= totalHint
                if (now - lastEmitAt >= FajerConstants.AUDIT_PROGRESS_EMIT_INTERVAL_MS || isLast) {
                    _progress.value = AuditProgress(
                        processed = processed,
                        total = totalHint,
                        ratePerSecond = rate,
                        elapsedMillis = elapsed,
                        etaMillis = eta,
                        currentCandidate = candidate,
                    )
                    lastEmitAt = now
                }

                when (mode) {
                    AuditMode.PASSWORD_STRENGTH_ANALYSIS -> {
                        val strength = PasswordStrengthAnalyzer.analyze(candidate).strength
                        strengthTally.merge(strength, 1, Int::plus)
                    }

                    AuditMode.OFFLINE_WORDLIST_SIMULATION -> {
                        if (candidate == FajerConstants.SAMPLE_LAB_SYNTHETIC_CREDENTIAL) {
                            throw MatchFound(AuditOutcome.Matched(processed, candidate))
                        }
                    }

                    AuditMode.KNOWN_TEST_CREDENTIAL_SIMULATION -> {
                        if (knownCredential != null && candidate == knownCredential) {
                            throw MatchFound(AuditOutcome.Matched(processed, candidate))
                        }
                    }
                }
            }
        } catch (match: MatchFound) {
            return match.outcome
        }

        return if (mode == AuditMode.PASSWORD_STRENGTH_ANALYSIS) {
            AuditOutcome.StrengthSummary(strengthTally)
        } else {
            AuditOutcome.NoMatch
        }
    }
}
