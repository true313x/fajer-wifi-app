package com.fajer.wifiaudit.data.repository

import android.content.Context
import com.fajer.wifiaudit.core.common.AppResult
import com.fajer.wifiaudit.core.permissions.PermissionManager
import com.fajer.wifiaudit.core.permissions.PermissionState
import com.fajer.wifiaudit.data.wifi.AndroidWifiScanner
import com.fajer.wifiaudit.domain.model.WifiNetwork
import com.fajer.wifiaudit.domain.repository.WifiRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class WifiRepositoryImpl(
    private val context: Context,
    private val scanner: AndroidWifiScanner,
) : WifiRepository {

    private val _networks = MutableStateFlow<List<WifiNetwork>>(emptyList())
    private val _permissionState = MutableStateFlow(PermissionManager.currentState(context))

    override fun observePermissionState(): StateFlow<PermissionState> = _permissionState.asStateFlow()

    override fun observeNetworks() = _networks.asStateFlow()

    override suspend fun scan(): AppResult<List<WifiNetwork>> {
        refreshPermissionState()
        return when (val result = scanner.scan()) {
            is AppResult.Success -> {
                _networks.value = result.data
                result
            }
            is AppResult.Error -> result
        }
    }

    override fun refreshPermissionState() {
        _permissionState.value = PermissionManager.currentState(context)
    }
}
