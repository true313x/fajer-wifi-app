package com.fajer.wifiaudit.data.repository

import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import com.fajer.wifiaudit.core.model.ThemeMode
import com.fajer.wifiaudit.domain.model.AuditMode
import com.fajer.wifiaudit.domain.model.WordlistPreferences
import com.fajer.wifiaudit.domain.repository.AppSettings
import com.fajer.wifiaudit.domain.repository.SettingsRepository
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map

class SettingsRepositoryImpl(
    private val dataStore: DataStore<Preferences>,
) : SettingsRepository {

    override fun observeSettings(): Flow<AppSettings> = dataStore.data.map { prefs ->
        AppSettings(
            themeMode = prefs[Keys.THEME_MODE]?.let { runCatching { ThemeMode.valueOf(it) }.getOrNull() }
                ?: ThemeMode.SYSTEM,
            scanIntervalSeconds = prefs[Keys.SCAN_INTERVAL] ?: 15,
            includeHiddenSsids = prefs[Keys.INCLUDE_HIDDEN_SSIDS] ?: true,
            wordlistPreferences = WordlistPreferences(
                trimWhitespace = prefs[Keys.TRIM_WHITESPACE] ?: true,
                deduplicate = prefs[Keys.DEDUPLICATE] ?: false,
                ignoreEmptyLines = prefs[Keys.IGNORE_EMPTY_LINES] ?: true,
            ),
            defaultAuditMode = prefs[Keys.DEFAULT_AUDIT_MODE]
                ?.let { runCatching { AuditMode.valueOf(it) }.getOrNull() }
                ?: AuditMode.PASSWORD_STRENGTH_ANALYSIS,
            requireAuthorizationConfirmation = prefs[Keys.REQUIRE_AUTH_CONFIRMATION] ?: true,
        )
    }

    override suspend fun update(transform: (AppSettings) -> AppSettings) {
        val current = observeSettings().first()
        val updated = transform(current)
        dataStore.edit { prefs ->
            prefs[Keys.THEME_MODE] = updated.themeMode.name
            prefs[Keys.SCAN_INTERVAL] = updated.scanIntervalSeconds
            prefs[Keys.INCLUDE_HIDDEN_SSIDS] = updated.includeHiddenSsids
            prefs[Keys.TRIM_WHITESPACE] = updated.wordlistPreferences.trimWhitespace
            prefs[Keys.DEDUPLICATE] = updated.wordlistPreferences.deduplicate
            prefs[Keys.IGNORE_EMPTY_LINES] = updated.wordlistPreferences.ignoreEmptyLines
            prefs[Keys.DEFAULT_AUDIT_MODE] = updated.defaultAuditMode.name
            prefs[Keys.REQUIRE_AUTH_CONFIRMATION] = updated.requireAuthorizationConfirmation
        }
    }

    private object Keys {
        val THEME_MODE = stringPreferencesKey("theme_mode")
        val SCAN_INTERVAL = intPreferencesKey("scan_interval_seconds")
        val INCLUDE_HIDDEN_SSIDS = booleanPreferencesKey("include_hidden_ssids")
        val TRIM_WHITESPACE = booleanPreferencesKey("trim_whitespace")
        val DEDUPLICATE = booleanPreferencesKey("deduplicate")
        val IGNORE_EMPTY_LINES = booleanPreferencesKey("ignore_empty_lines")
        val DEFAULT_AUDIT_MODE = stringPreferencesKey("default_audit_mode")
        val REQUIRE_AUTH_CONFIRMATION = booleanPreferencesKey("require_authorization_confirmation")
    }
}
