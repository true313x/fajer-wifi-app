package com.fajer.wifiaudit.presentation.navigation

/**
 * Route *patterns*, as registered with [androidx.navigation.NavGraphBuilder.composable]. Each
 * `create...` function below builds the concrete path for [androidx.navigation.NavController.navigate].
 */
object FajerRoute {
    const val Dashboard = "dashboard"
    const val Networks = "networks"
    const val NetworkDetails = "network/{bssid}"
    const val Wordlists = "wordlists"
    const val WordlistDetails = "wordlist/{wordlistId}"
    const val NewAudit = "newAudit"
    const val AuditRun = "audit/{sessionId}"
    const val History = "history"
    const val HistoryDetails = "history/{sessionId}"
    const val Reports = "reports"
    const val Settings = "settings"
    const val About = "about"

    fun networkDetails(bssid: String) = "network/$bssid"
    fun wordlistDetails(wordlistId: Long) = "wordlist/$wordlistId"
    fun auditRun(sessionId: Long) = "audit/$sessionId"
    fun historyDetails(sessionId: Long) = "history/$sessionId"
}
