package com.fajer.wifiaudit.presentation.wordlist

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.fajer.wifiaudit.domain.model.Wordlist
import com.fajer.wifiaudit.domain.repository.WordlistRepository
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn

data class WordlistDetailsUiState(val wordlist: Wordlist? = null)

class WordlistDetailsViewModel(
    wordlistRepository: WordlistRepository,
    wordlistId: Long,
) : ViewModel() {

    val uiState: StateFlow<WordlistDetailsUiState> = wordlistRepository.observeWordlist(wordlistId)
        .map { WordlistDetailsUiState(it) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), WordlistDetailsUiState())
}
