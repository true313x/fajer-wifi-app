package com.fajer.wifiaudit.presentation.wordlist

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import androidx.navigation.NavHostController
import com.fajer.wifiaudit.R
import com.fajer.wifiaudit.core.ui.components.FajerSectionCard
import com.fajer.wifiaudit.core.ui.components.StatRow
import com.fajer.wifiaudit.core.ui.theme.FajerColors
import com.fajer.wifiaudit.domain.model.LengthBucket
import com.fajer.wifiaudit.domain.model.WordlistStats
import com.fajer.wifiaudit.presentation.common.currentAppContainer
import kotlin.math.roundToInt

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun WordlistDetailsScreen(navController: NavHostController, wordlistId: Long) {
    val container = currentAppContainer()
    val viewModel: WordlistDetailsViewModel = viewModel(
        factory = viewModelFactory {
            initializer { WordlistDetailsViewModel(container.wordlistRepository, wordlistId) }
        }
    )
    val state by viewModel.uiState.collectAsStateWithLifecycle()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(stringResource(R.string.wordlist_details_title)) },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(Icons.Default.ArrowBack, contentDescription = null)
                    }
                },
            )
        },
    ) { innerPadding ->
        val wordlist = state.wordlist ?: return@Scaffold
        val stats = wordlist.stats

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            Text(wordlist.displayName, style = MaterialTheme.typography.headlineSmall)

            FajerSectionCard {
                StatRow(stringResource(R.string.wordlist_stat_entries), stats.totalLines.toString())
                StatRow(stringResource(R.string.wordlist_stat_unique), stats.uniqueLines.toString())
                StatRow(stringResource(R.string.wordlist_stat_duplicates), stats.duplicateCount.toString())
                StatRow(stringResource(R.string.wordlist_stat_empty), stats.emptyLinesRemoved.toString())
                StatRow(stringResource(R.string.wordlist_stat_encoding), wordlist.encoding)
            }

            FajerSectionCard(title = stringResource(R.string.section_length_distribution)) {
                LengthDistributionChart(stats)
            }

            FajerSectionCard(title = stringResource(R.string.section_character_composition)) {
                StatRow(stringResource(R.string.stat_average_length), "%.1f".format(stats.averageLength))
                StatRow(stringResource(R.string.stat_minimum_length), stats.minimumLength.toString())
                StatRow(stringResource(R.string.stat_maximum_length), stats.maximumLength.toString())
                StatRow(stringResource(R.string.stat_numeric_only), stats.numericOnlyCount.toString())
                StatRow(stringResource(R.string.stat_alphabetic_only), stats.alphabeticOnlyCount.toString())
                StatRow(stringResource(R.string.stat_mixed), stats.mixedCount.toString())
                StatRow(stringResource(R.string.stat_special_character), stats.specialCharacterCount.toString())
                StatRow(stringResource(R.string.stat_unicode), stats.unicodeCount.toString())
            }
        }
    }
}

@Composable
private fun LengthDistributionChart(stats: WordlistStats) {
    val maxCount = (stats.lengthDistribution.values.maxOrNull() ?: 0).coerceAtLeast(1)
    val barColor = FajerColors.Accent

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .height(120.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        LengthBucket.entries.forEach { bucket ->
            val count = stats.lengthDistribution[bucket] ?: 0
            val fraction = count.toFloat() / maxCount.toFloat()
            Column(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxSize(),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Bottom,
            ) {
                Text(count.toString(), style = MaterialTheme.typography.labelSmall)
                Canvas(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                        .padding(top = 4.dp),
                ) {
                    val barHeight = size.height * fraction
                    drawRect(
                        color = barColor,
                        topLeft = Offset(x = 0f, y = size.height - barHeight),
                        size = Size(width = size.width, height = barHeight),
                    )
                }
                Text(bucket.rangeLabel, style = MaterialTheme.typography.labelSmall)
            }
        }
    }
}
