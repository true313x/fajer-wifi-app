package com.fajer.wifiaudit.presentation.history

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.fajer.wifiaudit.domain.model.AuditLogEntry
import com.fajer.wifiaudit.domain.model.AuditSession
import com.fajer.wifiaudit.domain.repository.AuditRepository
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn

data class AuditDetailsUiState(
    val session: AuditSession? = null,
    val logs: List<AuditLogEntry> = emptyList(),
)

class AuditDetailsViewModel(
    auditRepository: AuditRepository,
    sessionId: Long,
) : ViewModel() {

    val uiState = combine(
        auditRepository.observeSession(sessionId),
        auditRepository.observeLogs(sessionId),
    ) { session, logs ->
        AuditDetailsUiState(session, logs)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), AuditDetailsUiState())
}
