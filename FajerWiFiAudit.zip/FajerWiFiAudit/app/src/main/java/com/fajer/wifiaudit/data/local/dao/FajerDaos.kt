package com.fajer.wifiaudit.data.local.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update
import com.fajer.wifiaudit.data.local.entities.AuditLogEntity
import com.fajer.wifiaudit.data.local.entities.LabTargetEntity
import com.fajer.wifiaudit.data.local.entities.WordlistEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface WordlistDao {
    @Insert
    suspend fun insert(wordlist: WordlistEntity): Long

    @Update
    suspend fun update(wordlist: WordlistEntity)

    @Delete
    suspend fun delete(wordlist: WordlistEntity)

    @Query("SELECT * FROM wordlists WHERE id = :id LIMIT 1")
    suspend fun getById(id: Long): WordlistEntity?

    @Query("SELECT * FROM wordlists ORDER BY importedAtEpochMillis DESC")
    fun observeAll(): Flow<List<WordlistEntity>>

    @Query("SELECT * FROM wordlists WHERE id = :id LIMIT 1")
    fun observeById(id: Long): Flow<WordlistEntity?>

    @Query("SELECT COUNT(*) FROM wordlists WHERE displayName = :displayName")
    suspend fun countByName(displayName: String): Int
}

@Dao
interface AuditLogDao {
    @Insert
    suspend fun insert(entry: AuditLogEntity)

    @Query("SELECT * FROM audit_logs WHERE auditSessionId = :sessionId ORDER BY timestampEpochMillis DESC")
    fun observeForSession(sessionId: Long): Flow<List<AuditLogEntity>>

    @Query("SELECT * FROM audit_logs WHERE auditSessionId IS NULL ORDER BY timestampEpochMillis DESC LIMIT :limit")
    fun observeGlobal(limit: Int): Flow<List<AuditLogEntity>>

    @Query("SELECT * FROM audit_logs ORDER BY timestampEpochMillis DESC LIMIT :limit")
    fun observeRecent(limit: Int): Flow<List<AuditLogEntity>>
}

@Dao
interface LabTargetDao {
    @Insert
    suspend fun insert(target: LabTargetEntity): Long

    @Delete
    suspend fun delete(target: LabTargetEntity)

    @Query("SELECT * FROM lab_targets ORDER BY addedAtEpochMillis DESC")
    fun observeAll(): Flow<List<LabTargetEntity>>

    @Query("SELECT * FROM lab_targets WHERE id = :id LIMIT 1")
    suspend fun getById(id: Long): LabTargetEntity?

    @Query("SELECT * FROM lab_targets WHERE isBuiltInSample = 1 LIMIT 1")
    suspend fun getSampleTarget(): LabTargetEntity?

    @Query("SELECT COUNT(*) FROM lab_targets WHERE bssid = :bssid")
    suspend fun countByBssid(bssid: String): Int
}
