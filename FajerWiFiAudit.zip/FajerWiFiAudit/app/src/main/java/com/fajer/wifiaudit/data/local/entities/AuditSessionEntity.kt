package com.fajer.wifiaudit.data.local.entities

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.fajer.wifiaudit.domain.model.AuditMode
import com.fajer.wifiaudit.domain.model.AuditOutcome
import com.fajer.wifiaudit.domain.model.AuditSession
import com.fajer.wifiaudit.domain.model.AuditStatus
import com.fajer.wifiaudit.domain.model.PasswordStrength

/**
 * [AuditOutcome] is a sealed type, so it is flattened into a discriminator column plus a
 * handful of nullable columns rather than mapped to separate tables — a session only ever
 * has one outcome at a time, and this keeps its full state in a single row.
 */
@Entity(tableName = "audit_sessions")
data class AuditSessionEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val targetSsid: String,
    val targetBssid: String,
    val wordlistId: Long,
    val wordlistName: String,
    val mode: String, // AuditMode.name
    val status: String, // AuditStatus.name
    val processed: Int,
    val total: Int,
    val durationMillis: Long,
    val outcomeType: String, // "pending" | "matched" | "no_match" | "strength_summary" | "stopped" | "failed"
    val outcomeCandidate: String? = null, // Matched: the candidate that hit (only ever the sample/known credential, never a real Wi-Fi password)
    val outcomeMatchedAtIndex: Int? = null, // Matched
    val outcomeProcessedBeforeStop: Int? = null, // Stopped
    val outcomeFailReason: String? = null, // Failed
    val outcomeStrengthSummaryCsv: String? = null, // StrengthSummary, encoded "VERY_WEAK:3;WEAK:10;..."
    val authorizationConfirmed: Boolean,
    val notes: String,
    val createdAtEpochMillis: Long,
    val completedAtEpochMillis: Long?,
) {
    fun toDomain(): AuditSession = AuditSession(
        id = id,
        name = name,
        targetSsid = targetSsid,
        targetBssid = targetBssid,
        wordlistId = wordlistId,
        wordlistName = wordlistName,
        mode = AuditMode.valueOf(mode),
        status = AuditStatus.valueOf(status),
        processed = processed,
        total = total,
        durationMillis = durationMillis,
        result = decodeOutcome(),
        authorizationConfirmed = authorizationConfirmed,
        notes = notes,
        createdAtEpochMillis = createdAtEpochMillis,
        completedAtEpochMillis = completedAtEpochMillis,
    )

    private fun decodeOutcome(): AuditOutcome = when (outcomeType) {
        "matched" -> AuditOutcome.Matched(outcomeMatchedAtIndex ?: 0, outcomeCandidate ?: "")
        "no_match" -> AuditOutcome.NoMatch
        "strength_summary" -> AuditOutcome.StrengthSummary(decodeStrengthCsv(outcomeStrengthSummaryCsv))
        "stopped" -> AuditOutcome.Stopped(outcomeProcessedBeforeStop ?: processed)
        "failed" -> AuditOutcome.Failed(outcomeFailReason ?: "Unknown error")
        else -> AuditOutcome.Pending
    }

    private fun decodeStrengthCsv(csv: String?): Map<PasswordStrength, Int> {
        if (csv.isNullOrBlank()) return emptyMap()
        return csv.split(";").mapNotNull { entry ->
            val parts = entry.split(":")
            if (parts.size != 2) return@mapNotNull null
            runCatching { PasswordStrength.valueOf(parts[0]) to parts[1].toInt() }.getOrNull()
        }.toMap()
    }

    companion object {
        fun fromDomain(session: AuditSession): AuditSessionEntity {
            val outcome = session.result
            return AuditSessionEntity(
                id = session.id,
                name = session.name,
                targetSsid = session.targetSsid,
                targetBssid = session.targetBssid,
                wordlistId = session.wordlistId,
                wordlistName = session.wordlistName,
                mode = session.mode.name,
                status = session.status.name,
                processed = session.processed,
                total = session.total,
                durationMillis = session.durationMillis,
                outcomeType = when (outcome) {
                    is AuditOutcome.Pending -> "pending"
                    is AuditOutcome.Matched -> "matched"
                    is AuditOutcome.NoMatch -> "no_match"
                    is AuditOutcome.StrengthSummary -> "strength_summary"
                    is AuditOutcome.Stopped -> "stopped"
                    is AuditOutcome.Failed -> "failed"
                },
                outcomeCandidate = (outcome as? AuditOutcome.Matched)?.candidate,
                outcomeMatchedAtIndex = (outcome as? AuditOutcome.Matched)?.matchedAtIndex,
                outcomeProcessedBeforeStop = (outcome as? AuditOutcome.Stopped)?.processedBeforeStop,
                outcomeFailReason = (outcome as? AuditOutcome.Failed)?.reason,
                outcomeStrengthSummaryCsv = (outcome as? AuditOutcome.StrengthSummary)?.distribution
                    ?.entries?.joinToString(";") { "${it.key.name}:${it.value}" },
                authorizationConfirmed = session.authorizationConfirmed,
                notes = session.notes,
                createdAtEpochMillis = session.createdAtEpochMillis,
                completedAtEpochMillis = session.completedAtEpochMillis,
            )
        }
    }
}
