package com.fajer.wifiaudit.core.utils

import java.util.Locale
import kotlin.math.roundToLong

object TimeUtils {

    /** "00:00:47" style duration, growing to include hours only when needed. */
    fun formatDuration(millis: Long): String {
        val totalSeconds = (millis / 1000).coerceAtLeast(0)
        val hours = totalSeconds / 3600
        val minutes = (totalSeconds % 3600) / 60
        val seconds = totalSeconds % 60
        return if (hours > 0) {
            String.format(Locale.US, "%02d:%02d:%02d", hours, minutes, seconds)
        } else {
            String.format(Locale.US, "%02d:%02d", minutes, seconds)
        }
    }

    fun formatEta(millis: Long?): String = if (millis == null) "—" else formatDuration(millis)

    /** "3,850" style throughput, grouped for readability at high rates. */
    fun formatRate(ratePerSecond: Double): String =
        String.format(Locale.US, "%,d", ratePerSecond.roundToLong())

    fun estimateEtaMillis(processed: Int, total: Int, elapsedMillis: Long): Long? {
        if (processed <= 0 || total <= processed) return null
        val remaining = total - processed
        val perItemMillis = elapsedMillis.toDouble() / processed
        return (remaining * perItemMillis).roundToLong()
    }
}
