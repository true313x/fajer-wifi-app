package com.fajer.wifiaudit

import android.app.Application
import com.fajer.wifiaudit.core.common.AppContainer
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

class FajerApplication : Application() {

    lateinit var container: AppContainer
        private set

    private val applicationScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    override fun onCreate() {
        super.onCreate()
        container = AppContainer(this)

        // The built-in sample lab target backs "Offline Wordlist Simulation" mode — make sure
        // it exists from first launch so that mode works with zero setup.
        applicationScope.launch {
            container.labTargetRepository.ensureSampleTargetExists()
        }
    }
}
