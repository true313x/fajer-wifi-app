package com.fajer.wifiaudit.presentation.audit

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.Checkbox
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import androidx.navigation.NavHostController
import com.fajer.wifiaudit.R
import com.fajer.wifiaudit.core.ui.components.FajerPrimaryButton
import com.fajer.wifiaudit.core.ui.components.FajerSectionCard
import com.fajer.wifiaudit.domain.model.AuditMode
import com.fajer.wifiaudit.presentation.common.currentAppContainer
import com.fajer.wifiaudit.presentation.navigation.FajerRoute

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NewAuditScreen(navController: NavHostController) {
    val container = currentAppContainer()
    val viewModel: NewAuditViewModel = viewModel(
        factory = viewModelFactory {
            initializer {
                NewAuditViewModel(container.auditRepository, container.labTargetRepository, container.wordlistRepository)
            }
        }
    )
    val state by viewModel.uiState.collectAsStateWithLifecycle()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(stringResource(R.string.audit_new_title)) },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(Icons.Default.ArrowBack, contentDescription = null)
                    }
                },
            )
        },
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            OutlinedTextField(
                value = state.name,
                onValueChange = viewModel::setName,
                label = { Text(stringResource(R.string.field_audit_name)) },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
            )

            FajerSectionCard(title = stringResource(R.string.field_mode)) {
                AuditMode.entries.forEach { mode ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        androidx.compose.material3.RadioButton(
                            selected = state.mode == mode,
                            onClick = { viewModel.selectMode(mode) },
                        )
                        Column {
                            Text(mode.displayName(), style = MaterialTheme.typography.bodyMedium)
                            Text(
                                mode.description(),
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                    }
                }
            }

            if (state.mode != AuditMode.PASSWORD_STRENGTH_ANALYSIS) {
                LabelledDropdown(
                    label = stringResource(R.string.field_target_network),
                    options = state.availableTargets.map { it.id to "${it.ssid} (${it.bssid})" },
                    selectedId = state.selectedTargetId,
                    onSelect = viewModel::selectTarget,
                    emptyHint = stringResource(R.string.no_networks_in_lab),
                )
            }

            LabelledDropdown(
                label = stringResource(R.string.field_wordlist),
                options = state.availableWordlists.map { it.id to "${it.displayName} (${it.stats.totalLines})" },
                selectedId = state.selectedWordlistId,
                onSelect = viewModel::selectWordlist,
                emptyHint = stringResource(R.string.wordlists_empty_title),
            )

            if (state.mode == AuditMode.KNOWN_TEST_CREDENTIAL_SIMULATION) {
                OutlinedTextField(
                    value = state.knownCredential,
                    onValueChange = viewModel::setKnownCredential,
                    label = { Text(stringResource(R.string.known_credential_label)) },
                    supportingText = { Text(stringResource(R.string.known_credential_hint)) },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                )
            }

            OutlinedTextField(
                value = state.notes,
                onValueChange = viewModel::setNotes,
                label = { Text(stringResource(R.string.field_notes)) },
                modifier = Modifier.fillMaxWidth(),
                minLines = 2,
            )

            Row(verticalAlignment = Alignment.CenterVertically) {
                Checkbox(
                    checked = state.authorizationConfirmed,
                    onCheckedChange = viewModel::setAuthorizationConfirmed,
                )
                Text(
                    stringResource(R.string.authorization_confirmation),
                    style = MaterialTheme.typography.bodySmall,
                )
            }

            state.errorMessage?.let {
                Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
            }

            FajerPrimaryButton(
                text = stringResource(R.string.action_create_audit),
                enabled = state.canSubmit && !state.isSubmitting,
                onClick = {
                    viewModel.submit { sessionId ->
                        navController.navigate(FajerRoute.auditRun(sessionId)) {
                            popUpTo(FajerRoute.Dashboard)
                        }
                    }
                },
                modifier = Modifier.fillMaxWidth(),
            )
        }
    }
}

private fun AuditMode.displayName(): String = when (this) {
    AuditMode.PASSWORD_STRENGTH_ANALYSIS -> "Password Strength Analysis"
    AuditMode.OFFLINE_WORDLIST_SIMULATION -> "Offline Wordlist Simulation"
    AuditMode.KNOWN_TEST_CREDENTIAL_SIMULATION -> "Known-Test-Credential Simulation"
}

private fun AuditMode.description(): String = when (this) {
    AuditMode.PASSWORD_STRENGTH_ANALYSIS -> "Score every candidate in the wordlist for strength. No target network needed."
    AuditMode.OFFLINE_WORDLIST_SIMULATION -> "Run the wordlist against the built-in synthetic lab target to see the engine in action."
    AuditMode.KNOWN_TEST_CREDENTIAL_SIMULATION -> "Check whether a credential you already know appears in the wordlist."
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun LabelledDropdown(
    label: String,
    options: List<Pair<Long, String>>,
    selectedId: Long?,
    onSelect: (Long) -> Unit,
    emptyHint: String,
) {
    var expanded by remember { mutableStateOf(false) }
    val selectedText = options.firstOrNull { it.first == selectedId }?.second.orEmpty()

    if (options.isEmpty()) {
        FajerSectionCard {
            Text(emptyHint, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        return
    }

    ExposedDropdownMenuBox(expanded = expanded, onExpandedChange = { expanded = it }) {
        OutlinedTextField(
            value = selectedText,
            onValueChange = {},
            readOnly = true,
            label = { Text(label) },
            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expanded) },
            modifier = Modifier
                .fillMaxWidth()
                .menuAnchor(),
        )
        androidx.compose.material3.ExposedDropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
            options.forEach { (id, text) ->
                DropdownMenuItem(
                    text = { Text(text) },
                    onClick = {
                        onSelect(id)
                        expanded = false
                    },
                )
            }
        }
    }
}
