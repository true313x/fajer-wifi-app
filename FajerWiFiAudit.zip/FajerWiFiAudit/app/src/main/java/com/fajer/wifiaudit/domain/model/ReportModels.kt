package com.fajer.wifiaudit.domain.model

enum class ReportFormat {
    TXT,
    CSV,
    JSON,
    PDF
}

/** Everything a generated report is allowed to contain. Notably absent: any real credential —
 *  only the synthetic lab credential's *match status*, never the wordlist candidate that
 *  matched it, is ever written out, and only when the user has explicitly entered that
 *  candidate themselves via Known-Test-Credential mode. */
data class ReportData(
    val appVersionName: String,
    val session: AuditSession,
    val generatedAtEpochMillis: Long
)
