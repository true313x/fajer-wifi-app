package com.fajer.wifiaudit.core.security

import com.fajer.wifiaudit.domain.model.PasswordAnalysisResult
import com.fajer.wifiaudit.domain.model.PasswordStrength
import kotlin.math.ln
import kotlin.math.max

/**
 * Scores a single candidate string for how hard it would be to guess. This is analysis only:
 * it never attempts to use a candidate to authenticate anywhere, and it never leaves the
 * device — everything here is a pure function of the input string.
 */
object PasswordStrengthAnalyzer {

    fun analyze(candidate: String): PasswordAnalysisResult {
        val hasLower = candidate.any { it.isLowerCase() }
        val hasUpper = candidate.any { it.isUpperCase() }
        val hasDigit = candidate.any { it.isDigit() }
        val hasSymbol = candidate.any { !it.isLetterOrDigit() }

        val poolSize = (if (hasLower) 26 else 0) +
            (if (hasUpper) 26 else 0) +
            (if (hasDigit) 10 else 0) +
            (if (hasSymbol) 33 else 0)

        val rawEntropy = if (poolSize == 0 || candidate.isEmpty()) {
            0.0
        } else {
            candidate.length * (ln(poolSize.toDouble()) / ln(2.0))
        }

        val repeated = hasRepeatedRun(candidate)
        val sequential = hasSequentialRun(candidate)
        val common = isCommonPassword(candidate)

        // Patterns make a string far easier to guess than raw entropy implies, so we penalize
        // the effective score rather than just reporting the theoretical figure.
        var effectiveEntropy = rawEntropy
        if (repeated) effectiveEntropy *= 0.6
        if (sequential) effectiveEntropy *= 0.6
        if (common) effectiveEntropy = max(0.0, effectiveEntropy - 40.0)

        val strength = classify(effectiveEntropy, common)

        return PasswordAnalysisResult(
            candidate = candidate,
            length = candidate.length,
            entropyBits = rawEntropy,
            strength = strength,
            hasLowercase = hasLower,
            hasUppercase = hasUpper,
            hasDigit = hasDigit,
            hasSymbol = hasSymbol,
            hasRepeatedRun = repeated,
            hasSequentialRun = sequential,
            isCommonPassword = common
        )
    }

    private fun classify(effectiveEntropy: Double, isCommon: Boolean): PasswordStrength {
        if (isCommon) return PasswordStrength.VERY_WEAK
        return when {
            effectiveEntropy < 28 -> PasswordStrength.VERY_WEAK
            effectiveEntropy < 36 -> PasswordStrength.WEAK
            effectiveEntropy < 60 -> PasswordStrength.MODERATE
            effectiveEntropy < 80 -> PasswordStrength.STRONG
            else -> PasswordStrength.VERY_STRONG
        }
    }

    /** Three or more identical characters in a row, e.g. "aaa" or "111". */
    private fun hasRepeatedRun(candidate: String, runLength: Int = 3): Boolean {
        if (candidate.length < runLength) return false
        var streak = 1
        for (i in 1 until candidate.length) {
            streak = if (candidate[i] == candidate[i - 1]) streak + 1 else 1
            if (streak >= runLength) return true
        }
        return false
    }

    /** Three or more ascending/descending characters in sequence, e.g. "abcd", "4321". */
    private fun hasSequentialRun(candidate: String, runLength: Int = 3): Boolean {
        if (candidate.length < runLength) return false
        var ascStreak = 1
        var descStreak = 1
        for (i in 1 until candidate.length) {
            val diff = candidate[i].code - candidate[i - 1].code
            ascStreak = if (diff == 1) ascStreak + 1 else 1
            descStreak = if (diff == -1) descStreak + 1 else 1
            if (ascStreak >= runLength || descStreak >= runLength) return true
        }
        return KEYBOARD_SEQUENCES.any { candidate.lowercase().contains(it) }
    }

    private fun isCommonPassword(candidate: String): Boolean =
        COMMON_PASSWORDS.contains(candidate.lowercase())

    // A small, well-known set of frequently reused passwords/keyboard walks. This is a
    // representative sample for local, offline heuristic scoring — not an exhaustive
    // credential-stuffing list.
    private val KEYBOARD_SEQUENCES = listOf(
        "qwerty", "asdfgh", "zxcvbn", "qazwsx", "1qaz2wsx", "qwertyuiop"
    )

    private val COMMON_PASSWORDS = setOf(
        "password", "123456", "12345678", "123456789", "1234567890", "qwerty", "abc123",
        "password1", "111111", "123123", "admin", "admin123", "letmein", "welcome",
        "monkey", "dragon", "master", "iloveyou", "sunshine", "princess", "football",
        "baseball", "shadow", "michael", "superman", "trustno1", "passw0rd", "starwars",
        "qwerty123", "000000", "666666", "121212", "1q2w3e4r", "zaq12wsx", "login",
        "changeme", "default", "guest", "root", "toor", "test", "user"
    )
}
