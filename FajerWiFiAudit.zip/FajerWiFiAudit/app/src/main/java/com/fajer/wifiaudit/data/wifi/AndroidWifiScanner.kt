package com.fajer.wifiaudit.data.wifi

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.wifi.WifiManager
import android.os.Build
import androidx.core.content.ContextCompat
import com.fajer.wifiaudit.core.common.AppResult
import com.fajer.wifiaudit.core.permissions.PermissionManager
import com.fajer.wifiaudit.core.utils.SecurityClassifier
import com.fajer.wifiaudit.domain.model.WifiNetwork
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withTimeoutOrNull
import kotlin.coroutines.resume

/**
 * Thin wrapper around [WifiManager]. This is the *only* file in the app that calls a Wi-Fi
 * scanning API — everything else works with [WifiNetwork], the plain data class above it.
 *
 * What this class does NOT do, by design: request a connection, supply a password to
 * [WifiManager] or [android.net.wifi.WifiNetworkSuggestion], or attempt authentication of any
 * kind. It only reads [android.net.wifi.ScanResult]s the platform already collected.
 */
class AndroidWifiScanner(private val context: Context) {

    private val wifiManager: WifiManager? by lazy {
        context.applicationContext.getSystemService(Context.WIFI_SERVICE) as? WifiManager
    }

    suspend fun scan(): AppResult<List<WifiNetwork>> {
        val manager = wifiManager
            ?: return AppResult.Error("This device has no Wi-Fi adapter")

        if (!PermissionManager.hasScanPermission(context)) {
            return AppResult.Error("Wi-Fi scan permission is not granted")
        }
        if (!manager.isWifiEnabled) {
            return AppResult.Error("Wi-Fi is disabled")
        }

        // WifiManager.startScan() is deprecated but remains the only public trigger for an
        // on-demand scan; apps are also throttled to a handful of calls per period by the
        // platform, which is expected and handled gracefully below (we fall back to whatever
        // scanResults already holds when a fresh scan is throttled).
        val scanTriggered = requestScan(manager)
        if (scanTriggered) {
            // Give the system a moment to publish results via the broadcast below; if it
            // never arrives (throttled), we still read whatever is currently cached.
            awaitScanResultsBroadcast(manager, timeoutMs = 4_000)
        }

        return try {
            @Suppress("MissingPermission") // Verified above via PermissionManager.
            val results = manager.scanResults.orEmpty()
            val networks = results
                .distinctBy { it.BSSID }
                .map { result ->
                    WifiNetwork(
                        ssid = result.SSID.orEmpty(),
                        bssid = result.BSSID.orEmpty(),
                        rssiDbm = result.level,
                        frequencyMhz = result.frequency,
                        capabilities = result.capabilities.orEmpty(),
                        securityType = SecurityClassifier.classify(result.capabilities.orEmpty()),
                        wifiStandard = wifiStandardLabel(result),
                        lastSeenEpochMillis = System.currentTimeMillis(),
                    )
                }
                .sortedByDescending { it.rssiDbm }
            AppResult.Success(networks)
        } catch (e: SecurityException) {
            AppResult.Error("Permission was revoked while scanning", e)
        }
    }

    private fun requestScan(manager: WifiManager): Boolean = try {
        @Suppress("DEPRECATION", "MissingPermission")
        manager.startScan()
    } catch (_: SecurityException) {
        false
    }

    private suspend fun awaitScanResultsBroadcast(manager: WifiManager, timeoutMs: Long) {
        withTimeoutOrNull(timeoutMs) {
            suspendCancellableCoroutine<Unit> { continuation ->
                val receiver = object : BroadcastReceiver() {
                    override fun onReceive(ctx: Context?, intent: Intent?) {
                        if (continuation.isActive) continuation.resume(Unit)
                    }
                }
                ContextCompat.registerReceiver(
                    context,
                    receiver,
                    IntentFilter(WifiManager.SCAN_RESULTS_AVAILABLE_ACTION),
                    ContextCompat.RECEIVER_NOT_EXPORTED,
                )
                continuation.invokeOnCancellation {
                    runCatching { context.unregisterReceiver(receiver) }
                }
            }
        }
    }

    /** Best-effort label — [android.net.wifi.ScanResult] only exposes this from API 30+. */
    private fun wifiStandardLabel(result: android.net.wifi.ScanResult): String? {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.R) return null
        return try {
            when (result.wifiStandard) {
                4 -> "802.11n (Wi-Fi 4)"
                5 -> "802.11ac (Wi-Fi 5)"
                6 -> "802.11ax (Wi-Fi 6)"
                8 -> "802.11be (Wi-Fi 7)"
                else -> null
            }
        } catch (_: Exception) {
            null
        }
    }

    /** Currently associated network, read via ConnectivityManager capabilities where possible. */
    fun observeConnectivity() = callbackFlow<Boolean> {
        val manager = wifiManager
        trySend(manager?.isWifiEnabled == true)
        val receiver = object : BroadcastReceiver() {
            override fun onReceive(ctx: Context?, intent: Intent?) {
                trySend(wifiManager?.isWifiEnabled == true)
            }
        }
        ContextCompat.registerReceiver(
            context,
            receiver,
            IntentFilter(WifiManager.WIFI_STATE_CHANGED_ACTION),
            ContextCompat.RECEIVER_NOT_EXPORTED,
        )
        awaitClose { runCatching { context.unregisterReceiver(receiver) } }
    }
}
