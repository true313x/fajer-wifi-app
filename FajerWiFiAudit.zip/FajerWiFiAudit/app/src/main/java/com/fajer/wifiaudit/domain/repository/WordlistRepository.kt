package com.fajer.wifiaudit.domain.repository

import com.fajer.wifiaudit.core.common.AppResult
import com.fajer.wifiaudit.domain.model.Wordlist
import com.fajer.wifiaudit.domain.model.WordlistPreferences
import kotlinx.coroutines.flow.Flow

interface WordlistRepository {

    fun observeWordlists(): Flow<List<Wordlist>>

    fun observeWordlist(id: Long): Flow<Wordlist?>

    /** Streams and analyzes the file at [uriString] without loading it fully into memory. */
    suspend fun import(
        uriString: String,
        displayName: String,
        preferences: WordlistPreferences
    ): AppResult<Wordlist>

    suspend fun rename(id: Long, newName: String): AppResult<Unit>

    suspend fun duplicate(id: Long): AppResult<Wordlist>

    suspend fun delete(id: Long): AppResult<Unit>

    /** Lazily streams every candidate line for use by the audit engine, without buffering the
     *  whole file in memory. */
    fun streamCandidates(id: Long): Flow<String>

    suspend fun installSampleWordlist(): AppResult<Wordlist>
}
