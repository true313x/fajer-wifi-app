package com.fajer.wifiaudit.presentation.dashboard

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.fajer.wifiaudit.core.permissions.PermissionState
import com.fajer.wifiaudit.domain.model.AuditSession
import com.fajer.wifiaudit.domain.repository.AuditRepository
import com.fajer.wifiaudit.domain.repository.WifiRepository
import com.fajer.wifiaudit.domain.repository.WordlistRepository
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn

data class DashboardUiState(
    val permissionState: PermissionState = PermissionState.Unknown,
    val wordlistCount: Int = 0,
    val auditSessionCount: Int = 0,
    val recentSessions: List<AuditSession> = emptyList(),
)

class DashboardViewModel(
    private val wifiRepository: WifiRepository,
    wordlistRepository: WordlistRepository,
    auditRepository: AuditRepository,
) : ViewModel() {

    val uiState: StateFlow<DashboardUiState> = combine(
        wifiRepository.observePermissionState(),
        wordlistRepository.observeWordlists(),
        auditRepository.observeSessions(),
    ) { permissionState, wordlists, sessions ->
        DashboardUiState(
            permissionState = permissionState,
            wordlistCount = wordlists.size,
            auditSessionCount = sessions.size,
            recentSessions = sessions.take(3),
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), DashboardUiState())

    /** Re-checks permission/adapter state — call from onResume-equivalent (e.g. after the
     *  system permission dialog or a trip to Settings closes). */
    fun refreshPermissionState() {
        wifiRepository.refreshPermissionState()
    }
}
