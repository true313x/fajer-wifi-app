package com.fajer.wifiaudit.domain.model

/** A wordlist the user has imported, tracked by metadata only — the entries themselves live
 *  in the file the user picked via Storage Access Framework, referenced by a persisted URI
 *  permission. We never copy large wordlists into app-private storage. */
data class Wordlist(
    val id: Long = 0,
    val displayName: String,
    val uri: String,
    val sizeBytes: Long,
    val encoding: String,
    val stats: WordlistStats,
    val importedAtEpochMillis: Long
)

data class WordlistStats(
    val totalLines: Int,
    val uniqueLines: Int,
    val duplicateCount: Int,
    val emptyLinesRemoved: Int,
    val averageLength: Double,
    val minimumLength: Int,
    val maximumLength: Int,
    val numericOnlyCount: Int,
    val alphabeticOnlyCount: Int,
    val mixedCount: Int,
    val specialCharacterCount: Int,
    val unicodeCount: Int,
    val lengthDistribution: Map<LengthBucket, Int>
) {
    companion object {
        val EMPTY = WordlistStats(
            totalLines = 0,
            uniqueLines = 0,
            duplicateCount = 0,
            emptyLinesRemoved = 0,
            averageLength = 0.0,
            minimumLength = 0,
            maximumLength = 0,
            numericOnlyCount = 0,
            alphabeticOnlyCount = 0,
            mixedCount = 0,
            specialCharacterCount = 0,
            unicodeCount = 0,
            lengthDistribution = LengthBucket.entries.associateWith { 0 }
        )
    }
}

enum class LengthBucket(val rangeLabel: String) {
    LEN_1_5("1-5"),
    LEN_6_7("6-7"),
    LEN_8_10("8-10"),
    LEN_11_15("11-15"),
    LEN_16_PLUS("16+");

    companion object {
        fun forLength(length: Int): LengthBucket = when {
            length <= 5 -> LEN_1_5
            length <= 7 -> LEN_6_7
            length <= 10 -> LEN_8_10
            length <= 15 -> LEN_11_15
            else -> LEN_16_PLUS
        }
    }
}

/** User-configurable wordlist import behavior, mirrored in Settings. */
data class WordlistPreferences(
    val trimWhitespace: Boolean = true,
    val deduplicate: Boolean = false,
    val ignoreEmptyLines: Boolean = true
)
