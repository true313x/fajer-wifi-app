package com.fajer.wifiaudit.domain.model

enum class PasswordStrength {
    VERY_WEAK,
    WEAK,
    MODERATE,
    STRONG,
    VERY_STRONG
}

/**
 * Result of scoring a single candidate string entirely offline. This is pattern/entropy
 * analysis only — it never attempts to use the candidate to authenticate anywhere.
 */
data class PasswordAnalysisResult(
    val candidate: String,
    val length: Int,
    val entropyBits: Double,
    val strength: PasswordStrength,
    val hasLowercase: Boolean,
    val hasUppercase: Boolean,
    val hasDigit: Boolean,
    val hasSymbol: Boolean,
    val hasRepeatedRun: Boolean,
    val hasSequentialRun: Boolean,
    val isCommonPassword: Boolean
)
