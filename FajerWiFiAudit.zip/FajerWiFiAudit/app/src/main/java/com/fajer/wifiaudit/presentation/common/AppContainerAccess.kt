package com.fajer.wifiaudit.presentation.common

import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalContext
import com.fajer.wifiaudit.FajerApplication
import com.fajer.wifiaudit.core.common.AppContainer

/** Every screen's ViewModel factory pulls its repositories from here instead of each screen
 *  reaching into [FajerApplication] directly — keeps the composition root swappable for tests. */
@Composable
fun currentAppContainer(): AppContainer =
    (LocalContext.current.applicationContext as FajerApplication).container
