package com.fajer.wifiaudit.domain.model

/**
 * Security classification parsed from a scan result's capability string. [UNKNOWN] is a first
 *-class outcome, not a fallback to hide behind — the UI must be able to say "we could not
 * reliably determine this" rather than guessing.
 */
enum class SecurityType {
    OPEN,
    WEP,
    WPA,
    WPA2,
    WPA3,
    UNKNOWN
}

/**
 * A single Wi-Fi network as observed by the on-device scanner. Every field here comes from
 * information the Android platform already exposes to any app holding the scan permission —
 * nothing is derived by contacting the network itself.
 */
data class WifiNetwork(
    val ssid: String,
    val bssid: String,
    val rssiDbm: Int,
    val frequencyMhz: Int,
    val capabilities: String,
    val securityType: SecurityType,
    val wifiStandard: String?,
    val lastSeenEpochMillis: Long
) {
    val signalPercent: Int
        get() = com.fajer.wifiaudit.core.utils.SignalUtils.rssiToPercent(rssiDbm)

    val channel: Int
        get() = com.fajer.wifiaudit.core.utils.SignalUtils.frequencyToChannel(frequencyMhz)

    val isHidden: Boolean
        get() = ssid.isBlank()
}

/** A network the user has explicitly added to their local lab as an audit target. */
data class LabTarget(
    val id: Long = 0,
    val ssid: String,
    val bssid: String,
    val securityType: SecurityType,
    val syntheticCredential: String,
    val isBuiltInSample: Boolean,
    val addedAtEpochMillis: Long
)
