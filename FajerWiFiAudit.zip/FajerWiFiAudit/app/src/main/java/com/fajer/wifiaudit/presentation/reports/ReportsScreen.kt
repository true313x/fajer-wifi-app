package com.fajer.wifiaudit.presentation.reports

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import androidx.navigation.NavHostController
import com.fajer.wifiaudit.R
import com.fajer.wifiaudit.core.ui.components.EmptyState
import com.fajer.wifiaudit.core.ui.components.FajerPrimaryButton
import com.fajer.wifiaudit.core.ui.components.FajerSectionCard
import com.fajer.wifiaudit.domain.model.ReportFormat
import com.fajer.wifiaudit.presentation.common.currentAppContainer
import com.fajer.wifiaudit.presentation.navigation.FajerRoute

@Composable
fun ReportsScreen(navController: NavHostController) {
    val container = currentAppContainer()
    val viewModel: ReportsViewModel = viewModel(
        factory = viewModelFactory { initializer { ReportsViewModel(container.auditRepository) } }
    )
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    val context = LocalContext.current
    var pendingFileName by remember { mutableStateOf("fajer-report.txt") }

    val createDocumentLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("*/*"),
    ) { uri ->
        if (uri != null) viewModel.generateAndSave(context, uri)
    }

    Scaffold(
        topBar = { TopAppBar(title = { Text(stringResource(R.string.reports_title)) }) },
    ) { innerPadding ->
        if (state.completedSessions.isEmpty()) {
            EmptyState(
                title = stringResource(R.string.reports_empty_title),
                body = stringResource(R.string.reports_empty_body),
                actionLabel = stringResource(R.string.audits_empty_action),
                onAction = { navController.navigate(FajerRoute.NewAudit) },
                modifier = Modifier.fillMaxSize().padding(innerPadding),
            )
            return@Scaffold
        }

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            FajerSectionCard(title = stringResource(R.string.report_select_audit)) {
                state.completedSessions.forEach { session ->
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 2.dp),
                    ) {
                        androidx.compose.foundation.layout.Row(
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            RadioButton(
                                selected = state.selectedSessionId == session.id,
                                onClick = { viewModel.selectSession(session.id) },
                            )
                            Text(session.name, style = MaterialTheme.typography.bodyMedium)
                        }
                    }
                }
            }

            FajerSectionCard(title = stringResource(R.string.report_select_format)) {
                ReportFormat.entries.forEach { format ->
                    androidx.compose.foundation.layout.Row(verticalAlignment = Alignment.CenterVertically) {
                        RadioButton(
                            selected = state.selectedFormat == format,
                            onClick = { viewModel.selectFormat(format) },
                        )
                        Text(format.name, style = MaterialTheme.typography.bodyMedium)
                    }
                }
            }

            state.statusMessage?.let {
                Text(it, color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.bodySmall)
            }

            FajerPrimaryButton(
                text = stringResource(R.string.action_generate),
                onClick = {
                    val session = state.completedSessions.firstOrNull { it.id == state.selectedSessionId }
                    val ext = state.selectedFormat.name.lowercase()
                    pendingFileName = "fajer-${session?.name?.replace(" ", "_") ?: "report"}.$ext"
                    createDocumentLauncher.launch(pendingFileName)
                },
                modifier = Modifier.fillMaxWidth(),
            )
        }
    }
}
