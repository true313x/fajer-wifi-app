package com.fajer.wifiaudit.domain.repository

import com.fajer.wifiaudit.core.common.AppResult
import com.fajer.wifiaudit.domain.model.AuditLogEntry
import com.fajer.wifiaudit.domain.model.AuditLogEvent
import com.fajer.wifiaudit.domain.model.AuditSession
import kotlinx.coroutines.flow.Flow

interface AuditRepository {

    fun observeSessions(): Flow<List<AuditSession>>

    fun observeSession(id: Long): Flow<AuditSession?>

    suspend fun createSession(session: AuditSession): AppResult<AuditSession>

    suspend fun updateSession(session: AuditSession): AppResult<Unit>

    suspend fun deleteSession(id: Long): AppResult<Unit>

    fun observeLogs(auditSessionId: Long?): Flow<List<AuditLogEntry>>

    suspend fun log(event: AuditLogEvent, detail: String, auditSessionId: Long? = null)
}
