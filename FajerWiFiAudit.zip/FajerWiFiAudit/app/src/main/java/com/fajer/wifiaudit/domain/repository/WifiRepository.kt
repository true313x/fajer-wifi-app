package com.fajer.wifiaudit.domain.repository

import com.fajer.wifiaudit.core.common.AppResult
import com.fajer.wifiaudit.core.permissions.PermissionState
import com.fajer.wifiaudit.domain.model.WifiNetwork
import kotlinx.coroutines.flow.Flow

interface WifiRepository {

    /** Current permission/adapter/service readiness, re-evaluated on demand. */
    fun observePermissionState(): Flow<PermissionState>

    /** Most recent scan results. Empty until the first successful scan. */
    fun observeNetworks(): Flow<List<WifiNetwork>>

    /** Requests a fresh scan. Suspends until results are delivered or the request fails. */
    suspend fun scan(): AppResult<List<WifiNetwork>>

    fun refreshPermissionState()
}
