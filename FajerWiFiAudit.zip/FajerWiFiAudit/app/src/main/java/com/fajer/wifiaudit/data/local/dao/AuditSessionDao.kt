package com.fajer.wifiaudit.data.local.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update
import com.fajer.wifiaudit.data.local.entities.AuditSessionEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface AuditSessionDao {
    @Insert
    suspend fun insert(session: AuditSessionEntity): Long

    @Update
    suspend fun update(session: AuditSessionEntity)

    @Delete
    suspend fun delete(session: AuditSessionEntity)

    @Query("DELETE FROM audit_sessions WHERE id = :id")
    suspend fun deleteById(id: Long)

    @Query("SELECT * FROM audit_sessions WHERE id = :id LIMIT 1")
    suspend fun getById(id: Long): AuditSessionEntity?

    @Query("SELECT * FROM audit_sessions WHERE id = :id LIMIT 1")
    fun observeById(id: Long): Flow<AuditSessionEntity?>

    @Query("SELECT * FROM audit_sessions ORDER BY createdAtEpochMillis DESC")
    fun observeAll(): Flow<List<AuditSessionEntity>>

    @Query("DELETE FROM audit_sessions")
    suspend fun deleteAll()

    @Query("SELECT COUNT(*) FROM audit_sessions")
    suspend fun count(): Int

    @Query("SELECT * FROM audit_sessions WHERE status IN ('RUNNING', 'PAUSED', 'PREPARING') LIMIT 1")
    suspend fun getActiveSession(): AuditSessionEntity?
}
