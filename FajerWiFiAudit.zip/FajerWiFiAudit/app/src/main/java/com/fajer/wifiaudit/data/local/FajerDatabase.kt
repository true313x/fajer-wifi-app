package com.fajer.wifiaudit.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.fajer.wifiaudit.core.common.FajerConstants
import com.fajer.wifiaudit.data.local.dao.AuditLogDao
import com.fajer.wifiaudit.data.local.dao.AuditSessionDao
import com.fajer.wifiaudit.data.local.dao.LabTargetDao
import com.fajer.wifiaudit.data.local.dao.WordlistDao
import com.fajer.wifiaudit.data.local.entities.AuditLogEntity
import com.fajer.wifiaudit.data.local.entities.AuditSessionEntity
import com.fajer.wifiaudit.data.local.entities.LabTargetEntity
import com.fajer.wifiaudit.data.local.entities.WordlistEntity

@Database(
    entities = [
        AuditSessionEntity::class,
        WordlistEntity::class,
        AuditLogEntity::class,
        LabTargetEntity::class,
    ],
    version = 1,
    exportSchema = true,
)
abstract class FajerDatabase : RoomDatabase() {
    abstract fun auditSessionDao(): AuditSessionDao
    abstract fun wordlistDao(): WordlistDao
    abstract fun auditLogDao(): AuditLogDao
    abstract fun labTargetDao(): LabTargetDao

    companion object {
        @Volatile
        private var instance: FajerDatabase? = null

        fun getInstance(context: Context): FajerDatabase =
            instance ?: synchronized(this) {
                instance ?: Room.databaseBuilder(
                    context.applicationContext,
                    FajerDatabase::class.java,
                    FajerConstants.DATABASE_NAME,
                ).build().also { instance = it }
            }
    }
}
