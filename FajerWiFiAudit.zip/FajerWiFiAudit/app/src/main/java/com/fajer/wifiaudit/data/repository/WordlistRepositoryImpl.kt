package com.fajer.wifiaudit.data.repository

import android.content.Context
import android.net.Uri
import com.fajer.wifiaudit.core.common.AppResult
import com.fajer.wifiaudit.core.common.FajerConstants
import com.fajer.wifiaudit.core.storage.WordlistFileReader
import com.fajer.wifiaudit.core.storage.WordlistStatsCalculator
import com.fajer.wifiaudit.data.local.dao.WordlistDao
import com.fajer.wifiaudit.data.local.entities.WordlistEntity
import com.fajer.wifiaudit.domain.model.Wordlist
import com.fajer.wifiaudit.domain.model.WordlistPreferences
import com.fajer.wifiaudit.domain.repository.WordlistRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext

class WordlistRepositoryImpl(
    private val context: Context,
    private val dao: WordlistDao,
) : WordlistRepository {

    override fun observeWordlists(): Flow<List<Wordlist>> =
        dao.observeAll().map { entities -> entities.map { it.toDomain() } }

    override fun observeWordlist(id: Long): Flow<Wordlist?> =
        dao.observeById(id).map { it?.toDomain() }

    override suspend fun import(
        uriString: String,
        displayName: String,
        preferences: WordlistPreferences,
    ): AppResult<Wordlist> = withContext(Dispatchers.IO) {
        try {
            val uri = Uri.parse(uriString)
            val sizeBytes = WordlistFileReader.querySize(context, uri)
            val charset = WordlistFileReader.detectCharset(context, uri)
            val lines = WordlistFileReader.lineSequence(context, uri, charset)
            val stats = WordlistStatsCalculator.compute(lines, preferences)

            if (stats.totalLines == 0) {
                return@withContext AppResult.Error("This file doesn't look like a valid wordlist")
            }

            // Persist a durable permission so the file remains readable across app restarts —
            // required because we never copy the wordlist into app-private storage.
            runCatching {
                context.contentResolver.takePersistableUriPermission(
                    uri,
                    android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION,
                )
            }

            val wordlist = Wordlist(
                displayName = displayName,
                uri = uriString,
                sizeBytes = sizeBytes,
                encoding = charset.name(),
                stats = stats,
                importedAtEpochMillis = System.currentTimeMillis(),
            )
            val id = dao.insert(WordlistEntity.fromDomain(wordlist))
            AppResult.Success(wordlist.copy(id = id))
        } catch (e: Exception) {
            AppResult.Error(e.message ?: "Could not read the selected file", e)
        }
    }

    override suspend fun rename(id: Long, newName: String): AppResult<Unit> = withContext(Dispatchers.IO) {
        val entity = dao.getById(id) ?: return@withContext AppResult.Error("Wordlist not found")
        dao.update(entity.copy(displayName = newName))
        AppResult.Success(Unit)
    }

    override suspend fun duplicate(id: Long): AppResult<Wordlist> = withContext(Dispatchers.IO) {
        val entity = dao.getById(id) ?: return@withContext AppResult.Error("Wordlist not found")
        val copy = entity.copy(
            id = 0,
            displayName = "${entity.displayName} (copy)",
            importedAtEpochMillis = System.currentTimeMillis(),
        )
        val newId = dao.insert(copy)
        AppResult.Success(copy.copy(id = newId).toDomain())
    }

    override suspend fun delete(id: Long): AppResult<Unit> = withContext(Dispatchers.IO) {
        val entity = dao.getById(id) ?: return@withContext AppResult.Success(Unit)
        dao.delete(entity)
        AppResult.Success(Unit)
    }

    override fun streamCandidates(id: Long): Flow<String> = flow {
        val entity = dao.getById(id) ?: return@flow
        if (entity.uri.startsWith(SAMPLE_URI_PREFIX)) {
            FajerConstants.SAMPLE_WORDLIST_ENTRIES.forEach { emit(it) }
            return@flow
        }
        val uri = Uri.parse(entity.uri)
        val charset = runCatching { charset(entity.encoding) }.getOrDefault(Charsets.UTF_8)
        WordlistFileReader.lineSequence(context, uri, charset).forEach { emit(it) }
    }

    override suspend fun installSampleWordlist(): AppResult<Wordlist> = withContext(Dispatchers.IO) {
        val existing = dao.countByName(SAMPLE_DISPLAY_NAME)
        if (existing > 0) {
            return@withContext AppResult.Error("Sample wordlist is already installed")
        }
        val stats = WordlistStatsCalculator.compute(
            FajerConstants.SAMPLE_WORDLIST_ENTRIES.asSequence(),
            WordlistPreferences(),
        )
        val wordlist = Wordlist(
            displayName = SAMPLE_DISPLAY_NAME,
            uri = "$SAMPLE_URI_PREFIX$SAMPLE_DISPLAY_NAME",
            sizeBytes = FajerConstants.SAMPLE_WORDLIST_ENTRIES.sumOf { it.toByteArray().size },
            encoding = "UTF-8",
            stats = stats,
            importedAtEpochMillis = System.currentTimeMillis(),
        )
        val id = dao.insert(WordlistEntity.fromDomain(wordlist))
        AppResult.Success(wordlist.copy(id = id))
    }

    companion object {
        private const val SAMPLE_URI_PREFIX = "fajer://sample-wordlist/"
        private const val SAMPLE_DISPLAY_NAME = "FAJER Sample Wordlist"
    }
}
