package com.fajer.wifiaudit.core.model

enum class ThemeMode {
    SYSTEM,
    LIGHT,
    DARK
}
