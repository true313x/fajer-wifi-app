package com.fajer.wifiaudit.core.storage

import android.content.Context
import android.net.Uri
import com.fajer.wifiaudit.domain.model.AuditOutcome
import com.fajer.wifiaudit.domain.model.ReportData
import com.fajer.wifiaudit.domain.model.ReportFormat
import java.text.DateFormat
import java.util.Date

/**
 * Turns a completed audit into report text. Every format below writes the *outcome type* —
 * matched/no-match/stopped/etc — but for [AuditOutcome.Matched] only ever writes the fixed
 * string "Synthetic credential matched"; the actual candidate string is deliberately never
 * included, even though the engine knows it, so a report can never leak a real Wi-Fi password
 * a Known-Test-Credential run happened to be checking for.
 */
object ReportFileWriter {

    fun render(report: ReportData, format: ReportFormat): String = when (format) {
        ReportFormat.TXT -> renderTxt(report)
        ReportFormat.CSV -> renderCsv(report)
        ReportFormat.JSON -> renderJson(report)
        ReportFormat.PDF -> renderTxt(report) // PDF layout reuses the TXT body as its page text.
    }

    fun writeToUri(context: Context, uri: Uri, content: String) {
        context.contentResolver.openOutputStream(uri)?.use { output ->
            output.write(content.toByteArray(Charsets.UTF_8))
        }
    }

    private fun outcomeLabel(outcome: AuditOutcome): String = when (outcome) {
        is AuditOutcome.Matched -> "Synthetic credential matched"
        is AuditOutcome.NoMatch -> "No match found"
        is AuditOutcome.Stopped -> "Stopped before completion (${outcome.processedBeforeStop} processed)"
        is AuditOutcome.Failed -> "Failed: ${outcome.reason}"
        is AuditOutcome.StrengthSummary -> "Strength analysis: " + outcome.distribution.entries
            .joinToString(", ") { "${it.key.name}=${it.value}" }
        is AuditOutcome.Pending -> "Pending"
    }

    private fun renderTxt(report: ReportData): String {
        val s = report.session
        val df = DateFormat.getDateTimeInstance(DateFormat.MEDIUM, DateFormat.SHORT)
        return buildString {
            appendLine("FAJER WiFi Audit Report")
            appendLine("App version: ${report.appVersionName}")
            appendLine("Generated: ${df.format(Date(report.generatedAtEpochMillis))}")
            appendLine()
            appendLine("Audit name: ${s.name}")
            appendLine("Target SSID: ${s.targetSsid.ifBlank { "(none)" }}")
            appendLine("Target BSSID: ${s.targetBssid.ifBlank { "(none)" }}")
            appendLine("Wordlist: ${s.wordlistName}")
            appendLine("Mode: ${s.mode.name}")
            appendLine("Entries: ${s.total}")
            appendLine("Processed: ${s.processed}")
            appendLine("Duration: ${s.durationMillis} ms")
            appendLine("Result: ${outcomeLabel(s.result)}")
            appendLine("Authorization confirmed: ${if (s.authorizationConfirmed) "Yes" else "No"}")
            appendLine("Created: ${df.format(Date(s.createdAtEpochMillis))}")
            s.completedAtEpochMillis?.let { appendLine("Completed: ${df.format(Date(it))}") }
            if (s.notes.isNotBlank()) {
                appendLine()
                appendLine("Notes:")
                appendLine(s.notes)
            }
        }
    }

    private fun renderCsv(report: ReportData): String {
        val s = report.session
        fun esc(value: String) = "\"${value.replace("\"", "\"\"")}\""
        val header = listOf(
            "name", "targetSsid", "targetBssid", "wordlist", "mode", "entries", "processed",
            "durationMs", "result", "authorizationConfirmed", "createdAt", "completedAt",
        ).joinToString(",")
        val row = listOf(
            esc(s.name), esc(s.targetSsid), esc(s.targetBssid), esc(s.wordlistName), s.mode.name,
            s.total.toString(), s.processed.toString(), s.durationMillis.toString(),
            esc(outcomeLabel(s.result)), s.authorizationConfirmed.toString(),
            s.createdAtEpochMillis.toString(), (s.completedAtEpochMillis ?: 0).toString(),
        ).joinToString(",")
        return "$header\n$row\n"
    }

    private fun renderJson(report: ReportData): String {
        val s = report.session
        fun esc(value: String) = value.replace("\\", "\\\\").replace("\"", "\\\"")
        return """
            {
              "appVersion": "${esc(report.appVersionName)}",
              "generatedAtEpochMillis": ${report.generatedAtEpochMillis},
              "audit": {
                "name": "${esc(s.name)}",
                "targetSsid": "${esc(s.targetSsid)}",
                "targetBssid": "${esc(s.targetBssid)}",
                "wordlist": "${esc(s.wordlistName)}",
                "mode": "${s.mode.name}",
                "entries": ${s.total},
                "processed": ${s.processed},
                "durationMillis": ${s.durationMillis},
                "result": "${esc(outcomeLabel(s.result))}",
                "authorizationConfirmed": ${s.authorizationConfirmed},
                "createdAtEpochMillis": ${s.createdAtEpochMillis},
                "completedAtEpochMillis": ${s.completedAtEpochMillis ?: "null"}
              }
            }
        """.trimIndent()
    }
}
