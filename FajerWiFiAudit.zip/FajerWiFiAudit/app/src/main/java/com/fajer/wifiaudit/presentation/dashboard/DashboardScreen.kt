package com.fajer.wifiaudit.presentation.dashboard

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import androidx.navigation.NavHostController
import com.fajer.wifiaudit.R
import com.fajer.wifiaudit.core.ui.components.FajerPrimaryButton
import com.fajer.wifiaudit.core.ui.components.FajerSectionCard
import com.fajer.wifiaudit.core.ui.components.StatRow
import com.fajer.wifiaudit.core.ui.components.StatusPill
import com.fajer.wifiaudit.presentation.common.currentAppContainer
import com.fajer.wifiaudit.presentation.navigation.FajerRoute

@Composable
fun DashboardScreen(navController: NavHostController) {
    val container = currentAppContainer()
    val viewModel: DashboardViewModel = viewModel(
        factory = viewModelFactory {
            initializer {
                DashboardViewModel(
                    container.wifiRepository,
                    container.wordlistRepository,
                    container.auditRepository,
                )
            }
        }
    )
    val state by viewModel.uiState.collectAsStateWithLifecycle()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = androidx.compose.ui.Alignment.Top,
        ) {
            Column {
                Text(text = stringResource(R.string.app_name), style = MaterialTheme.typography.displaySmall)
                Text(
                    text = stringResource(R.string.dashboard_header_subtitle),
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            Row {
                androidx.compose.material3.IconButton(onClick = { navController.navigate(FajerRoute.Settings) }) {
                    androidx.compose.material3.Icon(
                        androidx.compose.material.icons.Icons.Default.Settings,
                        contentDescription = stringResource(R.string.nav_settings),
                    )
                }
                androidx.compose.material3.IconButton(onClick = { navController.navigate(FajerRoute.About) }) {
                    androidx.compose.material3.Icon(
                        androidx.compose.material.icons.Icons.Default.Info,
                        contentDescription = stringResource(R.string.nav_about),
                    )
                }
            }
        }

        FajerSectionCard(title = stringResource(R.string.dashboard_card_wifi_status)) {
            StatRow(
                label = stringResource(R.string.dashboard_status_wifi_adapter),
                value = if (state.permissionState.isWifiEnabled) stringResource(R.string.status_connected)
                else stringResource(R.string.status_disconnected),
            )
            StatRow(
                label = stringResource(R.string.dashboard_status_permissions),
                value = if (state.permissionState.hasScanPermission) stringResource(R.string.status_ready)
                else stringResource(R.string.error_permission_denied),
            )
        }

        Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxWidth()) {
            FajerSectionCard(title = stringResource(R.string.dashboard_card_wordlists), modifier = Modifier.weight(1f)) {
                Text(text = state.wordlistCount.toString(), style = MaterialTheme.typography.headlineMedium)
            }
            FajerSectionCard(title = stringResource(R.string.dashboard_card_audit_sessions), modifier = Modifier.weight(1f)) {
                Text(text = state.auditSessionCount.toString(), style = MaterialTheme.typography.headlineMedium)
            }
        }

        FajerSectionCard(title = stringResource(R.string.dashboard_system_status)) {
            StatusPill(stringResource(R.string.dashboard_status_wifi_adapter), state.permissionState.isWifiHardwareSupported)
            StatusPill(stringResource(R.string.dashboard_status_permissions), state.permissionState.hasScanPermission)
            StatusPill(stringResource(R.string.dashboard_status_storage), true)
            StatusPill(stringResource(R.string.dashboard_status_database), true)
            StatusPill(stringResource(R.string.dashboard_status_audit_engine), true)
        }

        FajerSectionCard(title = stringResource(R.string.dashboard_quick_actions)) {
            FajerPrimaryButton(
                text = stringResource(R.string.dashboard_action_scan_networks),
                onClick = { navController.navigate(FajerRoute.Networks) },
                modifier = Modifier.fillMaxWidth(),
            )
            FajerPrimaryButton(
                text = stringResource(R.string.dashboard_action_import_wordlist),
                onClick = { navController.navigate(FajerRoute.Wordlists) },
                modifier = Modifier.fillMaxWidth(),
            )
            FajerPrimaryButton(
                text = stringResource(R.string.dashboard_action_new_audit),
                onClick = { navController.navigate(FajerRoute.NewAudit) },
                modifier = Modifier.fillMaxWidth(),
            )
            FajerPrimaryButton(
                text = stringResource(R.string.dashboard_action_generate_report),
                onClick = { navController.navigate(FajerRoute.Reports) },
                modifier = Modifier.fillMaxWidth(),
            )
        }

        FajerSectionCard(title = stringResource(R.string.dashboard_recent_activity)) {
            if (state.recentSessions.isEmpty()) {
                Text(
                    text = stringResource(R.string.dashboard_no_recent_activity),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            } else {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    state.recentSessions.forEach { session ->
                        StatRow(label = session.name, value = session.status.name)
                    }
                }
            }
        }

        FajerSectionCard {
            Text(
                text = stringResource(R.string.privacy_statement),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}
