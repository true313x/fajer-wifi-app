package com.fajer.wifiaudit.core.common

import android.content.Context
import androidx.datastore.preferences.preferencesDataStore
import com.fajer.wifiaudit.data.local.FajerDatabase
import com.fajer.wifiaudit.data.repository.AuditRepositoryImpl
import com.fajer.wifiaudit.data.repository.LabTargetRepositoryImpl
import com.fajer.wifiaudit.data.repository.SettingsRepositoryImpl
import com.fajer.wifiaudit.data.repository.WifiRepositoryImpl
import com.fajer.wifiaudit.data.repository.WordlistRepositoryImpl
import com.fajer.wifiaudit.data.wifi.AndroidWifiScanner
import com.fajer.wifiaudit.domain.repository.AuditRepository
import com.fajer.wifiaudit.domain.repository.LabTargetRepository
import com.fajer.wifiaudit.domain.repository.SettingsRepository
import com.fajer.wifiaudit.domain.repository.WifiRepository
import com.fajer.wifiaudit.domain.repository.WordlistRepository
import com.fajer.wifiaudit.domain.usecase.AuditEngine

private val Context.settingsDataStore by preferencesDataStore(name = FajerConstants.DATASTORE_NAME)

/**
 * Hand-rolled composition root. The app is small enough that a DI framework (Hilt/Koin) would
 * add annotation-processing overhead without buying much — every dependency below is a plain
 * constructor call, resolved once, in dependency order.
 */
class AppContainer(context: Context) {
    private val appContext = context.applicationContext

    private val database: FajerDatabase = FajerDatabase.getInstance(appContext)
    private val wifiScanner = AndroidWifiScanner(appContext)

    val wifiRepository: WifiRepository = WifiRepositoryImpl(appContext, wifiScanner)
    val wordlistRepository: WordlistRepository = WordlistRepositoryImpl(appContext, database.wordlistDao())
    val auditRepository: AuditRepository = AuditRepositoryImpl(database.auditSessionDao(), database.auditLogDao())
    val labTargetRepository: LabTargetRepository = LabTargetRepositoryImpl(database.labTargetDao())
    val settingsRepository: SettingsRepository = SettingsRepositoryImpl(appContext.settingsDataStore)

    /** A fresh engine per audit run — it holds per-run mutable state (pause flag, progress). */
    fun newAuditEngine(): AuditEngine = AuditEngine()
}
