package com.fajer.wifiaudit.domain.repository

import com.fajer.wifiaudit.core.common.AppResult
import com.fajer.wifiaudit.domain.model.LabTarget
import com.fajer.wifiaudit.domain.model.WifiNetwork
import kotlinx.coroutines.flow.Flow

interface LabTargetRepository {

    fun observeTargets(): Flow<List<LabTarget>>

    /** Adds a scanned network to the lab. Its `syntheticCredential` is always the shared
     *  sample credential unless the user later attaches a known credential via a
     *  Known-Test-Credential audit — the target itself never stores a real password. */
    suspend fun addFromNetwork(network: WifiNetwork): AppResult<LabTarget>

    suspend fun remove(id: Long): AppResult<Unit>

    suspend fun ensureSampleTargetExists(): LabTarget
}
