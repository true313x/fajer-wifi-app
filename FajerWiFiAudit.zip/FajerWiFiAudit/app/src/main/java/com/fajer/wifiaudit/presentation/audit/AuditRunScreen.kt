package com.fajer.wifiaudit.presentation.audit

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import androidx.navigation.NavHostController
import com.fajer.wifiaudit.R
import com.fajer.wifiaudit.core.ui.components.FajerDangerButton
import com.fajer.wifiaudit.core.ui.components.FajerSecondaryButton
import com.fajer.wifiaudit.core.ui.components.FajerSectionCard
import com.fajer.wifiaudit.core.ui.components.StatRow
import com.fajer.wifiaudit.core.utils.TimeUtils
import com.fajer.wifiaudit.domain.model.AuditOutcome
import com.fajer.wifiaudit.domain.model.AuditStatus
import com.fajer.wifiaudit.presentation.common.currentAppContainer

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AuditRunScreen(navController: NavHostController, sessionId: Long) {
    val container = currentAppContainer()
    val viewModel: AuditRunViewModel = viewModel(
        factory = viewModelFactory {
            initializer { AuditRunViewModel(container.auditRepository, container.wordlistRepository, sessionId) }
        }
    )
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    var showStopConfirm by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(stringResource(R.string.audit_run_title)) },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(Icons.Default.ArrowBack, contentDescription = null)
                    }
                },
            )
        },
    ) { innerPadding ->
        val session = state.session ?: return@Scaffold
        val progress = state.progress

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            FajerSectionCard {
                StatRow(stringResource(R.string.label_target), session.targetSsid.ifBlank { "—" })
                StatRow(stringResource(R.string.label_wordlist_name), session.wordlistName)
                StatRow(stringResource(R.string.label_status), session.status.displayLabel())
            }

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp),
                contentAlignment = Alignment.Center,
            ) {
                CircularProgressIndicator(
                    progress = { progress.percentage },
                    modifier = Modifier.size(180.dp),
                    strokeWidth = 10.dp,
                    trackColor = MaterialTheme.colorScheme.surfaceVariant,
                )
                Text(
                    text = "${(progress.percentage * 100).toInt()}%",
                    style = MaterialTheme.typography.displaySmall,
                )
            }

            FajerSectionCard {
                StatRow(stringResource(R.string.label_processed), "${progress.processed}")
                StatRow(stringResource(R.string.label_total), "${progress.total}")
                StatRow(stringResource(R.string.label_rate), "${TimeUtils.formatRate(progress.ratePerSecond)}/sec")
                StatRow(stringResource(R.string.label_elapsed), TimeUtils.formatDuration(progress.elapsedMillis))
                StatRow(stringResource(R.string.label_eta), TimeUtils.formatEta(progress.etaMillis))
                StatRow(stringResource(R.string.label_current_candidate), progress.currentCandidate.ifBlank { "—" })
            }

            ResultCard(session.result)

            if (session.isRunning) {
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxWidth()) {
                    FajerSecondaryButton(
                        text = if (state.isPaused) stringResource(R.string.action_resume) else stringResource(R.string.action_pause),
                        onClick = { viewModel.togglePause() },
                        modifier = Modifier.weight(1f),
                    )
                    FajerDangerButton(
                        text = stringResource(R.string.action_stop),
                        onClick = { showStopConfirm = true },
                        modifier = Modifier.weight(1f),
                    )
                }
            }
        }

        if (showStopConfirm) {
            AlertDialog(
                onDismissRequest = { showStopConfirm = false },
                title = { Text(stringResource(R.string.audit_confirm_stop_title)) },
                text = { Text(stringResource(R.string.audit_confirm_stop_body)) },
                confirmButton = {
                    TextButton(onClick = {
                        showStopConfirm = false
                        viewModel.stop()
                    }) { Text(stringResource(R.string.action_stop)) }
                },
                dismissButton = {
                    TextButton(onClick = { showStopConfirm = false }) { Text(stringResource(R.string.action_cancel)) }
                },
            )
        }
    }
}

@Composable
private fun ResultCard(result: AuditOutcome) {
    FajerSectionCard {
        when (result) {
            is AuditOutcome.Matched -> Text(
                stringResource(R.string.audit_result_matched),
                color = MaterialTheme.colorScheme.primary,
            )
            is AuditOutcome.NoMatch -> Text(stringResource(R.string.audit_result_no_match))
            is AuditOutcome.Stopped -> Text(stringResource(R.string.audit_result_stopped))
            is AuditOutcome.Failed -> Text(result.reason, color = MaterialTheme.colorScheme.error)
            is AuditOutcome.StrengthSummary -> Column {
                result.distribution.entries.sortedBy { it.key.ordinal }.forEach { (strength, count) ->
                    StatRow(strength.name, count.toString())
                }
            }
            is AuditOutcome.Pending -> Unit
        }
    }
}

private fun AuditStatus.displayLabel(): String = when (this) {
    AuditStatus.IDLE -> "Idle"
    AuditStatus.PREPARING -> "Preparing"
    AuditStatus.RUNNING -> "Running"
    AuditStatus.PAUSED -> "Paused"
    AuditStatus.COMPLETED -> "Completed"
    AuditStatus.STOPPED -> "Stopped"
    AuditStatus.FAILED -> "Failed"
}
