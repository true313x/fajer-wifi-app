package com.fajer.wifiaudit.presentation.wordlist

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import androidx.navigation.NavHostController
import com.fajer.wifiaudit.R
import com.fajer.wifiaudit.domain.model.Wordlist
import com.fajer.wifiaudit.presentation.common.currentAppContainer
import com.fajer.wifiaudit.presentation.navigation.FajerRoute

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun WordlistsScreen(navController: NavHostController) {
    val container = currentAppContainer()
    val viewModel: WordlistListViewModel = viewModel(
        factory = viewModelFactory {
            initializer { WordlistListViewModel(container.wordlistRepository, container.settingsRepository) }
        }
    )
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    val context = LocalContext.current

    val openDocumentLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument(),
    ) { uri ->
        if (uri != null) viewModel.importFrom(context, uri)
    }

    Scaffold(
        topBar = { TopAppBar(title = { Text(stringResource(R.string.wordlists_title)) }) },
        floatingActionButton = {
            FloatingActionButton(
                onClick = { openDocumentLauncher.launch(arrayOf("text/plain", "text/*", "application/octet-stream")) }
            ) {
                Icon(Icons.Default.Add, contentDescription = stringResource(R.string.action_import))
            }
        },
    ) { innerPadding ->
        Column(modifier = Modifier.fillMaxSize().padding(innerPadding)) {
            if (state.isImporting) {
                LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
                Text(
                    text = stringResource(R.string.wordlist_importing),
                    style = MaterialTheme.typography.bodySmall,
                    modifier = Modifier.padding(16.dp),
                )
            }

            if (state.wordlists.isEmpty() && !state.isImporting) {
                Column(
                    modifier = Modifier.fillMaxSize().padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center,
                ) {
                    Text(stringResource(R.string.wordlists_empty_title), style = MaterialTheme.typography.titleLarge)
                    Text(
                        text = state.errorMessage ?: stringResource(R.string.wordlists_empty_body),
                        style = MaterialTheme.typography.bodySmall,
                        modifier = Modifier.padding(vertical = 8.dp),
                    )
                    TextButton(onClick = { viewModel.installSample() }) {
                        Text("Use the built-in sample wordlist instead")
                    }
                }
            } else {
                LazyColumn(
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                    items(state.wordlists, key = { it.id }) { wordlist ->
                        WordlistRow(wordlist) {
                            navController.navigate(
                                FajerRoute.wordlistDetails(wordlist.id)
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun WordlistRow(wordlist: Wordlist, onClick: () -> Unit) {
    Card(
        onClick = onClick,
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
    ) {
        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(wordlist.displayName, style = MaterialTheme.typography.titleSmall)
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(
                    "${wordlist.stats.totalLines} entries · ${wordlist.stats.uniqueLines} unique",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                Text(
                    wordlist.encoding,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
    }
}
