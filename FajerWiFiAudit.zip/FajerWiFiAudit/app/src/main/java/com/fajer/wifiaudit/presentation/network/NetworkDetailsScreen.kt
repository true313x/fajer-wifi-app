package com.fajer.wifiaudit.presentation.network

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Snackbar
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.AnnotatedString
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import androidx.navigation.NavHostController
import com.fajer.wifiaudit.R
import com.fajer.wifiaudit.core.ui.components.FajerPrimaryButton
import com.fajer.wifiaudit.core.ui.components.FajerSecondaryButton
import com.fajer.wifiaudit.core.ui.components.FajerSectionCard
import com.fajer.wifiaudit.core.ui.components.SecurityBadge
import com.fajer.wifiaudit.core.ui.components.StatRow
import com.fajer.wifiaudit.presentation.common.currentAppContainer
import com.fajer.wifiaudit.presentation.navigation.FajerRoute
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NetworkDetailsScreen(navController: NavHostController, bssid: String) {
    val container = currentAppContainer()
    val viewModel: NetworkDetailsViewModel = viewModel(
        factory = viewModelFactory {
            initializer { NetworkDetailsViewModel(container.wifiRepository, container.labTargetRepository, bssid) }
        }
    )
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    val clipboard = LocalClipboardManager.current
    val snackbarHostState = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(stringResource(R.string.network_details_title)) },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(Icons.Default.ArrowBack, contentDescription = null)
                    }
                },
            )
        },
        snackbarHost = { SnackbarHost(snackbarHostState) { Snackbar(it) } },
    ) { innerPadding ->
        val network = state.network
        if (network == null) {
            Column(modifier = Modifier.fillMaxSize().padding(innerPadding).padding(24.dp)) {
                Text(stringResource(R.string.error_generic_retry))
            }
            return@Scaffold
        }

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            FajerSectionCard(title = stringResource(R.string.section_overview)) {
                StatRow(stringResource(R.string.label_ssid), network.ssid.ifBlank { "(hidden)" })
                StatRow(stringResource(R.string.label_bssid), network.bssid)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text(stringResource(R.string.label_security), style = MaterialTheme.typography.bodyMedium)
                    SecurityBadge(network.securityType)
                }
            }

            FajerSectionCard(title = stringResource(R.string.section_radio_information)) {
                StatRow(stringResource(R.string.label_rssi), "${network.rssiDbm} dBm")
                StatRow(stringResource(R.string.label_signal_percent), "${network.signalPercent}%")
                StatRow(stringResource(R.string.label_frequency), "${network.frequencyMhz} MHz")
                StatRow(stringResource(R.string.label_channel), network.channel.toString())
                StatRow(
                    stringResource(R.string.label_wifi_standard),
                    network.wifiStandard ?: stringResource(R.string.vendor_unknown),
                )
                StatRow(stringResource(R.string.label_last_scanned), viewModel.formatLastSeen(network.lastSeenEpochMillis))
            }

            FajerSectionCard(title = stringResource(R.string.section_security)) {
                StatRow(stringResource(R.string.label_capabilities), network.capabilities)
            }

            FajerSectionCard(title = stringResource(R.string.section_audit_preparation)) {
                FajerPrimaryButton(
                    text = stringResource(R.string.action_add_to_lab),
                    onClick = {
                        scope.launch {
                            val added = viewModel.addToLab()
                            snackbarHostState.showSnackbar(
                                if (added) "Added to your local lab" else "Could not add — it may already be in your lab"
                            )
                        }
                    },
                    modifier = Modifier.fillMaxWidth(),
                )
                FajerPrimaryButton(
                    text = stringResource(R.string.action_create_audit_session),
                    onClick = { navController.navigate(FajerRoute.NewAudit) },
                    modifier = Modifier.fillMaxWidth(),
                )
                FajerSecondaryButton(
                    text = stringResource(R.string.action_copy_ssid),
                    onClick = { clipboard.setText(AnnotatedString(network.ssid)) },
                    modifier = Modifier.fillMaxWidth(),
                )
                FajerSecondaryButton(
                    text = stringResource(R.string.action_copy_bssid),
                    onClick = { clipboard.setText(AnnotatedString(network.bssid)) },
                    modifier = Modifier.fillMaxWidth(),
                )
            }
        }
    }
}
