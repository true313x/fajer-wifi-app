package com.fajer.wifiaudit.core.permissions

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.location.LocationManager
import android.net.wifi.WifiManager
import android.os.Build
import androidx.core.content.ContextCompat
import androidx.core.location.LocationManagerCompat

/**
 * Wraps the permission story that changed shape across Android releases:
 *
 * - Android 12 and below: [Manifest.permission.ACCESS_FINE_LOCATION] plus device location
 *   services switched on.
 * - Android 13+ (API 33): apps can instead request
 *   [Manifest.permission.NEARBY_WIFI_DEVICES] with `neverForLocation`, which does not require
 *   location services to be on at all.
 *
 * We request both permissions in the manifest and let this class decide, at runtime, which
 * one actually satisfies the current OS version — so the rest of the app never has to think
 * about API levels.
 */
object PermissionManager {

    fun requiredScanPermissions(): Array<String> =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            arrayOf(Manifest.permission.NEARBY_WIFI_DEVICES)
        } else {
            arrayOf(Manifest.permission.ACCESS_FINE_LOCATION)
        }

    fun hasScanPermission(context: Context): Boolean =
        requiredScanPermissions().all {
            ContextCompat.checkSelfPermission(context, it) == PackageManager.PERMISSION_GRANTED
        }

    /** Location services must be ON in addition to the permission below API 33. */
    fun isLocationServicesRequired(): Boolean = Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU

    fun isLocationServicesEnabled(context: Context): Boolean = try {
        val locationManager = context.getSystemService(Context.LOCATION_SERVICE) as? LocationManager
        locationManager != null && LocationManagerCompat.isLocationEnabled(locationManager)
    } catch (_: Exception) {
        false
    }

    fun isWifiHardwareSupported(context: Context): Boolean =
        context.packageManager.hasSystemFeature(android.content.pm.PackageManager.FEATURE_WIFI)

    fun isWifiEnabled(context: Context): Boolean = try {
        val wifiManager = context.applicationContext
            .getSystemService(Context.WIFI_SERVICE) as? WifiManager
        wifiManager?.isWifiEnabled == true
    } catch (_: Exception) {
        false
    }

    fun currentState(context: Context): PermissionState = PermissionState(
        hasScanPermission = hasScanPermission(context),
        locationServicesRequired = isLocationServicesRequired(),
        isLocationServicesEnabled = isLocationServicesEnabled(context),
        isWifiEnabled = isWifiEnabled(context),
        isWifiHardwareSupported = isWifiHardwareSupported(context)
    )
}
