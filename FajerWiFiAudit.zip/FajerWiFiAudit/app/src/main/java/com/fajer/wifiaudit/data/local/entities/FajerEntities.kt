package com.fajer.wifiaudit.data.local.entities

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.fajer.wifiaudit.domain.model.AuditLogEntry
import com.fajer.wifiaudit.domain.model.AuditLogEvent
import com.fajer.wifiaudit.domain.model.LabTarget
import com.fajer.wifiaudit.domain.model.LengthBucket
import com.fajer.wifiaudit.domain.model.SecurityType
import com.fajer.wifiaudit.domain.model.Wordlist
import com.fajer.wifiaudit.domain.model.WordlistStats

@Entity(tableName = "wordlists")
data class WordlistEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val displayName: String,
    val uri: String,
    val sizeBytes: Long,
    val encoding: String,
    val totalLines: Int,
    val uniqueLines: Int,
    val duplicateCount: Int,
    val emptyLinesRemoved: Int,
    val averageLength: Double,
    val minimumLength: Int,
    val maximumLength: Int,
    val numericOnlyCount: Int,
    val alphabeticOnlyCount: Int,
    val mixedCount: Int,
    val specialCharacterCount: Int,
    val unicodeCount: Int,
    // Encoded "LEN_1_5:12;LEN_6_7:340;..." — five buckets, not worth a child table.
    val lengthDistributionCsv: String,
    val importedAtEpochMillis: Long,
) {
    fun toDomain(): Wordlist = Wordlist(
        id = id,
        displayName = displayName,
        uri = uri,
        sizeBytes = sizeBytes,
        encoding = encoding,
        stats = WordlistStats(
            totalLines = totalLines,
            uniqueLines = uniqueLines,
            duplicateCount = duplicateCount,
            emptyLinesRemoved = emptyLinesRemoved,
            averageLength = averageLength,
            minimumLength = minimumLength,
            maximumLength = maximumLength,
            numericOnlyCount = numericOnlyCount,
            alphabeticOnlyCount = alphabeticOnlyCount,
            mixedCount = mixedCount,
            specialCharacterCount = specialCharacterCount,
            unicodeCount = unicodeCount,
            lengthDistribution = decodeLengthDistribution(lengthDistributionCsv),
        ),
        importedAtEpochMillis = importedAtEpochMillis,
    )

    companion object {
        fun fromDomain(wordlist: Wordlist): WordlistEntity = WordlistEntity(
            id = wordlist.id,
            displayName = wordlist.displayName,
            uri = wordlist.uri,
            sizeBytes = wordlist.sizeBytes,
            encoding = wordlist.encoding,
            totalLines = wordlist.stats.totalLines,
            uniqueLines = wordlist.stats.uniqueLines,
            duplicateCount = wordlist.stats.duplicateCount,
            emptyLinesRemoved = wordlist.stats.emptyLinesRemoved,
            averageLength = wordlist.stats.averageLength,
            minimumLength = wordlist.stats.minimumLength,
            maximumLength = wordlist.stats.maximumLength,
            numericOnlyCount = wordlist.stats.numericOnlyCount,
            alphabeticOnlyCount = wordlist.stats.alphabeticOnlyCount,
            mixedCount = wordlist.stats.mixedCount,
            specialCharacterCount = wordlist.stats.specialCharacterCount,
            unicodeCount = wordlist.stats.unicodeCount,
            lengthDistributionCsv = wordlist.stats.lengthDistribution.entries
                .joinToString(";") { "${it.key.name}:${it.value}" },
            importedAtEpochMillis = wordlist.importedAtEpochMillis,
        )

        private fun decodeLengthDistribution(csv: String): Map<LengthBucket, Int> {
            val decoded = csv.split(";").mapNotNull { entry ->
                val parts = entry.split(":")
                if (parts.size != 2) return@mapNotNull null
                runCatching { LengthBucket.valueOf(parts[0]) to parts[1].toInt() }.getOrNull()
            }.toMap()
            // Ensure every bucket is present even if the stored CSV predates a bucket change.
            return LengthBucket.entries.associateWith { decoded[it] ?: 0 }
        }
    }
}

@Entity(tableName = "audit_logs")
data class AuditLogEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val auditSessionId: Long?,
    val event: String, // AuditLogEvent.name
    val detail: String,
    val timestampEpochMillis: Long,
) {
    fun toDomain(): AuditLogEntry = AuditLogEntry(
        id = id,
        auditSessionId = auditSessionId,
        event = AuditLogEvent.valueOf(event),
        detail = detail,
        timestampEpochMillis = timestampEpochMillis,
    )

    companion object {
        fun fromDomain(entry: AuditLogEntry): AuditLogEntity = AuditLogEntity(
            id = entry.id,
            auditSessionId = entry.auditSessionId,
            event = entry.event.name,
            detail = entry.detail,
            timestampEpochMillis = entry.timestampEpochMillis,
        )
    }
}

@Entity(tableName = "lab_targets")
data class LabTargetEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val ssid: String,
    val bssid: String,
    val securityType: String, // SecurityType.name
    val syntheticCredential: String,
    val isBuiltInSample: Boolean,
    val addedAtEpochMillis: Long,
) {
    fun toDomain(): LabTarget = LabTarget(
        id = id,
        ssid = ssid,
        bssid = bssid,
        securityType = SecurityType.valueOf(securityType),
        syntheticCredential = syntheticCredential,
        isBuiltInSample = isBuiltInSample,
        addedAtEpochMillis = addedAtEpochMillis,
    )

    companion object {
        fun fromDomain(target: LabTarget): LabTargetEntity = LabTargetEntity(
            id = target.id,
            ssid = target.ssid,
            bssid = target.bssid,
            securityType = target.securityType.name,
            syntheticCredential = target.syntheticCredential,
            isBuiltInSample = target.isBuiltInSample,
            addedAtEpochMillis = target.addedAtEpochMillis,
        )
    }
}
