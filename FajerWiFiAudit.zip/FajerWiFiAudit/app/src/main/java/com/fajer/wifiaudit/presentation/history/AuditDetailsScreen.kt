package com.fajer.wifiaudit.presentation.history

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import androidx.navigation.NavHostController
import com.fajer.wifiaudit.R
import com.fajer.wifiaudit.core.ui.components.FajerSectionCard
import com.fajer.wifiaudit.core.ui.components.StatRow
import com.fajer.wifiaudit.core.utils.TimeUtils
import com.fajer.wifiaudit.presentation.common.currentAppContainer
import java.text.DateFormat
import java.util.Date

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AuditDetailsScreen(navController: NavHostController, sessionId: Long) {
    val container = currentAppContainer()
    val viewModel: AuditDetailsViewModel = viewModel(
        factory = viewModelFactory { initializer { AuditDetailsViewModel(container.auditRepository, sessionId) } }
    )
    val state by viewModel.uiState.collectAsStateWithLifecycle()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(stringResource(R.string.history_details_title)) },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(Icons.Default.ArrowBack, contentDescription = null)
                    }
                },
            )
        },
    ) { innerPadding ->
        val session = state.session ?: return@Scaffold

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            Text(session.name, style = MaterialTheme.typography.headlineSmall)

            FajerSectionCard {
                StatRow(stringResource(R.string.label_target), session.targetSsid.ifBlank { "—" })
                StatRow(stringResource(R.string.label_wordlist_name), session.wordlistName)
                StatRow(stringResource(R.string.field_mode), session.mode.name)
                StatRow(stringResource(R.string.label_status), session.status.name)
                StatRow(stringResource(R.string.label_processed), "${session.processed} / ${session.total}")
                StatRow("Duration", TimeUtils.formatDuration(session.durationMillis))
                StatRow(
                    "Created",
                    DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.SHORT)
                        .format(Date(session.createdAtEpochMillis)),
                )
                StatRow(
                    "Authorization",
                    if (session.authorizationConfirmed) "Confirmed" else "Not confirmed",
                )
            }

            if (session.notes.isNotBlank()) {
                FajerSectionCard(title = stringResource(R.string.field_notes)) {
                    Text(session.notes, style = MaterialTheme.typography.bodyMedium)
                }
            }

            FajerSectionCard(title = stringResource(R.string.section_logs)) {
                if (state.logs.isEmpty()) {
                    Text(
                        "No logged events for this session.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                } else {
                    state.logs.forEach { entry ->
                        StatRow(
                            entry.event.name,
                            DateFormat.getTimeInstance(DateFormat.SHORT).format(Date(entry.timestampEpochMillis)),
                        )
                    }
                }
            }
        }
    }
}
