package com.fajer.wifiaudit.presentation.network

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.fajer.wifiaudit.core.common.AppResult
import com.fajer.wifiaudit.domain.model.WifiNetwork
import com.fajer.wifiaudit.domain.repository.LabTargetRepository
import com.fajer.wifiaudit.domain.repository.WifiRepository
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import java.text.DateFormat
import java.util.Date

data class NetworkDetailsUiState(val network: WifiNetwork? = null)

class NetworkDetailsViewModel(
    wifiRepository: WifiRepository,
    private val labTargetRepository: LabTargetRepository,
    private val bssid: String,
) : ViewModel() {

    val uiState: StateFlow<NetworkDetailsUiState> = wifiRepository.observeNetworks()
        .map { networks -> NetworkDetailsUiState(networks.firstOrNull { it.bssid == bssid }) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), NetworkDetailsUiState())

    fun formatLastSeen(epochMillis: Long): String =
        DateFormat.getTimeInstance(DateFormat.SHORT).format(Date(epochMillis))

    /** Returns true if the network was newly added; false if it was already in the lab or the
     *  add failed for another reason. */
    suspend fun addToLab(): Boolean {
        val network = uiState.value.network ?: return false
        return when (labTargetRepository.addFromNetwork(network)) {
            is AppResult.Success -> true
            is AppResult.Error -> false
        }
    }
}
