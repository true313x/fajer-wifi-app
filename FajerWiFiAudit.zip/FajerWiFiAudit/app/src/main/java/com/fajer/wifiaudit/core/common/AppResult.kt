package com.fajer.wifiaudit.core.common

/**
 * A minimal success/failure wrapper used at repository and use-case boundaries.
 *
 * We deliberately avoid `kotlin.Result` here: it boxes exceptions in a way that is easy to
 * accidentally swallow, and its API surface encourages catching `Throwable` broadly. This
 * sealed type forces every call site to explicitly acknowledge failure.
 */
sealed interface AppResult<out T> {
    data class Success<out T>(val data: T) : AppResult<T>
    data class Error(val message: String, val cause: Throwable? = null) : AppResult<Nothing>
}

inline fun <T, R> AppResult<T>.map(transform: (T) -> R): AppResult<R> = when (this) {
    is AppResult.Success -> AppResult.Success(transform(data))
    is AppResult.Error -> this
}

inline fun <T> AppResult<T>.onSuccess(action: (T) -> Unit): AppResult<T> {
    if (this is AppResult.Success) action(data)
    return this
}

inline fun <T> AppResult<T>.onError(action: (AppResult.Error) -> Unit): AppResult<T> {
    if (this is AppResult.Error) action(this)
    return this
}

fun <T> T.asSuccess(): AppResult<T> = AppResult.Success(this)

fun runCatchingApp(message: String, block: () -> Unit): AppResult<Unit> = try {
    block()
    AppResult.Success(Unit)
} catch (t: Throwable) {
    AppResult.Error(message, t)
}
