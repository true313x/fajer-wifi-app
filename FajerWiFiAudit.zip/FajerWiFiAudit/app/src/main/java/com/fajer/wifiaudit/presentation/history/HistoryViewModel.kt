package com.fajer.wifiaudit.presentation.history

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.fajer.wifiaudit.domain.model.AuditSession
import com.fajer.wifiaudit.domain.repository.AuditRepository
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn

class HistoryViewModel(auditRepository: AuditRepository) : ViewModel() {
    val sessions: StateFlow<List<AuditSession>> = auditRepository.observeSessions()
        .map { list -> list.sortedByDescending { it.createdAtEpochMillis } }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())
}
