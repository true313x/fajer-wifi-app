package com.fajer.wifiaudit

import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performClick
import androidx.test.ext.junit.runners.AndroidJUnit4
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class NavigationTest {

    @get:Rule
    val composeRule = createAndroidComposeRule<MainActivity>()

    @Test
    fun tappingWordlistsTabShowsWordlistsScreen() {
        composeRule.onNodeWithText("Wordlists").performClick()
        composeRule.onNodeWithText("Import your first wordlist").assertExists()
    }
}
