package com.fajer.wifiaudit

import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.compose.ui.test.onNodeWithText
import androidx.test.ext.junit.runners.AndroidJUnit4
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith

/**
 * A deliberately small smoke test: it confirms the app launches, Compose renders without
 * throwing, and the Dashboard's header text is on screen. It is not a substitute for a full
 * Compose UI test suite per screen — see README "Known limitations" for what is not yet
 * covered here (this project could not run instrumentation tests in the environment it was
 * generated in, so this file is unverified beyond manual review).
 */
@RunWith(AndroidJUnit4::class)
class DashboardScreenTest {

    @get:Rule
    val composeRule = createAndroidComposeRule<MainActivity>()

    @Test
    fun dashboardShowsAppNameOnLaunch() {
        composeRule.onNodeWithText("FAJER").assertExists()
    }
}
