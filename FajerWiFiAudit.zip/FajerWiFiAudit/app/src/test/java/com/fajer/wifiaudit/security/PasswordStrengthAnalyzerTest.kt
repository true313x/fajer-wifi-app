package com.fajer.wifiaudit.security

import com.fajer.wifiaudit.core.security.PasswordStrengthAnalyzer
import com.fajer.wifiaudit.domain.model.PasswordStrength
import com.google.common.truth.Truth.assertThat
import org.junit.Test

class PasswordStrengthAnalyzerTest {

    @Test
    fun `common password is always very weak regardless of length`() {
        val result = PasswordStrengthAnalyzer.analyze("password")
        assertThat(result.strength).isEqualTo(PasswordStrength.VERY_WEAK)
        assertThat(result.isCommonPassword).isTrue()
    }

    @Test
    fun `empty string is very weak`() {
        val result = PasswordStrengthAnalyzer.analyze("")
        assertThat(result.strength).isEqualTo(PasswordStrength.VERY_WEAK)
        assertThat(result.entropyBits).isEqualTo(0.0)
    }

    @Test
    fun `long random mixed-case alphanumeric with symbols is very strong`() {
        val result = PasswordStrengthAnalyzer.analyze("qX7!mK9#vR2\$pL4&wZ8")
        assertThat(result.strength).isEqualTo(PasswordStrength.VERY_STRONG)
    }

    @Test
    fun `repeated character run is detected and penalized`() {
        val result = PasswordStrengthAnalyzer.analyze("aaa11111bbb")
        assertThat(result.hasRepeatedRun).isTrue()
    }

    @Test
    fun `sequential ascending run is detected`() {
        val result = PasswordStrengthAnalyzer.analyze("xyzabcd123")
        assertThat(result.hasSequentialRun).isTrue()
    }

    @Test
    fun `no false positive sequential run on non-sequential input`() {
        val result = PasswordStrengthAnalyzer.analyze("kR9mZ2vB")
        assertThat(result.hasSequentialRun).isFalse()
    }

    @Test
    fun `character class flags reflect actual composition`() {
        val result = PasswordStrengthAnalyzer.analyze("Ab1!")
        assertThat(result.hasLowercase).isTrue()
        assertThat(result.hasUppercase).isTrue()
        assertThat(result.hasDigit).isTrue()
        assertThat(result.hasSymbol).isTrue()
    }

    @Test
    fun `known sample lab credential scores above weak`() {
        // Sanity check on the sample data shipped in FajerConstants — if this ever regresses
        // to Very Weak or Weak, the "Offline Wordlist Simulation" demo would look broken by
        // default.
        val result = PasswordStrengthAnalyzer.analyze("LabPassword123!")
        assertThat(result.strength).isNotEqualTo(PasswordStrength.VERY_WEAK)
        assertThat(result.strength).isNotEqualTo(PasswordStrength.WEAK)
    }
}
