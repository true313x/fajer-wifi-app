package com.fajer.wifiaudit.utils

import com.fajer.wifiaudit.core.utils.SecurityClassifier
import com.fajer.wifiaudit.domain.model.SecurityType
import com.google.common.truth.Truth.assertThat
import org.junit.Test

class SecurityClassifierTest {

    @Test
    fun `WPA2 PSK capability string classifies as WPA2`() {
        assertThat(SecurityClassifier.classify("[WPA2-PSK-CCMP][ESS]")).isEqualTo(SecurityType.WPA2)
    }

    @Test
    fun `WPA3 SAE capability string classifies as WPA3`() {
        assertThat(SecurityClassifier.classify("[RSN-SAE-CCMP][ESS]")).isEqualTo(SecurityType.WPA3)
    }

    @Test
    fun `mixed WPA2-WPA3 transition network prefers the stronger WPA3`() {
        assertThat(SecurityClassifier.classify("[WPA2-PSK-CCMP][RSN-SAE-CCMP][ESS]")).isEqualTo(SecurityType.WPA3)
    }

    @Test
    fun `plain ESS with no security token classifies as OPEN`() {
        assertThat(SecurityClassifier.classify("[ESS]")).isEqualTo(SecurityType.OPEN)
    }

    @Test
    fun `WEP capability string classifies as WEP`() {
        assertThat(SecurityClassifier.classify("[WEP][ESS]")).isEqualTo(SecurityType.WEP)
    }

    @Test
    fun `blank capabilities is UNKNOWN, never guessed`() {
        assertThat(SecurityClassifier.classify("")).isEqualTo(SecurityType.UNKNOWN)
    }

    @Test
    fun `unrecognized token with no ESS is UNKNOWN rather than defaulting to OPEN`() {
        assertThat(SecurityClassifier.classify("[SOMETHING-WEIRD]")).isEqualTo(SecurityType.UNKNOWN)
    }

    @Test
    fun `RSN alone without the literal WPA2 string still classifies as WPA2`() {
        assertThat(SecurityClassifier.classify("[RSN-PSK-CCMP][ESS]")).isEqualTo(SecurityType.WPA2)
    }
}
