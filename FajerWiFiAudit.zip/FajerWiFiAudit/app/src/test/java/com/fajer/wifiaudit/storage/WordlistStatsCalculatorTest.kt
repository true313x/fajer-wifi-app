package com.fajer.wifiaudit.storage

import com.fajer.wifiaudit.core.storage.WordlistStatsCalculator
import com.fajer.wifiaudit.domain.model.LengthBucket
import com.fajer.wifiaudit.domain.model.WordlistPreferences
import com.google.common.truth.Truth.assertThat
import org.junit.Test

class WordlistStatsCalculatorTest {

    @Test
    fun `empty sequence produces zeroed stats without crashing`() {
        val stats = WordlistStatsCalculator.compute(emptySequence(), WordlistPreferences())
        assertThat(stats.totalLines).isEqualTo(0)
        assertThat(stats.uniqueLines).isEqualTo(0)
        assertThat(stats.duplicateCount).isEqualTo(0)
    }

    @Test
    fun `duplicate lines are counted correctly`() {
        val lines = sequenceOf("password", "password", "admin123", "password")
        val stats = WordlistStatsCalculator.compute(lines, WordlistPreferences())
        assertThat(stats.totalLines).isEqualTo(4)
        assertThat(stats.uniqueLines).isEqualTo(2)
        assertThat(stats.duplicateCount).isEqualTo(2)
    }

    @Test
    fun `blank lines are removed and counted when ignoreEmptyLines is enabled`() {
        val lines = sequenceOf("password", "", "admin123", "   ")
        val stats = WordlistStatsCalculator.compute(
            lines,
            WordlistPreferences(trimWhitespace = true, ignoreEmptyLines = true),
        )
        assertThat(stats.totalLines).isEqualTo(4)
        assertThat(stats.emptyLinesRemoved).isEqualTo(2)
        assertThat(stats.uniqueLines).isEqualTo(2)
    }

    @Test
    fun `trimWhitespace normalizes lines before dedup so they collapse together`() {
        val lines = sequenceOf("password", "password ", " password")
        val stats = WordlistStatsCalculator.compute(lines, WordlistPreferences(trimWhitespace = true))
        assertThat(stats.uniqueLines).isEqualTo(1)
        assertThat(stats.duplicateCount).isEqualTo(2)
    }

    @Test
    fun `length distribution buckets entries correctly`() {
        val lines = sequenceOf("abc", "abcdefgh", "abcdefghijklmnop")
        val stats = WordlistStatsCalculator.compute(lines, WordlistPreferences())
        assertThat(stats.lengthDistribution[LengthBucket.LEN_1_5]).isEqualTo(1)
        assertThat(stats.lengthDistribution[LengthBucket.LEN_8_10]).isEqualTo(1)
        assertThat(stats.lengthDistribution[LengthBucket.LEN_16_PLUS]).isEqualTo(1)
    }

    @Test
    fun `character composition classifies numeric, alphabetic, mixed and special correctly`() {
        val lines = sequenceOf("12345", "abcde", "abc123", "abc!23")
        val stats = WordlistStatsCalculator.compute(lines, WordlistPreferences())
        assertThat(stats.numericOnlyCount).isEqualTo(1)
        assertThat(stats.alphabeticOnlyCount).isEqualTo(1)
        assertThat(stats.mixedCount).isEqualTo(1)
        assertThat(stats.specialCharacterCount).isEqualTo(1)
    }

    @Test
    fun `unicode line is classified as unicode even when it also contains digits`() {
        val stats = WordlistStatsCalculator.compute(sequenceOf("مرحبا123"), WordlistPreferences())
        assertThat(stats.unicodeCount).isEqualTo(1)
        assertThat(stats.mixedCount).isEqualTo(0)
    }

    @Test
    fun `average length is computed over considered lines only, excluding removed empties`() {
        val lines = sequenceOf("ab", "abcd", "")
        val stats = WordlistStatsCalculator.compute(
            lines,
            WordlistPreferences(ignoreEmptyLines = true),
        )
        assertThat(stats.averageLength).isEqualTo(3.0) // (2 + 4) / 2
    }

    @Test
    fun `large synthetic wordlist of 10000 unique entries reports correct counts`() {
        val lines = (1..10_000).asSequence().map { "candidate$it" }
        val stats = WordlistStatsCalculator.compute(lines, WordlistPreferences())
        assertThat(stats.totalLines).isEqualTo(10_000)
        assertThat(stats.uniqueLines).isEqualTo(10_000)
        assertThat(stats.duplicateCount).isEqualTo(0)
    }
}
