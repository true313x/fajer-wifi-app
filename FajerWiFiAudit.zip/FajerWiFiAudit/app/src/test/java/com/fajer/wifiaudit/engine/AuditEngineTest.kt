package com.fajer.wifiaudit.engine

import com.fajer.wifiaudit.core.common.FajerConstants
import com.fajer.wifiaudit.domain.model.AuditMode
import com.fajer.wifiaudit.domain.model.AuditOutcome
import com.fajer.wifiaudit.domain.usecase.AuditEngine
import com.google.common.truth.Truth.assertThat
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.async
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.test.runTest
import kotlinx.coroutines.yield
import org.junit.Test

@OptIn(ExperimentalCoroutinesApi::class)
class AuditEngineTest {

    @Test
    fun `offline simulation matches the sample synthetic credential`() = runTest {
        val engine = AuditEngine()
        val candidates = flowOf("wrong1", "wrong2", FajerConstants.SAMPLE_LAB_SYNTHETIC_CREDENTIAL, "wrong3")

        val outcome = engine.run(AuditMode.OFFLINE_WORDLIST_SIMULATION, candidates, totalHint = 4)

        assertThat(outcome).isInstanceOf(AuditOutcome.Matched::class.java)
        assertThat((outcome as AuditOutcome.Matched).matchedAtIndex).isEqualTo(3)
        assertThat(outcome.candidate).isEqualTo(FajerConstants.SAMPLE_LAB_SYNTHETIC_CREDENTIAL)
    }

    @Test
    fun `offline simulation reports no match when the credential never appears`() = runTest {
        val engine = AuditEngine()
        val candidates = flowOf("wrong1", "wrong2", "wrong3")

        val outcome = engine.run(AuditMode.OFFLINE_WORDLIST_SIMULATION, candidates, totalHint = 3)

        assertThat(outcome).isEqualTo(AuditOutcome.NoMatch)
    }

    @Test
    fun `known-test-credential mode matches only the exact user-supplied credential`() = runTest {
        val engine = AuditEngine()
        val candidates = flowOf("guess1", "MySecretLabPass1", "guess2")

        val outcome = engine.run(
            AuditMode.KNOWN_TEST_CREDENTIAL_SIMULATION,
            candidates,
            totalHint = 3,
            knownCredential = "MySecretLabPass1",
        )

        assertThat(outcome).isInstanceOf(AuditOutcome.Matched::class.java)
        assertThat((outcome as AuditOutcome.Matched).matchedAtIndex).isEqualTo(2)
    }

    @Test
    fun `password strength analysis tallies every candidate without ever matching`() = runTest {
        val engine = AuditEngine()
        val candidates = flowOf("password", "Kx9!mQ2vZp#8wR", "123456")

        val outcome = engine.run(AuditMode.PASSWORD_STRENGTH_ANALYSIS, candidates, totalHint = 3)

        assertThat(outcome).isInstanceOf(AuditOutcome.StrengthSummary::class.java)
        val total = (outcome as AuditOutcome.StrengthSummary).distribution.values.sum()
        assertThat(total).isEqualTo(3)
    }

    @Test
    fun `empty wordlist completes immediately with no crash`() = runTest {
        val engine = AuditEngine()
        val outcome = engine.run(AuditMode.OFFLINE_WORDLIST_SIMULATION, flowOf(), totalHint = 0)
        assertThat(outcome).isEqualTo(AuditOutcome.NoMatch)
    }

    @Test
    fun `cancelling the run propagates CancellationException and leaves partial progress readable`() = runTest {
        val engine = AuditEngine()
        // An infinite flow that never contains the target — the run only ends when cancelled.
        val candidates = flow {
            var i = 0
            while (true) {
                emit("never-matches-$i")
                i++
                yield()
            }
        }

        val job = async {
            engine.run(AuditMode.OFFLINE_WORDLIST_SIMULATION, candidates, totalHint = 1_000_000)
        }
        yield()
        yield()
        job.cancel()

        var threw = false
        try {
            job.await()
        } catch (e: CancellationException) {
            threw = true
        }
        assertThat(threw).isTrue()
        assertThat(engine.progress.value.processed).isAtLeast(0)
    }

    @Test
    fun `pause blocks progress until resume is called`() = runTest {
        val engine = AuditEngine()
        engine.pause()
        val candidates = flowOf("a", "b", "c")

        val job = async {
            engine.run(AuditMode.OFFLINE_WORDLIST_SIMULATION, candidates, totalHint = 3)
        }
        // Give the coroutine a chance to start and hit the pause spin-wait.
        yield()
        assertThat(job.isCompleted).isFalse()

        engine.resume()
        val outcome = job.await()
        assertThat(outcome).isEqualTo(AuditOutcome.NoMatch)
    }
}
