# Room entities/DAOs are referenced via generated code + reflection in a few edge cases.
-keep class com.fajer.wifiaudit.data.local.entities.** { *; }
-keep class com.fajer.wifiaudit.data.local.dao.** { *; }

# Kotlin coroutines / Compose already ship consumer ProGuard rules; nothing extra needed here.

# Keep line numbers in stack traces for crash reports read manually on-device (no crash
# reporting SDK is used — this app has no analytics or telemetry of any kind).
-keepattributes SourceFile,LineNumberTable
-renamesourcefileattribute SourceFile
